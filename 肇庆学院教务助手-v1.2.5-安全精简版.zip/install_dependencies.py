#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""Install project dependencies with mirror fallback."""
from __future__ import annotations

import argparse
import subprocess
import sys
from dataclasses import dataclass
from pathlib import Path

ROOT = Path(__file__).resolve().parent
REQUIREMENTS = ROOT / "requirements.txt"


@dataclass(frozen=True)
class PipSource:
    name: str
    index_url: str | None = None


SOURCES = [
    PipSource("Official PyPI"),
    PipSource("Tsinghua mirror", "https://pypi.tuna.tsinghua.edu.cn/simple"),
    PipSource("Aliyun mirror", "https://mirrors.aliyun.com/pypi/simple/"),
    PipSource("USTC mirror", "https://pypi.mirrors.ustc.edu.cn/simple/"),
]


def _run(command: list[str]) -> int:
    print("\n" + "=" * 70)
    print("Command:")
    print(" ".join(f'"{part}"' if " " in part else part for part in command))
    print("=" * 70 + "\n")
    return subprocess.run(command, cwd=str(ROOT)).returncode


def install_dependencies(user_requested_source: str = "") -> int:
    if not REQUIREMENTS.exists():
        print(f"[ERROR] requirements.txt not found: {REQUIREMENTS}")
        return 2

    selected_sources = SOURCES
    if user_requested_source:
        text = user_requested_source.strip().lower()
        selected_sources = [
            source for source in SOURCES
            if text in source.name.lower() or text in str(source.index_url or "").lower()
        ]
        if not selected_sources:
            print(f"[ERROR] Unknown source: {user_requested_source}")
            return 2

    base = [
        sys.executable,
        "-m",
        "pip",
        "install",
        "-r",
        str(REQUIREMENTS),
        "--progress-bar",
        "on",
        "--disable-pip-version-check",
    ]

    for index, source in enumerate(selected_sources, start=1):
        print(f"[{index}/{len(selected_sources)}] Installing dependencies from {source.name}...")
        command = list(base)
        if source.index_url:
            command.extend(["-i", source.index_url])
        code = _run(command)
        if code == 0:
            print(f"\n[OK] Dependencies installed successfully from {source.name}.")
            return 0
        print(f"\n[WARN] {source.name} failed. Trying next source...")

    print("\n[FAILED] All sources failed. Check network, proxy or Python environment.")
    return 1


def main() -> int:
    parser = argparse.ArgumentParser(description="Install ZQU Academic Assistant dependencies")
    parser.add_argument("--source", default="", help="choose source: official, tsinghua, aliyun, ustc")
    args = parser.parse_args()
    return install_dependencies(args.source)


if __name__ == "__main__":
    raise SystemExit(main())
