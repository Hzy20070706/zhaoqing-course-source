#!/usr/bin/env python3
from __future__ import annotations

import argparse
import os
from pathlib import Path

import uvicorn

from server.app import create_app


ROOT = Path(__file__).resolve().parent


def main() -> None:
    parser = argparse.ArgumentParser(description="ZQU 助手中心服务器")
    parser.add_argument("--host", default="0.0.0.0")
    parser.add_argument("--port", type=int, default=8788)
    parser.add_argument("--db", type=Path, default=ROOT / "server" / "data" / "server.db")
    parser.add_argument("--key-dir", type=Path, default=ROOT / "server" / "data" / "keys")
    args = parser.parse_args()
    application = create_app(
        database_path=args.db,
        key_directory=args.key_dir,
        api_key=os.getenv("ZQU_SERVER_API_KEY", ""),
    )
    uvicorn.run(application, host=args.host, port=args.port, access_log=False)


if __name__ == "__main__":
    main()

