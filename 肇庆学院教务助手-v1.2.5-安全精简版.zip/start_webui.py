#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""Start the local ZQU WebUI."""
from __future__ import annotations

import argparse
import importlib.util
import os
import socket
import subprocess
import sys
import webbrowser
from json import JSONDecodeError, load
from pathlib import Path
from urllib.error import URLError
from urllib.request import urlopen

ROOT = Path(__file__).resolve().parent

REQUIRED_MODULES = {
    "aiohttp":"aiohttp",
    "requests":"requests",
    "loguru":"loguru",
    "Crypto":"pycryptodome",
    "cv2":"opencv-python",
    "numpy":"numpy",
    "PIL":"Pillow",
    "ddddocr":"ddddocr",
    "fastapi":"fastapi",
    "uvicorn":"uvicorn[standard]",
    "pydantic":"pydantic",
}


def _missing_dependencies() -> list[str]:
    missing = []
    for module_name, package_name in REQUIRED_MODULES.items():
        if importlib.util.find_spec(module_name) is None:
            missing.append(package_name)
    return sorted(set(missing))


def _install_dependencies() -> bool:
    installer = ROOT / "install_dependencies.py"
    if not installer.exists():
        print(f"Installer not found: {installer}")
        return False
    print("Installing missing dependencies automatically.")
    print("Mirror fallback order: PyPI -> Tsinghua -> Aliyun -> USTC.")
    print("pip will show its own download progress bar. Please wait.\n")
    code = subprocess.call([sys.executable, str(installer)], cwd=str(ROOT))
    return code == 0


def _ensure_web_dependencies(auto_install: bool = False) -> None:
    missing = _missing_dependencies()
    if not missing:
        return
    packages = " ".join(missing)
    if auto_install:
        print(f"Missing Python packages: {packages}")
        if _install_dependencies():
            missing = _missing_dependencies()
            if not missing:
                return
            packages = " ".join(missing)
    raise SystemExit(
        f"Missing Python packages: {packages}\n"
        f"Python executable: {sys.executable}\n"
        "Run install_dependencies.bat, or run manually:\n"
        f'  "{sys.executable}" -m pip install -r requirements.txt'
    )


def _port_available(host: str, port: int) -> bool:
    with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as sock:
        try:
            sock.bind((host, port))
            return True
        except OSError:
            return False


def _running_webui(url: str) -> bool:
    try:
        with urlopen(f"{url}api/health", timeout=1.5) as response:
            payload = load(response)
        return bool(isinstance(payload, dict) and payload.get("app"))
    except (OSError, URLError, JSONDecodeError, ValueError):
        return False


def _next_available_port(host: str, requested_port: int) -> int | None:
    for candidate in range(requested_port + 1, requested_port + 21):
        if _port_available(host, candidate):
            return candidate
    return None


def main() -> None:
    parser = argparse.ArgumentParser(description="ZQU Academic Assistant WebUI")
    parser.add_argument("--host", default="127.0.0.1")
    parser.add_argument("--port", type=int, default=8766)
    parser.add_argument("--server-url", default=os.getenv("ZQU_SERVER_URL", ""))
    parser.add_argument("--no-browser", action="store_true")
    parser.add_argument("--reload", action="store_true")
    parser.add_argument("--auto-install", action="store_true", help="install missing packages automatically")
    parser.add_argument("--no-auto-install", action="store_true", help="disable automatic dependency installation")
    args = parser.parse_args()

    if sys.platform.startswith("win"):
        os.environ.setdefault("PYTHONIOENCODING", "utf-8")
        for stream in (sys.stdout, sys.stderr):
            try:
                stream.reconfigure(encoding="utf-8")
            except Exception:
                pass

    if args.server_url:
        os.environ["ZQU_SERVER_URL"] = args.server_url.strip().rstrip("/")

    browser_host = "127.0.0.1" if args.host == "0.0.0.0" else args.host
    port = args.port
    url = f"http://{browser_host}:{port}/"
    if not _port_available(args.host, port):
        if _running_webui(url):
            print(f"ZQU Academic Assistant is already running: {url}")
            if not args.no_browser:
                webbrowser.open(url)
            return
        fallback_port = _next_available_port(args.host, port)
        if fallback_port is None:
            raise SystemExit(f"Ports {port}-{port + 20} are all busy. Try again later.")
        port = fallback_port
        url = f"http://{browser_host}:{port}/"
        print(f"Port {args.port} is busy. Switched to {port}.")

    auto_install = args.auto_install and not args.no_auto_install
    _ensure_web_dependencies(auto_install=auto_install)
    sys.path.insert(0, str(ROOT))
    import uvicorn

    print(f"ZQU Academic Assistant WebUI: {url}")
    if not args.no_browser:
        webbrowser.open(url)
    uvicorn.run(
        "webui.app:app",
        host=args.host,
        port=port,
        reload=args.reload,
        log_level="info",
        access_log=False,
    )


if __name__ == "__main__":
    main()
