@echo off
setlocal
cd /d "%~dp0"
set "PYTHON_EXE=D:\anaconda3\envs\cs2\python.exe"
if exist "%PYTHON_EXE%" (
  "%PYTHON_EXE%" install_dependencies.py %*
) else (
  echo [INFO] Preferred Python not found: %PYTHON_EXE%
  echo [INFO] Fallback to py -3.
  py -3 install_dependencies.py %*
)
if errorlevel 1 (
  echo.
  echo [FAILED] Dependency installation failed. Check network or Python environment.
  pause
) else (
  echo.
  echo [OK] Dependencies are installed.
  pause
)
endlocal
