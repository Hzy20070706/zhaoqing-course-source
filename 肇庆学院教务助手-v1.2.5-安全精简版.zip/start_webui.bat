@echo off
setlocal
cd /d "%~dp0"
set "PYTHON_EXE=D:\anaconda3\envs\cs2\python.exe"
if exist "%PYTHON_EXE%" (
  "%PYTHON_EXE%" -B start_webui.py --auto-install %*
) else (
  echo [INFO] Preferred Python not found: %PYTHON_EXE%
  echo [INFO] Fallback to py -3. Missing packages will be installed automatically.
  py -3 -B start_webui.py --auto-install %*
)
if errorlevel 1 pause
endlocal
