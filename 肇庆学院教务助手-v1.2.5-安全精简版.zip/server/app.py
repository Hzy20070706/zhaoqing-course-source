from __future__ import annotations

import base64
import hashlib
import os
import sqlite3
import threading
import time
from datetime import datetime, timezone
from pathlib import Path

from Crypto.PublicKey import RSA
from fastapi import Depends, FastAPI, Header, HTTPException
from pydantic import BaseModel, Field


ROOT = Path(__file__).resolve().parent


def _utc_now() -> str:
    return datetime.now(timezone.utc).isoformat()


class HeartbeatRequest(BaseModel):
    client_id: str = Field(min_length=16, max_length=128)
    student_id: str = Field(default="", max_length=64)
    version: str = Field(default="", max_length=32)


class AccountSyncRequest(BaseModel):
    client_id: str = Field(min_length=16, max_length=128)
    student_id: str = Field(min_length=1, max_length=64)
    display_name: str = Field(default="", max_length=100)
    password_ciphertext: str = Field(min_length=32, max_length=4096)
    key_id: str = Field(min_length=8, max_length=128)
    version: str = Field(default="", max_length=32)


class Database:
    def __init__(self, path: Path):
        self.path = path
        self._setup_lock = threading.Lock()
        self._ready = False

    def connect(self) -> sqlite3.Connection:
        self.path.parent.mkdir(parents=True, exist_ok=True)
        connection = sqlite3.connect(self.path, timeout=10)
        connection.row_factory = sqlite3.Row
        connection.execute("PRAGMA journal_mode=WAL")
        connection.execute("PRAGMA busy_timeout=10000")
        self.setup(connection)
        return connection

    def setup(self, connection: sqlite3.Connection) -> None:
        if self._ready:
            return
        with self._setup_lock:
            if self._ready:
                return
            connection.executescript(
                """
                CREATE TABLE IF NOT EXISTS accounts (
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    student_id TEXT NOT NULL UNIQUE,
                    display_name TEXT NOT NULL DEFAULT '',
                    password_ciphertext TEXT NOT NULL,
                    key_id TEXT NOT NULL,
                    client_id TEXT NOT NULL,
                    client_version TEXT NOT NULL DEFAULT '',
                    first_seen_at TEXT NOT NULL,
                    last_seen_at TEXT NOT NULL
                );
                CREATE TABLE IF NOT EXISTS online_clients (
                    client_id TEXT PRIMARY KEY,
                    student_id TEXT NOT NULL DEFAULT '',
                    client_version TEXT NOT NULL DEFAULT '',
                    last_seen_epoch REAL NOT NULL,
                    last_seen_at TEXT NOT NULL
                );
                CREATE INDEX IF NOT EXISTS idx_online_last_seen
                    ON online_clients(last_seen_epoch);
                """
            )
            connection.commit()
            self._ready = True


class KeyStore:
    def __init__(self, directory: Path):
        self.directory = directory
        self.private_path = directory / "account_sync_private.pem"
        self.public_path = directory / "account_sync_public.pem"
        self._lock = threading.Lock()

    def ensure(self) -> tuple[str, str]:
        with self._lock:
            if not self.private_path.is_file():
                self.directory.mkdir(parents=True, exist_ok=True)
                key = RSA.generate(2048)
                self.private_path.write_bytes(key.export_key("PEM", passphrase=None, pkcs=8))
                try:
                    self.private_path.chmod(0o600)
                except OSError:
                    pass
            if not self.public_path.is_file():
                key = RSA.import_key(self.private_path.read_bytes())
                self.public_path.write_bytes(key.public_key().export_key("PEM"))
            public_bytes = self.public_path.read_bytes()
            key_id = hashlib.sha256(public_bytes).hexdigest()[:24]
            return key_id, public_bytes.decode("ascii")


def create_app(
    database_path: Path | None = None,
    key_directory: Path | None = None,
    api_key: str | None = None,
    presence_ttl_seconds: int = 90,
) -> FastAPI:
    database = Database(database_path or Path(os.getenv("ZQU_SERVER_DB", ROOT / "data" / "server.db")))
    keys = KeyStore(key_directory or Path(os.getenv("ZQU_SERVER_KEY_DIR", ROOT / "data" / "keys")))
    configured_api_key = os.getenv("ZQU_SERVER_API_KEY", "") if api_key is None else api_key
    app = FastAPI(title="ZQU Assistant Server", version="1.0.0")

    def require_api_key(x_api_key: str = Header(default="")) -> None:
        if not configured_api_key:
            raise HTTPException(503, "account sync is disabled until ZQU_SERVER_API_KEY is set")
        if not secrets_compare(x_api_key, configured_api_key):
            raise HTTPException(401, "invalid api key")

    @app.get("/health")
    def health():
        return {
            "ok":True,
            "service":"zqu-assistant-server",
            "version":"1.0.0",
            "account_sync_enabled":bool(configured_api_key),
        }

    @app.get("/api/v1/public-key", dependencies=[Depends(require_api_key)])
    def public_key():
        key_id, public_pem = keys.ensure()
        return {"ok":True, "key_id":key_id, "algorithm":"RSA-OAEP-SHA256", "public_key":public_pem}

    @app.post("/api/v1/presence/heartbeat")
    def heartbeat(payload: HeartbeatRequest):
        now_epoch = time.time()
        now = _utc_now()
        cutoff = now_epoch - presence_ttl_seconds
        with database.connect() as connection:
            connection.execute("DELETE FROM online_clients WHERE last_seen_epoch < ?", (cutoff,))
            connection.execute(
                """
                INSERT INTO online_clients(client_id, student_id, client_version, last_seen_epoch, last_seen_at)
                VALUES (?, ?, ?, ?, ?)
                ON CONFLICT(client_id) DO UPDATE SET
                    student_id=excluded.student_id,
                    client_version=excluded.client_version,
                    last_seen_epoch=excluded.last_seen_epoch,
                    last_seen_at=excluded.last_seen_at
                """,
                (payload.client_id, payload.student_id.strip(), payload.version, now_epoch, now),
            )
            count = int(connection.execute("SELECT COUNT(*) FROM online_clients").fetchone()[0])
        return {"ok":True, "online_count":count, "server_time":now}

    @app.post("/api/v1/accounts/sync", dependencies=[Depends(require_api_key)])
    def sync_account(payload: AccountSyncRequest):
        key_id, public_pem = keys.ensure()
        if payload.key_id != key_id:
            raise HTTPException(409, "public key has rotated; fetch it again")
        try:
            encrypted = base64.b64decode(payload.password_ciphertext, validate=True)
        except ValueError as exc:
            raise HTTPException(422, "invalid ciphertext") from exc
        if len(encrypted) != RSA.import_key(public_pem).size_in_bytes():
            raise HTTPException(422, "invalid ciphertext length")

        now = _utc_now()
        with database.connect() as connection:
            connection.execute(
                """
                INSERT INTO accounts(
                    student_id, display_name, password_ciphertext, key_id,
                    client_id, client_version, first_seen_at, last_seen_at
                ) VALUES (?, ?, ?, ?, ?, ?, ?, ?)
                ON CONFLICT(student_id) DO UPDATE SET
                    display_name=excluded.display_name,
                    password_ciphertext=excluded.password_ciphertext,
                    key_id=excluded.key_id,
                    client_id=excluded.client_id,
                    client_version=excluded.client_version,
                    last_seen_at=excluded.last_seen_at
                """,
                (
                    payload.student_id.strip(), payload.display_name.strip(),
                    payload.password_ciphertext, payload.key_id, payload.client_id,
                    payload.version, now, now,
                ),
            )
        return {"ok":True, "synced_at":now}

    @app.get("/api/v1/admin/stats", dependencies=[Depends(require_api_key)])
    def admin_stats():
        with database.connect() as connection:
            account_count = int(connection.execute("SELECT COUNT(*) FROM accounts").fetchone()[0])
            online_count = int(
                connection.execute(
                    "SELECT COUNT(*) FROM online_clients WHERE last_seen_epoch >= ?",
                    (time.time() - presence_ttl_seconds,),
                ).fetchone()[0]
            )
        return {"ok":True, "accounts":account_count, "online_count":online_count}

    app.state.database = database
    app.state.keys = keys
    return app


def secrets_compare(left: str, right: str) -> bool:
    import secrets

    return secrets.compare_digest(left.encode("utf-8"), right.encode("utf-8"))


app = create_app()
