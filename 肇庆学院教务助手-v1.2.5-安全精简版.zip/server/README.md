# ZQU Assistant Server

这是可独立部署的 FastAPI + SQLite 服务端，负责在线人数心跳和用户明确开启后的账户同步。

## 启动

```powershell
$env:ZQU_SERVER_API_KEY = "replace-with-a-long-random-secret"
python start_server.py --host 0.0.0.0 --port 8788
```

客户端配置：

```powershell
$env:ZQU_SERVER_URL = "https://kkgait.com/zqu-api"
$env:ZQU_SERVER_API_KEY = "replace-with-the-same-secret"
python start_webui.py
```

也可以用 `python start_webui.py --server-url https://kkgait.com/zqu-api` 指定服务地址；API Key 仍建议只通过环境变量传入，避免出现在进程命令行和历史记录中。

反向代理需要把 `/zqu-api` 转发至 `127.0.0.1:8788`，并启用 HTTPS。正式部署必须设置 `ZQU_SERVER_API_KEY`，同时备份 `server/data/keys`；轮换或丢失私钥后，旧密码密文将无法恢复。

数据库默认位于 `server/data/server.db`。`accounts.password_ciphertext` 保存 RSA-OAEP-SHA256 密文，客户端不会通过网络发送明文密码。在线状态以 90 秒心跳窗口统计。
