"""Optional central service for the ZQU assistant."""

