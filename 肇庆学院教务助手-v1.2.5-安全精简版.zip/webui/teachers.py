from __future__ import annotations

import html
import json
import os
import re
import threading
import time
from concurrent.futures import ThreadPoolExecutor, as_completed
from dataclasses import dataclass
from html.parser import HTMLParser
from pathlib import Path
from typing import Any, Callable, Optional
from urllib.parse import urljoin, urlsplit

import requests


SEARCH_URL = "https://www.sogou.com/web"
PROJECT_ROOT = Path(__file__).resolve().parent.parent
DEFAULT_CACHE_PATH = PROJECT_ROOT / "data" / "teacher-profiles.json"
CACHE_VERSION = 4
EXTERNAL_ACADEMIC_HOSTS = {
    "orcid.org": "ORCID 公开资料",
    "www.researchgate.net": "ResearchGate 公开资料",
    "researchgate.net": "ResearchGate 公开资料",
    "scholar.google.com": "Google Scholar 公开资料",
}
OFFICIAL_DIRECTORY_URLS = (
    "https://chem.zqu.edu.cn/szdw.htm",
    "https://chem.zqu.edu.cn/szdw/jstd.htm",
    "https://cs.zqu.edu.cn/xygk/szdw.htm",
    "https://cs.zqu.edu.cn/xygk/jsfc.htm",
    "https://eee.zqu.edu.cn/szdw/jsbs.htm",
    "https://eee.zqu.edu.cn/szdw/gxjs.htm",
    "https://fpe.zqu.edu.cn/szdw.htm",
    "https://jgxy.zqu.edu.cn/szdw/jsbs.htm",
    "https://jky.zqu.edu.cn/xygk/szdw.htm",
    "https://jxqc.zqu.edu.cn/szdw.htm",
    "https://lyxy.zqu.edu.cn/xygk1/jsfc.htm",
    "https://maths.zqu.edu.cn/szdw/xbjs.htm",
    "https://maths.zqu.edu.cn/szdw/jsbs.htm",
    "https://mkszyxy.zqu.edu.cn/sztd.htm",
    "https://mkszyxy.zqu.edu.cn/sztd/xg_jxb.htm",
    "https://mkszyxy.zqu.edu.cn/sztd/mg_jxb.htm",
    "https://mkszyxy.zqu.edu.cn/sztd/df_jxb.htm",
    "https://mkszyxy.zqu.edu.cn/sztd/yl_jxb.htm",
    "https://mkszyxy.zqu.edu.cn/sztd/gy_jxb.htm",
    "https://mkszyxy.zqu.edu.cn/sztd/szx.htm",
    "https://mkszyxy.zqu.edu.cn/sztd/xsyzcjxb.htm",
    "https://mkszyxy.zqu.edu.cn/sztd/jslljxb.htm",
    "https://msxy.zqu.edu.cn/rzpy/msxx.htm",
    "https://peh.zqu.edu.cn/szdw/js.htm",
    "https://peh.zqu.edu.cn/szdw/bs.htm",
    "https://peh.zqu.edu.cn/szdw/fjs.htm",
    "https://peh.zqu.edu.cn/szdw/js2.htm",
    "https://sky.zqu.edu.cn/xygk/szdw.htm",
    "https://tec.zqu.edu.cn/szdw.htm",
    "https://wxy.zqu.edu.cn/ywgk/szll.htm",
    "https://wyxy.zqu.edu.cn/szdw/zrjs.htm",
    "https://wyxy.zqu.edu.cn/szdw/jsfc.htm",
    "https://zfxy.zqu.edu.cn/xygk/szdw.htm",
)
REQUEST_HEADERS = {
    "User-Agent": (
        "Mozilla/5.0 (Windows NT 10.0; Win64; x64) "
        "AppleWebKit/537.36 Chrome/126 Safari/537.36"
    ),
    "Accept-Language": "zh-CN,zh;q=0.9",
}
PROFILE_TITLE_MARKERS = ("详细资料", "个人简介", "教师简介", "教师信息", "师资简介")
PROFILE_SIGNALS = (
    "姓名",
    "职称",
    "系部",
    "所属学院",
    "研究方向",
    "研究领域",
    "主讲课程",
    "个人简介",
)
INVALID_NAMES = {"待定", "暂无", "无", "未定", "--"}
TEACHING_RECORD_PATTERNS = (
    ("十佳教师奖", re.compile(r"(?:肇庆学院)?十佳教师奖")),
    ("优秀教师称号", re.compile(r"优秀教师(?:称号)?")),
    ("教学名师", re.compile(r"(?:省级|校级)?教学名师")),
    ("优秀教学成果奖", re.compile(r"(?:肇庆学院)?优秀教学成果奖(?:[一二三]等奖)?")),
    ("教学成果奖", re.compile(r"(?<!优秀)(?:国家|省级|广东省)?教学成果奖(?:[一二三]等奖)?")),
    ("课堂教学竞赛", re.compile(r"课堂教学竞赛(?:[^。；;，,]{0,16})?(?:特等奖|一等奖|二等奖|三等奖|优秀奖)")),
    ("教学基本功比赛", re.compile(r"教学基本功比赛(?:[^。；;，,]{0,16})?(?:特等奖|一等奖|二等奖|三等奖|优秀奖)")),
    ("教学展示大赛", re.compile(r"教学展示大赛(?:[^。；;，,]{0,16})?(?:特等奖|一等奖|二等奖|三等奖|优秀奖)")),
    ("优质课例比赛", re.compile(r"优质课例比赛(?:[^。；;，,]{0,16})?(?:特等奖|一等奖|二等奖|三等奖|优秀奖)")),
    ("优秀教学案例", re.compile(r"优秀教学案例(?:[^。；;，,]{0,16})?(?:特等奖|一等奖|二等奖|三等奖|优秀奖)")),
)
FIELD_LABELS = (
    "姓名",
    "性别",
    "出生年月",
    "学历",
    "学位",
    "职称",
    "系部",
    "部门",
    "所属学院",
    "所在学院",
    "职务",
    "电子邮箱",
    "邮箱",
    "E-mail",
    "Email",
    "电话",
    "办公电话",
    "联系电话",
    "手机",
    "研究方向",
    "研究领域",
    "主讲课程",
    "承担课程",
    "教学课程",
)


def normalize_teacher_name(value: Any) -> str:
    name = re.sub(r"\s+", " ", str(value or "")).strip()
    if name in INVALID_NAMES or not 2 <= len(name) <= 30:
        return ""
    if name.endswith(("学院", "教研室", "系部", "中心")):
        return ""
    if not re.fullmatch(r"[\u3400-\u9fffA-Za-z·.\- ]+", name):
        return ""
    return name


def _teacher_name_from_directory_label(value: Any) -> str:
    label = _normalize_text(str(value or ""))
    # Some official directory cards put a full biography in the link text.  The
    # first name is still a reliable key when the target is an official /info/
    # page, while normalize_teacher_name() would reject the full long label.
    leading_name = re.match(r"^([\u3400-\u9fff·]{2,6})(?=\s|[，,。；;：:]|$)", label)
    if leading_name:
        return normalize_teacher_name(leading_name.group(1))
    match = re.match(
        r"^([\u3400-\u9fff·]{2,6})(?:\s+|[-—])(?:"
        r"教授|副教授|讲师|助教|博士|硕士|主任|副主任|系主任|系副主任|"
        r"教学部主任|教研部主任|教研室主任"
        r")(?:\s.*)?$",
        label,
    )
    return normalize_teacher_name(match.group(1) if match else label)


def is_official_zqu_url(url: str) -> bool:
    try:
        parsed = urlsplit(url)
    except ValueError:
        return False
    hostname = (parsed.hostname or "").lower().rstrip(".")
    return parsed.scheme in {"http", "https"} and (
        hostname == "zqu.edu.cn" or hostname.endswith(".zqu.edu.cn")
    )


def teacher_source_label(url: str) -> str:
    """Classify the small, reviewable set of sources allowed in teacher cards."""
    try:
        parsed = urlsplit(url)
    except ValueError:
        return ""
    hostname = (parsed.hostname or "").lower().rstrip(".")
    if is_official_zqu_url(url):
        return "肇庆学院官网"
    if parsed.scheme != "https":
        return ""
    if hostname.endswith(".edu.cn"):
        return "高校公开资料"
    return EXTERNAL_ACADEMIC_HOSTS.get(hostname, "")


def is_trusted_teacher_source_url(url: str) -> bool:
    return bool(teacher_source_label(url))


def _decode_response(response: Any) -> str:
    content = getattr(response, "content", None)
    if isinstance(content, bytes):
        prefix = content[:4096].decode("ascii", "ignore")
        match = re.search(r"charset\s*=\s*[\"']?([\w-]+)", prefix, re.I)
        encodings = [match.group(1)] if match else []
        encodings.extend(["utf-8", "gb18030"])
        for encoding in encodings:
            try:
                return content.decode(encoding)
            except (LookupError, UnicodeDecodeError):
                continue
        return content.decode("utf-8", "replace")
    return str(getattr(response, "text", ""))


class _ProfileHTMLParser(HTMLParser):
    _CONTENT_MARKERS = {
        "vsb_content",
        "v_news_content",
        "article-content",
        "article_content",
        "news-content",
        "news_content",
    }
    _VOID_TAGS = {"area", "base", "br", "col", "embed", "hr", "img", "input", "link", "meta", "param", "source", "track", "wbr"}
    _BLOCK_TAGS = {"br", "p", "div", "li", "tr", "td", "section", "article", "h1", "h2", "h3", "h4", "h5", "h6"}

    def __init__(self):
        super().__init__(convert_charrefs=True)
        self.depth = 0
        self.capture_depth: Optional[int] = None
        self.content_parts: list[str] = []
        self.title_parts: list[str] = []
        self.in_title = False
        self.meta: dict[str, str] = {}
        self.image_sources: list[str] = []
        self.ignored_depth = 0

    def handle_starttag(self, tag: str, attrs: list[tuple[str, Optional[str]]]):
        tag = tag.lower()
        if tag in {"script", "style"}:
            self.ignored_depth += 1
        values = {str(key).lower(): value or "" for key, value in attrs}
        marker_values = {
            token.strip().lower()
            for key in ("id", "class")
            for token in re.split(r"\s+", values.get(key, ""))
            if token.strip()
        }
        if self.capture_depth is None and marker_values & self._CONTENT_MARKERS:
            self.capture_depth = self.depth
        if tag == "title":
            self.in_title = True
        elif tag == "meta":
            name = values.get("name", "").lower()
            if name and values.get("content"):
                self.meta[name] = values["content"]
        if self.capture_depth is not None:
            if tag in self._BLOCK_TAGS:
                self.content_parts.append("\n")
            if tag == "img" and values.get("src"):
                self.image_sources.append(values["src"])
        if tag not in self._VOID_TAGS:
            self.depth += 1

    def handle_endtag(self, tag: str):
        tag = tag.lower()
        if tag == "title":
            self.in_title = False
        if tag in self._BLOCK_TAGS and self.capture_depth is not None:
            self.content_parts.append("\n")
        if tag not in self._VOID_TAGS:
            self.depth = max(0, self.depth - 1)
        if self.capture_depth is not None and self.depth <= self.capture_depth:
            self.capture_depth = None
        if tag in {"script", "style"}:
            self.ignored_depth = max(0, self.ignored_depth - 1)

    def handle_data(self, data: str):
        if self.in_title:
            self.title_parts.append(data)
        if self.capture_depth is not None and self.ignored_depth == 0:
            self.content_parts.append(data)


def _normalize_text(value: str, preserve_lines: bool = False) -> str:
    value = html.unescape(value or "").replace("\xa0", " ").replace("\u3000", " ")
    value = re.sub(r"[\u200b-\u200d\ufeff]", "", value)
    for pattern, replacement in (
        (r"姓\s*名", "姓名"),
        (r"性\s*别", "性别"),
        (r"学\s*位", "学位"),
        (r"职\s*称", "职称"),
        (r"系\s*部", "系部"),
        (r"职\s*务", "职务"),
        (r"电\s*话", "电话"),
    ):
        value = re.sub(pattern, replacement, value)
    if not preserve_lines:
        return re.sub(r"\s+", " ", value).strip()
    lines = [re.sub(r"[ \t\r\f\v]+", " ", line).strip() for line in value.split("\n")]
    return "\n".join(line for line in lines if line)


def _remove_contact_info(value: str) -> str:
    value = re.sub(r"[A-Z0-9._%+\-]+@[A-Z0-9.\-]+\.[A-Z]{2,}", "", value, flags=re.I)
    value = re.sub(r"(?<!\d)1[3-9]\d{9}(?!\d)", "", value)
    value = re.sub(r"(?<!\d)0\d{2,3}[-\s]?\d{7,8}(?!\d)", "", value)
    safe_lines = []
    for line in value.split("\n"):
        if re.match(r"^(?:电子邮箱|邮箱|E-?mail|电话|办公电话|联系电话|手机)\s*[：:]", line, re.I):
            continue
        safe_lines.append(line)
    return _normalize_text("\n".join(safe_lines), preserve_lines=True)


def _field_value(text: str, labels: tuple[str, ...]) -> str:
    label_pattern = "|".join(re.escape(label) for label in labels)
    all_labels = "|".join(re.escape(label) for label in FIELD_LABELS)
    match = re.search(
        rf"(?:{label_pattern})\s*[：:]\s*(.*?)\s*(?=(?:{all_labels})\s*[：:]|\n|$)",
        text,
        re.I | re.S,
    )
    if not match:
        return ""
    return _normalize_text(_remove_contact_info(match.group(1)))[:120]


def _professional_title(text: str) -> str:
    value = _field_value(text, ("职称",))
    if value:
        return value
    match = re.search(r"(?:教授|副教授|讲师|助教|研究员|副研究员|高级实验师|实验师)", text)
    return match.group(0) if match else ""


def _department(text: str, page_title: str) -> str:
    value = _field_value(text, ("系部", "部门", "所属学院", "所在学院"))
    if value:
        return value
    parts = [_normalize_text(part) for part in re.split(r"[-_|]", page_title)]
    candidates = [part for part in parts if part.endswith(("学院", "系")) and part != "肇庆学院"]
    return candidates[-1][:120] if candidates else ""


def _summary(text: str, name: str) -> str:
    cleaned = _remove_contact_info(text)
    candidates = []
    for line in cleaned.split("\n"):
        line = _normalize_text(line)
        if not line or re.match(r"^(?:姓名|性别|学历|学位|职称|系部|部门|所属学院|所在学院|职务)\s*[：:]", line):
            continue
        if name in line and len(line) >= 15:
            candidates.append(line)
    if not candidates:
        candidates = [
            _normalize_text(line)
            for line in cleaned.split("\n")
            if len(_normalize_text(line)) >= 24
            and any(word in line for word in ("毕业", "就职", "任职", "研究", "主讲", "讲授"))
        ]
    if not candidates:
        return ""
    return max(candidates, key=len)[:700]


def _research_and_courses(text: str) -> list[str]:
    values = []
    for labels in (("研究方向", "研究领域"), ("主讲课程", "承担课程", "教学课程")):
        value = _field_value(text, labels)
        if not value:
            continue
        for item in re.split(r"[、，,；;。]", value):
            item = _normalize_text(item)
            if 1 < len(item) <= 80 and item not in values:
                values.append(item)
    return values[:8]


def _public_teaching_records(text: str) -> list[str]:
    """Return only explicitly stated teaching honors from an official profile."""
    cleaned = _normalize_text(_remove_contact_info(text))
    records: list[str] = []
    for fallback, pattern in TEACHING_RECORD_PATTERNS:
        match = pattern.search(cleaned)
        if not match:
            continue
        record = _normalize_text(match.group(0))[:80] or fallback
        if record not in records:
            records.append(record)
    return records[:4]


def parse_teacher_profile(name: str, page_html: str, source_url: str) -> Optional[dict[str, Any]]:
    name = normalize_teacher_name(name)
    source_label = teacher_source_label(source_url)
    if not name or not source_label:
        return None
    parser = _ProfileHTMLParser()
    try:
        parser.feed(page_html)
    except Exception:
        return None
    page_title = _normalize_text("".join(parser.title_parts))
    description = _normalize_text(parser.meta.get("description", ""), preserve_lines=True)
    article_text = _normalize_text("".join(parser.content_parts), preserve_lines=True)
    profile_text = _normalize_text("\n".join((description, article_text)), preserve_lines=True)
    if name not in page_title or name not in profile_text:
        return None
    signal_count = sum(signal in profile_text for signal in PROFILE_SIGNALS)
    compact_profile = (
        len(article_text) >= 40
        and article_text.startswith(name)
        and (
            bool(_professional_title(profile_text))
            or (
                "博士" in article_text[:120]
                and any(marker in article_text for marker in ("研究", "课程", "讲授", "教学"))
            )
        )
    )
    if (
        not any(marker in page_title for marker in PROFILE_TITLE_MARKERS)
        and signal_count < 3
        and not compact_profile
    ):
        return None
    if "肇庆学院" not in page_title and "肇庆学院" not in profile_text:
        return None

    title = _professional_title(profile_text)
    department = _department(profile_text, page_title)
    summary = _summary(article_text or description, name)
    topics = _research_and_courses(profile_text)
    teaching_records = _public_teaching_records(profile_text)
    if not any((title, department, summary, topics, teaching_records)):
        return None

    photo_url = ""
    for source in parser.image_sources:
        candidate = urljoin(source_url, html.unescape(source.strip()))
        filename = urlsplit(candidate).path.lower()
        if is_official_zqu_url(candidate) and not re.search(r"(?:logo|icon|wx|weixin|qr|ewm)", filename):
            photo_url = candidate
            break
    result = {
        "name": name,
        "title": _remove_contact_info(title),
        "department": _remove_contact_info(department),
        "summary": summary,
        "topics": topics,
        "photo_url": photo_url,
        "source_url": source_url,
        "source_label": source_label,
    }
    if teaching_records:
        result["teaching_records"] = teaching_records
    return result


@dataclass
class _CacheItem:
    value: Optional[dict[str, Any]]
    expires_at: float
    persist: bool = True


def _directory_department(directory_url: str) -> str:
    hostname = (urlsplit(directory_url).hostname or "").lower()
    if hostname == "peh.zqu.edu.cn":
        return "体育与健康学院"
    return ""


class TeacherProfileService:
    def __init__(
        self,
        http_get: Callable[..., Any] = requests.get,
        *,
        found_ttl: int = 24 * 60 * 60,
        missing_ttl: int = 6 * 60 * 60,
        error_ttl: int = 5 * 60,
        cache_path: Optional[str | Path] = None,
    ):
        self._http_get = http_get
        self._found_ttl = found_ttl
        self._missing_ttl = missing_ttl
        self._error_ttl = error_ttl
        self._cache_path = Path(cache_path) if cache_path else None
        self._cache: dict[str, _CacheItem] = {}
        self._directory_index: dict[str, str] = {}
        self._directory_roster_pages: list[tuple[str, str, str]] = []
        self._directory_expires_at = 0.0
        self._lock = threading.RLock()
        self._directory_refresh_lock = threading.Lock()
        self._load_disk_cache()

    @staticmethod
    def _cached_profile(name: str, value: Any) -> Optional[dict[str, Any]]:
        """Validate and trim persisted data before it is trusted by the UI."""
        if not isinstance(value, dict) or normalize_teacher_name(value.get("name")) != name:
            return None
        source_url = str(value.get("source_url") or "").strip()
        is_roster = value.get("profile_kind") == "roster"
        source_label = "肇庆学院官网师资名录" if is_roster else teacher_source_label(source_url)
        if not source_label:
            return None
        if is_roster and not is_official_zqu_url(source_url):
            return None
        topics = value.get("topics")
        if not isinstance(topics, list):
            topics = []
        summary = _remove_contact_info(str(value.get("summary") or "").strip())[:700]
        teaching_records = _public_teaching_records(summary)
        result = {
            "name": name,
            "title": _remove_contact_info(str(value.get("title") or "").strip())[:120],
            "department": _remove_contact_info(str(value.get("department") or "").strip())[:120],
            "summary": summary,
            "topics": [str(item).strip()[:80] for item in topics if str(item).strip()][:8],
            "photo_url": str(value.get("photo_url") or "").strip()
            if is_official_zqu_url(str(value.get("photo_url") or "").strip())
            else "",
            "source_url": source_url,
            "source_label": source_label,
        }
        if is_roster:
            result["profile_kind"] = "roster"
        if teaching_records:
            result["teaching_records"] = teaching_records
        return result

    def _load_disk_cache(self):
        if self._cache_path is None or not self._cache_path.is_file():
            return
        try:
            raw = json.loads(self._cache_path.read_text(encoding="utf-8"))
            items = raw.get("items", {}) if isinstance(raw, dict) else {}
            cache_version = raw.get("version") if isinstance(raw, dict) else None
            now = time.time()
            if not isinstance(items, dict):
                return
            for raw_name, payload in items.items():
                name = normalize_teacher_name(raw_name)
                if not name or not isinstance(payload, dict):
                    continue
                expires_at = float(payload.get("expires_at", 0))
                if expires_at <= now:
                    continue
                value = payload.get("value")
                if cache_version != CACHE_VERSION and value is None:
                    continue
                if value is not None:
                    value = self._cached_profile(name, value)
                    if value is None:
                        continue
                self._cache[name] = _CacheItem(value=value, expires_at=expires_at)
        except (OSError, TypeError, ValueError, json.JSONDecodeError):
            # A partially written or hand-edited cache must never stop the app.
            return

    def _save_disk_cache(self):
        if self._cache_path is None:
            return
        now = time.time()
        items = {
            name: {"value": item.value, "expires_at": item.expires_at}
            for name, item in self._cache.items()
            if item.expires_at > now and item.persist
        }
        payload = {"version": CACHE_VERSION, "updated_at": now, "items": items}
        try:
            self._cache_path.parent.mkdir(parents=True, exist_ok=True)
            temporary = self._cache_path.with_name(self._cache_path.name + ".tmp")
            temporary.write_text(
                json.dumps(payload, ensure_ascii=False, indent=2, sort_keys=True),
                encoding="utf-8",
            )
            os.replace(temporary, self._cache_path)
        except OSError:
            return

    def _cached(self, name: str) -> tuple[bool, Optional[dict[str, Any]]]:
        now = time.time()
        with self._lock:
            item = self._cache.get(name)
            if item is None or item.expires_at <= now:
                self._cache.pop(name, None)
                return False, None
            return True, item.value

    def _store(
        self,
        name: str,
        value: Optional[dict[str, Any]],
        ttl: int,
        *,
        persist: bool = True,
    ):
        with self._lock:
            self._cache[name] = _CacheItem(
                value=value,
                expires_at=time.time() + ttl,
                persist=persist,
            )
            if persist:
                self._save_disk_cache()

    def _search_urls(self, name: str) -> list[str]:
        response = self._http_get(
            SEARCH_URL,
            params={"query": f'site:zqu.edu.cn "{name}" 教师 简介'},
            headers=REQUEST_HEADERS,
            timeout=8,
        )
        response.raise_for_status()
        result_html = _decode_response(response)
        urls = []
        for match in re.finditer(
            r"<a\b[^>]*href=[\"']([^\"']+)[\"'][^>]*>(.*?)</a>",
            result_html,
            re.I | re.S,
        ):
            candidate = html.unescape(match.group(1)).strip()
            label = _normalize_text(re.sub(r"<[^>]+>", " ", match.group(2)))
            if (
                is_official_zqu_url(candidate)
                and name in label
                and any(marker in label for marker in PROFILE_TITLE_MARKERS)
                and candidate not in urls
            ):
                urls.append(candidate)
        return urls[:8]

    def _external_search_urls(self, name: str) -> list[str]:
        response = self._http_get(
            SEARCH_URL,
            params={"query": f'"{name}" "肇庆学院" 教师'},
            headers=REQUEST_HEADERS,
            timeout=8,
        )
        response.raise_for_status()
        result_html = _decode_response(response)
        urls = []
        for match in re.finditer(
            r"<a\b[^>]*href=[\"']([^\"']+)[\"'][^>]*>(.*?)</a>",
            result_html,
            re.I | re.S,
        ):
            candidate = html.unescape(match.group(1)).strip()
            label = _normalize_text(re.sub(r"<[^>]+>", " ", match.group(2)))
            if (
                not is_official_zqu_url(candidate)
                and is_trusted_teacher_source_url(candidate)
                and name in label
                and any(marker in label for marker in ("教师", "教授", "讲师", "个人", "师资"))
                and candidate not in urls
            ):
                urls.append(candidate)
        return urls[:5]

    def _directory_urls(self, name: str) -> list[str]:
        now = time.time()
        with self._lock:
            if self._directory_expires_at > now:
                candidate = self._directory_index.get(name)
                return [candidate] if candidate else []
        with self._directory_refresh_lock:
            now = time.time()
            with self._lock:
                if self._directory_expires_at > now:
                    candidate = self._directory_index.get(name)
                    return [candidate] if candidate else []
            index: dict[str, str] = {}
            roster_pages: list[tuple[str, str, str]] = []
            for directory_url in OFFICIAL_DIRECTORY_URLS:
                try:
                    response = self._http_get(
                        directory_url,
                        headers=REQUEST_HEADERS,
                        timeout=8,
                        allow_redirects=True,
                    )
                    response.raise_for_status()
                    directory_html = _decode_response(response)
                except (requests.RequestException, TimeoutError, ValueError):
                    continue
                parser = _ProfileHTMLParser()
                try:
                    parser.feed(directory_html)
                except Exception:
                    parser = None
                if parser is not None:
                    roster_text = _normalize_text(
                        "".join(parser.content_parts), preserve_lines=True
                    )
                    if roster_text:
                        roster_pages.append((
                            directory_url,
                            roster_text,
                            _normalize_text("".join(parser.title_parts)),
                        ))
                for match in re.finditer(
                    r"<a\b[^>]*href=[\"']([^\"']+)[\"'][^>]*>(.*?)</a>",
                    directory_html,
                    re.I | re.S,
                ):
                    label = _teacher_name_from_directory_label(
                        _normalize_text(re.sub(r"<[^>]+>", " ", match.group(2)))
                    )
                    candidate = urljoin(directory_url, html.unescape(match.group(1)).strip())
                    if label and "/info/" in urlsplit(candidate).path and is_official_zqu_url(candidate):
                        index[label] = candidate
            with self._lock:
                if index or roster_pages:
                    self._directory_index = index
                    self._directory_roster_pages = roster_pages
                    self._directory_expires_at = now + 24 * 60 * 60
                else:
                    self._directory_expires_at = now + 5 * 60
                candidate = self._directory_index.get(name)
        return [candidate] if candidate else []

    def _directory_roster_profile(self, name: str) -> Optional[dict[str, Any]]:
        """Return an explicit official roster entry when no personal page exists."""
        with self._lock:
            pages = tuple(self._directory_roster_pages)
        compact_name = re.sub(r"\s+", "", name)
        for directory_url, roster_text, page_title in pages:
            if compact_name not in re.sub(r"\s+", "", roster_text):
                continue
            department = _directory_department(directory_url)
            title = _professional_title(page_title)
            unit = department or "肇庆学院"
            return {
                "name": name,
                "title": title,
                "department": department,
                "summary": (
                    f"{name}列于{unit}官网师资名录。该名录未提供个人简历、"
                    "研究方向或论文详情。"
                ),
                "topics": [],
                "photo_url": "",
                "source_url": directory_url,
                "source_label": "肇庆学院官网师资名录",
                "profile_kind": "roster",
            }
        return None

    def _profile_from_candidates(
        self, name: str, candidates: list[str]
    ) -> Optional[dict[str, Any]]:
        for candidate in candidates:
            response = self._http_get(
                candidate,
                headers=REQUEST_HEADERS,
                timeout=8,
                allow_redirects=True,
            )
            response.raise_for_status()
            final_url = str(getattr(response, "url", candidate))
            if not is_trusted_teacher_source_url(final_url):
                continue
            result = parse_teacher_profile(name, _decode_response(response), final_url)
            if result is not None:
                return result
        return None

    def lookup(self, value: Any) -> Optional[dict[str, Any]]:
        name = normalize_teacher_name(value)
        if not name:
            return None
        cached, result = self._cached(name)
        if cached:
            return result
        try:
            candidates = self._directory_urls(name)
            result = self._profile_from_candidates(name, candidates)
            if result is None:
                # A verified university roster is preferable to an unreliable
                # search request when that roster has no standalone profile.
                result = self._directory_roster_profile(name)
            if result is None and not candidates:
                result = self._profile_from_candidates(name, self._search_urls(name))
            if result is None:
                result = self._profile_from_candidates(
                    name, self._external_search_urls(name)
                )
            if result is not None:
                self._store(name, result, self._found_ttl)
                return result
            self._store(name, None, self._missing_ttl)
        except (requests.RequestException, TimeoutError, ValueError):
            # Transient network errors should not poison the static cache.
            self._store(name, None, self._error_ttl, persist=False)
        return None

    def lookup_many(self, names: list[Any], max_workers: int = 3) -> dict[str, dict[str, Any]]:
        unique = []
        for value in names:
            name = normalize_teacher_name(value)
            if name and name not in unique:
                unique.append(name)
        unique = unique[:40]
        if not unique:
            return {}
        found: dict[str, dict[str, Any]] = {}
        with ThreadPoolExecutor(max_workers=min(max_workers, len(unique))) as executor:
            futures = {executor.submit(self.lookup, name): name for name in unique}
            for future in as_completed(futures):
                name = futures[future]
                try:
                    profile = future.result()
                except Exception:
                    profile = None
                if profile is not None:
                    found[name] = profile
        return found


TEACHER_PROFILES = TeacherProfileService(
    # Found profiles stay local for six months; missing entries are retried weekly.
    found_ttl=180 * 24 * 60 * 60,
    missing_ttl=7 * 24 * 60 * 60,
    cache_path=DEFAULT_CACHE_PATH,
)
