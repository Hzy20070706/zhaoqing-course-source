from __future__ import annotations

import base64
import ctypes
import json
import os
import threading
from ctypes import wintypes
from dataclasses import dataclass
from datetime import datetime, timezone
from pathlib import Path
from typing import Optional


APP_ENTROPY = b"zqu-webui-saved-login-v1"
CRYPTPROTECT_UI_FORBIDDEN = 0x01


class DataBlob(ctypes.Structure):
    _fields_ = [
        ("cbData", wintypes.DWORD),
        ("pbData", ctypes.POINTER(ctypes.c_ubyte)),
    ]


def _input_blob(data: bytes) -> tuple[DataBlob, object]:
    buffer = (ctypes.c_ubyte * len(data)).from_buffer_copy(data)
    blob = DataBlob(len(data), ctypes.cast(buffer, ctypes.POINTER(ctypes.c_ubyte)))
    return blob, buffer


def _protect(data: bytes) -> bytes:
    if os.name != "nt":
        raise RuntimeError("保存登录信息需要 Windows DPAPI")
    data_blob, data_buffer = _input_blob(data)
    entropy_blob, entropy_buffer = _input_blob(APP_ENTROPY)
    output = DataBlob()
    crypt32 = ctypes.windll.crypt32
    kernel32 = ctypes.windll.kernel32
    result = crypt32.CryptProtectData(
        ctypes.byref(data_blob),
        "ZQU WebUI saved login",
        ctypes.byref(entropy_blob),
        None,
        None,
        CRYPTPROTECT_UI_FORBIDDEN,
        ctypes.byref(output),
    )
    _ = data_buffer, entropy_buffer
    if not result:
        raise ctypes.WinError()
    try:
        return ctypes.string_at(output.pbData, output.cbData)
    finally:
        kernel32.LocalFree(output.pbData)


def _unprotect(data: bytes) -> bytes:
    if os.name != "nt":
        raise RuntimeError("读取登录信息需要 Windows DPAPI")
    data_blob, data_buffer = _input_blob(data)
    entropy_blob, entropy_buffer = _input_blob(APP_ENTROPY)
    output = DataBlob()
    crypt32 = ctypes.windll.crypt32
    kernel32 = ctypes.windll.kernel32
    result = crypt32.CryptUnprotectData(
        ctypes.byref(data_blob),
        None,
        ctypes.byref(entropy_blob),
        None,
        None,
        CRYPTPROTECT_UI_FORBIDDEN,
        ctypes.byref(output),
    )
    _ = data_buffer, entropy_buffer
    if not result:
        raise ctypes.WinError()
    try:
        return ctypes.string_at(output.pbData, output.cbData)
    finally:
        kernel32.LocalFree(output.pbData)


@dataclass(frozen=True)
class SavedCredential:
    username: str
    password: str
    proxy: Optional[str]
    saved_at: str
    display_name: str = ""
    sync_account: bool = False


class CredentialStore:
    def __init__(self, path: Path):
        self.path = path
        self._lock = threading.RLock()

    def save(
        self,
        username: str,
        password: str,
        proxy: Optional[str],
        display_name: str = "",
        sync_account: bool = False,
    ) -> SavedCredential:
        saved_at = datetime.now(timezone.utc).isoformat()
        payload = json.dumps(
            {
                "username":username,
                "password":password,
                "proxy":proxy,
                "display_name":display_name,
                "sync_account":sync_account,
                "saved_at":saved_at,
            },
            ensure_ascii=False,
            separators=(",", ":"),
        ).encode("utf-8")
        document = {
            "version":1,
            "protected":base64.b64encode(_protect(payload)).decode("ascii"),
            "saved_at":saved_at,
        }
        encoded = json.dumps(document, ensure_ascii=True, indent=2)
        with self._lock:
            self.path.parent.mkdir(parents=True, exist_ok=True)
            temporary = self.path.with_suffix(self.path.suffix + ".tmp")
            temporary.write_text(encoded, encoding="utf-8")
            temporary.replace(self.path)
        return SavedCredential(username, password, proxy, saved_at, display_name, sync_account)

    def load(self) -> Optional[SavedCredential]:
        with self._lock:
            if not self.path.exists():
                return None
            document = json.loads(self.path.read_text(encoding="utf-8"))
            if document.get("version") != 1:
                raise ValueError("不支持的凭据文件版本")
            protected = base64.b64decode(document["protected"], validate=True)
            payload = json.loads(_unprotect(protected).decode("utf-8"))
        username = str(payload.get("username", "")).strip()
        password = str(payload.get("password", ""))
        if not username or not password:
            raise ValueError("已保存的登录信息不完整")
        proxy = str(payload.get("proxy") or "").strip() or None
        return SavedCredential(
            username=username,
            password=password,
            proxy=proxy,
            saved_at=str(payload.get("saved_at") or document.get("saved_at") or ""),
            display_name=str(payload.get("display_name") or "").strip(),
            sync_account=bool(payload.get("sync_account", False)),
        )

    def clear(self) -> bool:
        with self._lock:
            if not self.path.exists():
                return False
            self.path.unlink()
            return True
