"""Local WebUI package for the ZQU assistant."""
