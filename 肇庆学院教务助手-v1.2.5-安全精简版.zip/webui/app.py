from __future__ import annotations

import asyncio
import importlib.util
import json
import re
import secrets
import sys
import threading
import time
from collections import deque
from dataclasses import dataclass, field
from datetime import datetime, timedelta
from pathlib import Path
from typing import Any, Optional

import requests
from fastapi import FastAPI, HTTPException, Request, Response
from fastapi.responses import FileResponse, StreamingResponse
from fastapi.staticfiles import StaticFiles
from pydantic import BaseModel, Field

from webui.community import ClientIdentityStore, CommunityClient, CommunityConfig
from webui.security import CredentialStore, SavedCredential
from webui.teachers import TEACHER_PROFILES, normalize_teacher_name

ROOT = Path(__file__).resolve().parents[1]
STATIC_DIR = Path(__file__).resolve().parent / "static"
DATA_DIR = ROOT / "data"
CREDENTIALS = CredentialStore(DATA_DIR / "saved_login.json")
COMMUNITY = CommunityClient(
    CommunityConfig.from_environment(),
    ClientIdentityStore(DATA_DIR / "community_client_id"),
)
BACKGROUND_TASKS: set[asyncio.Task] = set()
SESSION_TTL_SECONDS = 12 * 60 * 60


def _load_core():
    path = ROOT / "抢课.py"
    spec = importlib.util.spec_from_file_location("zqu_grabber_core", path)
    if spec is None or spec.loader is None:
        raise RuntimeError(f"无法加载核心模块: {path}")
    module = importlib.util.module_from_spec(spec)
    sys.modules[spec.name] = module
    spec.loader.exec_module(module)
    return module


core = _load_core()


@dataclass
class UserContext:
    session: requests.Session
    username: str
    proxy: Optional[str]
    display_name: str = ""
    sync_requested: bool = False
    sync_status: str = "disabled"
    sync_error: str = ""
    lock: threading.RLock = field(default_factory=threading.RLock, repr=False)
    created_at: float = field(default_factory=time.time)
    last_seen_at: float = field(default_factory=time.time)
    scanner: Any = None
    course_types: dict[str, Any] = field(default_factory=dict)
    grades: list[dict] = field(default_factory=list)
    notices: list[dict] = field(default_factory=list)
    timetable_terms: list[dict] = field(default_factory=list)
    timetables: dict[str, dict] = field(default_factory=dict)
    school_online_count: Optional[int] = None
    school_online_updated_at: float = 0.0
    school_online_error: str = ""
    school_online_history: list[dict[str, Any]] = field(default_factory=list)
    retain_session: bool = False

    def __post_init__(self):
        self.scanner = core.Scanner(self.session)


class SessionStore:
    def __init__(self):
        self._items: dict[str, UserContext] = {}
        self._lock = threading.Lock()

    def create(self, context: UserContext) -> str:
        self.prune()
        sid = secrets.token_urlsafe(32)
        with self._lock:
            self._items[sid] = context
        return sid

    def get(self, sid: str) -> Optional[UserContext]:
        self.prune()
        with self._lock:
            context = self._items.get(sid)
            if context is not None:
                context.last_seen_at = time.time()
            return context

    def remove(self, sid: str) -> Optional[UserContext]:
        with self._lock:
            return self._items.pop(sid, None)

    def prune(self, ttl_seconds: int = SESSION_TTL_SECONDS) -> int:
        cutoff = time.time() - ttl_seconds
        with self._lock:
            stale = [
                sid for sid, context in self._items.items()
                if context.last_seen_at < cutoff and not context.retain_session
            ]
            contexts = [self._items.pop(sid) for sid in stale]
        for context in contexts:
            try:
                context.session.close()
            except Exception:
                pass
        return len(contexts)

    def active_count(self, ttl_seconds: int = 90) -> int:
        self.prune()
        cutoff = time.time() - ttl_seconds
        with self._lock:
            return sum(context.last_seen_at >= cutoff for context in self._items.values())


SESSIONS = SessionStore()


@dataclass
class LoginJob:
    id: str
    username: str
    display_name: str = ""
    status: str = "pending"
    progress: int = 0
    message: str = "准备登录"
    error: str = ""
    sid: str = ""
    created_at: float = field(default_factory=time.time)


class LoginJobStore:
    def __init__(self):
        self._items: dict[str, LoginJob] = {}
        self._lock = threading.RLock()

    def create(self, username: str, display_name: str = "") -> LoginJob:
        self.prune()
        job = LoginJob(
            id=secrets.token_urlsafe(20),
            username=username,
            display_name=display_name,
        )
        with self._lock:
            self._items[job.id] = job
        return job

    def get(self, job_id: str) -> Optional[LoginJob]:
        with self._lock:
            return self._items.get(job_id)

    def update(self, job_id: str, **values: Any) -> Optional[LoginJob]:
        with self._lock:
            job = self._items.get(job_id)
            if job is not None:
                for key, value in values.items():
                    setattr(job, key, value)
            return job

    def prune(self):
        cutoff = time.time() - 15 * 60
        with self._lock:
            stale = [key for key, job in self._items.items() if job.created_at < cutoff]
            for key in stale:
                self._items.pop(key, None)


LOGIN_JOBS = LoginJobStore()
_LOGIN_WARMUP_LOCK = threading.Lock()
_LOGIN_WARMUP_ACTIVE = False


def _run_login_warmup() -> None:
    global _LOGIN_WARMUP_ACTIVE
    try:
        core.warm_login_dependencies()
    except Exception:
        # Warm-up is optional; login keeps its normal error handling path.
        pass
    finally:
        with _LOGIN_WARMUP_LOCK:
            _LOGIN_WARMUP_ACTIVE = False


def _schedule_login_warmup() -> bool:
    global _LOGIN_WARMUP_ACTIVE
    with _LOGIN_WARMUP_LOCK:
        if _LOGIN_WARMUP_ACTIVE:
            return False
        _LOGIN_WARMUP_ACTIVE = True
    threading.Thread(
        target=_run_login_warmup,
        name="zqu-login-warmup",
        daemon=True,
    ).start()
    return True


def _context(request: Request) -> UserContext:
    sid = request.cookies.get("zqu_session", "")
    context = SESSIONS.get(sid)
    if context is None:
        raise HTTPException(401, "请先登录")
    return context


def _safe_timetable_item(row: dict) -> dict:
    allowed = {
        "id", "course_name", "course_code", "class_name", "teacher", "location",
        "day", "weekday", "periods", "start_period", "end_period", "time",
        "weeks", "week_summary",
    }
    return {key: row.get(key) for key in allowed if key in row}


def _mask_username(username: str) -> str:
    if len(username) <= 5:
        return username
    return username[:4] + "*" * (len(username) - 7) + username[-3:]


def _safe_grade(row: dict) -> dict:
    item = dict(row)
    for key in ("xsbh", "xsxm", "xsdm"):
        item.pop(key, None)
    if core._grade_hidden(item):
        item["zcj"] = "**"
        item["cjjd"] = "**"
    return item


def _apply_school_display_name(context: UserContext) -> str:
    school_name = next(
        (
            str(row.get("xsxm", "")).strip()
            for row in context.grades
            if str(row.get("xsxm", "")).strip()
        ),
        "",
    )
    if not school_name:
        return context.display_name
    context.display_name = school_name
    try:
        credential = _load_saved_credential()
        if (
            credential
            and credential.username == context.username
            and credential.display_name != school_name
        ):
            CREDENTIALS.save(
                credential.username,
                credential.password,
                credential.proxy,
                school_name,
                credential.sync_account,
            )
    except Exception:
        pass
    return school_name


def _locked_call(context: UserContext, callback: Any, *args: Any, **kwargs: Any) -> Any:
    """Serialize access to the shared requests.Session."""
    with context.lock:
        return callback(*args, **kwargs)


def _school_online_error_message(exc: Exception) -> str:
    if isinstance(exc, requests.Timeout):
        return "教务在线人数请求超时，请稍后重试"
    if isinstance(exc, requests.ConnectionError):
        return "无法连接教务在线人数接口，请检查网络后重试"
    message = str(exc)
    if any(token in message for token in ("会话", "登录", "session", "login")):
        return "教务会话已过期，请重新登录后再读取在线人数"
    if "HTTP" in message:
        return "教务在线人数接口响应异常，请稍后重试"
    return "教务在线人数接口未返回有效数据，请稍后重试"


def _school_online_status(context: UserContext, refresh: bool = False) -> dict[str, Any]:
    def payload(connected: bool, error: Optional[str] = None) -> dict[str, Any]:
        return {
            "connected": connected,
            "online_count": context.school_online_count,
            "updated_at": context.school_online_updated_at,
            "error": "" if connected else (error if error is not None else context.school_online_error),
            "history": [dict(sample) for sample in context.school_online_history],
        }

    now = time.time()
    if (
        not refresh
        and context.school_online_count is not None
        and now - context.school_online_updated_at < 15
    ):
        return payload(True)

    def fetch_online_count() -> int:
        response = context.session.get(
            core.EDU_PROXY + "login!getOnlineCount.action",
            headers={
                "X-Requested-With": "XMLHttpRequest",
                "Referer": core.EDU_PROXY,
            },
            timeout=10,
        )
        response.raise_for_status()
        value = str(response.text).strip()
        if not re.fullmatch(r"\d+", value):
            try:
                body = json.loads(value)
            except (TypeError, json.JSONDecodeError):
                body = None
            if isinstance(body, dict) and body.get("success") is False:
                message = str(body.get("message") or "")
                if message:
                    raise RuntimeError(message)
            raise RuntimeError("在线人数接口未返回数字")
        return int(value)

    try:
        with context.lock:
            now = time.time()
            if (
                not refresh
                and context.school_online_count is not None
                and now - context.school_online_updated_at < 15
            ):
                return payload(True)
            context.school_online_count = fetch_online_count()
            context.school_online_updated_at = time.time()
            context.school_online_error = ""
            context.school_online_history.append({
                "ts": context.school_online_updated_at,
                "online_count": context.school_online_count,
            })
            del context.school_online_history[:-120]
    except Exception as exc:
        context.school_online_error = _school_online_error_message(exc)
        return payload(False)

    return payload(True)


def _set_session_cookie(response: Response, sid: str):
    response.set_cookie(
        "zqu_session",
        sid,
        httponly=True,
        samesite="strict",
        secure=False,
        max_age=7 * 24 * 60 * 60,
    )


def _load_saved_credential() -> Optional[SavedCredential]:
    try:
        return CREDENTIALS.load()
    except Exception:
        return None


def _refresh_context_session(
    context: UserContext, credential: SavedCredential
) -> dict[str, str]:
    proxy = context.proxy or credential.proxy
    session = core.vpn_login(credential.username, credential.password, proxy)
    if session is None or not core.edu_login(
        session, credential.username, credential.password
    ):
        if session is not None:
            session.close()
        raise RuntimeError("定时启动前重新登录失败")
    with context.lock:
        previous = context.session
        context.session = session
        context.scanner = core.Scanner(session)
    previous.close()
    return {key:value for key, value in session.cookies.items()}


def _resolve_course_window(raw: dict, now_cn: datetime) -> Optional[dict]:
    """Return the active, next, or most recently ended selection window."""
    active = core.choose_active_or_next_window(raw, now_cn)
    if active is not None:
        return active
    windows = sorted(core.get_course_windows(raw), key=lambda item:item["start"])
    if windows and now_cn > windows[-1]["end"]:
        return {**windows[-1], "status":"ended"}
    return None


def _serialize_course_window(active: Optional[dict]) -> Optional[dict]:
    if active is None:
        return None
    return {
        "stage": active["stage"],
        "status": active["status"],
        "start": active["start"].isoformat(),
        "end": active["end"].isoformat(),
        "has_started": active["status"] in {"active", "ended"},
        "is_open": active["status"] == "active",
        "source": "教务系统选课类型字段",
    }


def _serialize_course_type(key: str, course_type: Any) -> dict:
    now_cn = core.datetime.now(core.CN_TZ)
    active = _resolve_course_window(course_type.raw, now_cn)
    return {
        "id": key,
        "name": course_type.name,
        "controller": course_type.controller,
        "window": _serialize_course_window(active),
    }


def _course_selection_state(
    course: Any,
    enrolled_ids: set[str],
    enrolled_sections: set[str],
    enrolled_course_ids: set[str],
) -> tuple[bool, bool]:
    exact_selected = (
        bool(course.kcrwdm and course.kcrwdm in enrolled_ids)
        or bool(course.section and course.section in enrolled_sections)
    )
    same_course_selected = bool(
        not exact_selected and course.kcdm and course.kcdm in enrolled_course_ids
    )
    return exact_selected, same_course_selected


def _confirmed_target_names(targets: list[Any], enrolled: list[dict]) -> list[str]:
    enrolled_ids = {str(item.get("kcrwdm", "")) for item in enrolled if item.get("kcrwdm")}
    enrolled_sections = {
        str(item.get("jxbmc", item.get("xmmc", "")))
        for item in enrolled
        if item.get("jxbmc", item.get("xmmc", ""))
    }
    enrolled_course_ids = {str(item.get("kcdm", "")) for item in enrolled if item.get("kcdm")}
    return [
        course.name
        for course in targets
        if any(
            _course_selection_state(
                course, enrolled_ids, enrolled_sections, enrolled_course_ids
            )
        )
    ]


async def _verify_target_enrollment(
    context: UserContext, course_type: Any, targets: list[Any], attempts: int = 3
) -> list[str]:
    """Confirm a successful submit against the authoritative enrolled-course list."""
    for attempt in range(max(1, attempts)):
        enrolled = await asyncio.to_thread(
            _locked_call, context, lambda: context.scanner.scan_enrolled(course_type)
        )
        confirmed = _confirmed_target_names(targets, enrolled)
        if confirmed:
            return confirmed
        if attempt + 1 < attempts:
            await asyncio.sleep(1)
    return []


def _serialize_course(
    course: Any,
    enrolled_ids: set[str],
    enrolled_sections: set[str],
    enrolled_course_ids: set[str],
) -> dict:
    exact_selected, same_course_selected = _course_selection_state(
        course,
        enrolled_ids,
        enrolled_sections,
        enrolled_course_ids,
    )
    return {
        "id": course.kcrwdm,
        "name": course.name,
        "section": course.section,
        "teacher": course.teacher,
        "capacity": course.capacity,
        "enrolled": course.enrolled,
        "remaining": course.remaining,
        "available": course.available,
        "credits": course.credits,
        "nature": course.nature,
        "time": course.time_info,
        "selected": exact_selected or same_course_selected,
        "exact_selected":exact_selected,
        "same_course_selected":same_course_selected,
    }


def _serialize_notice(item: dict) -> dict:
    notice_type = str(item.get("type", ""))
    raw_message = str(item.get("msg", ""))
    payload: dict[str, Any] = {}
    if raw_message.lstrip().startswith("{"):
        try:
            parsed = json.loads(raw_message)
            if isinstance(parsed, dict):
                payload = parsed
        except (TypeError, ValueError):
            pass

    title = "教务通知"
    body = re.sub(r"<[^>]+>", " ", raw_message).strip()
    if notice_type.endswith("cjtz"):
        title = f"{payload.get('kcmc', '课程')}成绩通知"
        body = f"总成绩：{payload.get('zcj', '--')} · 绩点：{payload.get('jd', '--')}"
    elif notice_type.endswith("xkcl"):
        title = f"{payload.get('kcmc', '课程')}选课处理"
        body = "本轮未被选中，请关注下一轮选课开放时间。"
    elif notice_type.endswith(("sh", "hg", "mt")):
        title = str(payload.get("subject") or "业务办理通知")
        parts = [str(payload.get("status") or "")]
        feedback = payload.get("feedback")
        if feedback not in (None, "", "null"):
            parts.append(f"意见：{feedback}")
        body = " · ".join(part for part in parts if part) or body

    return {
        "id":str(item.get("xxid", "")),
        "type":notice_type,
        "title":title,
        "body":body or "无正文",
    }


def _fetch_unread_notices(context: UserContext) -> list[dict]:
    response = context.session.get(
        core.EDU_PROXY + "notice!getNotice.action",
        headers={
            "X-Requested-With":"XMLHttpRequest",
            "Referer":core.EDU_PROXY + "desktop!showDesktop.action",
        },
        timeout=15,
    )
    response.raise_for_status()
    data = response.json()
    return data if isinstance(data, list) else []


class LoginRequest(BaseModel):
    username: str = Field(min_length=1, max_length=64)
    password: str = Field(min_length=1, max_length=256)
    display_name: str = Field(default="", max_length=100)
    proxy: str = Field(default="", max_length=500)
    remember: bool = False
    sync_account: bool = False


class TeacherProfilesRequest(BaseModel):
    names: list[str] = Field(default_factory=list, max_length=40)


class GrabRequest(BaseModel):
    course_type_id: str
    target_ids: list[str] = Field(min_length=1, max_length=3)
    mode: str = "auto"
    scheduled_at: Optional[datetime] = None
    pool_size: int = Field(default=8, ge=1, le=32)
    poll_ms: int = Field(default=200, ge=1, le=1000)
    jitter_ms: int = Field(default=40, ge=0, le=1000)
    retry_ms: int = Field(default=800, ge=200, le=5000)
    hang_hours: float = Field(default=24, ge=1, le=720)
    warmup_ms: int = Field(default=6000, ge=0, le=30000)
    lead_ms: int = Field(default=40, ge=0, le=500)
    burst_count: int = Field(default=3, ge=1, le=20)
    burst_gap_ms: int = Field(default=80, ge=1, le=1000)
    prefire: bool = False
    prefire_interval_ms: int = Field(default=200, ge=50, le=5000)


async def _run_login_job(
    job_id: str,
    username: str,
    password: str,
    display_name: str,
    proxy: Optional[str],
    remember: bool,
    sync_account: bool,
    old_sid: str,
):
    session: Optional[requests.Session] = None
    try:
        LOGIN_JOBS.update(
            job_id,
            status="running",
            progress=12,
            message="初始化本地安全会话",
        )
        await asyncio.sleep(0)
        LOGIN_JOBS.update(
            job_id,
            progress=24,
            message="识别验证码并连接 WebVPN",
        )
        session = await asyncio.to_thread(core.vpn_login, username, password, proxy)
        if session is None:
            raise RuntimeError("账号、密码或验证码校验失败")

        LOGIN_JOBS.update(job_id, progress=62, message="WebVPN 已连接")
        await asyncio.sleep(0)
        LOGIN_JOBS.update(job_id, progress=72, message="登录教务系统")
        authenticated = await asyncio.to_thread(
            core.edu_login, session, username, password
        )
        if not authenticated:
            raise RuntimeError("教务系统登录失败")

        LOGIN_JOBS.update(job_id, progress=90, message="建立本地登录会话")
        old_context = SESSIONS.remove(old_sid) if old_sid else None
        if old_context:
            old_context.session.close()
        context = UserContext(
            session=session,
            username=username,
            proxy=proxy,
            display_name=display_name,
            sync_requested=sync_account,
            sync_status="pending" if sync_account else "disabled",
        )
        sid = SESSIONS.create(context)
        session = None

        save_message = "登录成功"
        try:
            if remember:
                await asyncio.to_thread(
                    CREDENTIALS.save,
                    username,
                    password,
                    proxy,
                    display_name,
                    sync_account,
                )
                save_message = "登录成功，账号已安全保存"
            else:
                await asyncio.to_thread(CREDENTIALS.clear)
        except Exception as exc:
            save_message = f"登录成功，但保存登录信息失败: {exc}"

        LOGIN_JOBS.update(
            job_id,
            status="success",
            progress=100,
            message=save_message,
            sid=sid,
        )
        if sync_account:
            _queue_account_sync(context, password)
    except asyncio.CancelledError:
        LOGIN_JOBS.update(
            job_id, status="error", progress=100, error="登录任务已取消"
        )
        raise
    except Exception as exc:
        LOGIN_JOBS.update(
            job_id,
            status="error",
            progress=100,
            message="登录失败",
            error=str(exc),
        )
    finally:
        password = ""
        if session is not None:
            session.close()


def _start_login_job(
    username: str,
    password: str,
    display_name: str,
    proxy: Optional[str],
    remember: bool,
    sync_account: bool,
    old_sid: str,
) -> LoginJob:
    job = LOGIN_JOBS.create(username, display_name)
    asyncio.create_task(
        _run_login_job(
            job.id,
            username,
            password,
            display_name,
            proxy,
            remember,
            sync_account,
            old_sid,
        ),
        name=f"zqu-login-{job.id[:8]}",
    )
    return job


def _queue_account_sync(context: UserContext, password: str) -> None:
    if not context.sync_requested:
        return
    if not COMMUNITY.configured:
        context.sync_status = "not_configured"
        context.sync_error = "社区服务器尚未配置"
        return

    async def worker(secret_password: str):
        context.sync_status = "syncing"
        try:
            await asyncio.to_thread(
                COMMUNITY.sync_account,
                context.username,
                context.display_name,
                secret_password,
            )
            context.sync_status = "synced"
            context.sync_error = ""
        except Exception as exc:
            context.sync_status = "error"
            context.sync_error = str(exc)[:240]
        finally:
            secret_password = ""

    task = asyncio.create_task(worker(password), name=f"zqu-account-sync-{context.username[-4:]}")
    BACKGROUND_TASKS.add(task)
    task.add_done_callback(BACKGROUND_TASKS.discard)


class GrabController:
    def __init__(self):
        self.task: Optional[asyncio.Task] = None
        self.grabber: Any = None
        self.state = self._idle_state()
        self.history: deque[dict] = deque(maxlen=500)
        self.subscribers: set[asyncio.Queue] = set()
        self._lock = asyncio.Lock()

    @staticmethod
    def _idle_state() -> dict:
        return {
            "status":"idle",
            "started_at":None,
            "finished_at":None,
            "targets":[],
            "course_type":"",
            "message":"等待任务",
            "scheduled_for":None,
        }

    def emit(self, message: str, kind: str = "info"):
        event = {"ts":time.time(), "kind":kind, "message":str(message).strip()}
        self.history.append(event)
        for queue in tuple(self.subscribers):
            try:
                queue.put_nowait(event)
            except asyncio.QueueFull:
                pass

    def subscribe(self) -> asyncio.Queue:
        queue: asyncio.Queue = asyncio.Queue(maxsize=200)
        self.subscribers.add(queue)
        return queue

    def unsubscribe(self, queue: asyncio.Queue):
        self.subscribers.discard(queue)

    async def start(self, context: UserContext, request: GrabRequest):
        async with self._lock:
            if self.task and not self.task.done():
                raise HTTPException(409, "已有抢课任务正在运行")
            course_type = context.course_types.get(request.course_type_id)
            if course_type is None:
                raise HTTPException(400, "请重新刷新选课类型")
            if not course_type.courses:
                await asyncio.to_thread(
                    _locked_call,
                    context,
                    lambda: context.scanner.scan_courses(course_type),
                )
            if len(set(request.target_ids)) != len(request.target_ids):
                raise HTTPException(400, "志愿课程不能重复")
            course_map = {course.kcrwdm:course for course in course_type.courses}
            targets = [course_map[target_id] for target_id in request.target_ids if target_id in course_map]
            if not targets:
                raise HTTPException(400, "没有有效的目标课程")

            mode = request.mode.lower()
            if mode not in {"auto", "timed", "scheduled", "poll", "watch"}:
                raise HTTPException(400, "运行模式无效")
            local_now_cn = core.datetime.now(core.CN_TZ)
            selection_window = _resolve_course_window(course_type.raw, local_now_cn)
            if selection_window and selection_window["status"] == "ended":
                ended_at = selection_window["end"].strftime("%Y-%m-%d %H:%M:%S")
                raise HTTPException(409, f"该选课时间已于 {ended_at} 结束，不能再配置或启动任务")

            enrolled = await asyncio.to_thread(
                _locked_call,
                context,
                lambda: context.scanner.scan_enrolled(course_type),
            )
            enrolled_ids = {
                str(item.get("kcrwdm", "")) for item in enrolled if item.get("kcrwdm")
            }
            enrolled_sections = {
                str(item.get("jxbmc", item.get("xmmc", "")))
                for item in enrolled
                if item.get("jxbmc", item.get("xmmc", ""))
            }
            enrolled_course_ids = {
                str(item.get("kcdm", "")) for item in enrolled if item.get("kcdm")
            }
            blocked_targets = [
                course
                for course in targets
                if any(
                    _course_selection_state(
                        course,
                        enrolled_ids,
                        enrolled_sections,
                        enrolled_course_ids,
                    )
                )
            ]
            if blocked_targets:
                names = "、".join(dict.fromkeys(course.name for course in blocked_targets))
                raise HTTPException(409, f"已经选过同一课程，无需再次选择：{names}")

            if mode in {"watch", "poll"}:
                server_delta = timedelta(0)
            else:
                server_delta = await asyncio.to_thread(
                    _locked_call,
                    context,
                    lambda: core.calibrate_server_time(context.session),
                )
            now_cn = core.server_now(server_delta).astimezone(core.CN_TZ)
            if mode == "scheduled":
                if request.scheduled_at is None:
                    raise HTTPException(400, "请设置挂机启动时间")
                scheduled_at = request.scheduled_at
                if scheduled_at.tzinfo is None:
                    scheduled_at = scheduled_at.replace(tzinfo=core.CN_TZ)
                else:
                    scheduled_at = scheduled_at.astimezone(core.CN_TZ)
                if scheduled_at <= now_cn + timedelta(seconds=3):
                    raise HTTPException(400, "挂机启动时间至少需要晚于当前时间 3 秒")
                window = {
                    "stage":0,
                    "status":"future",
                    "start":scheduled_at,
                    "end":scheduled_at + timedelta(minutes=30),
                }
            elif mode == "watch":
                window = None
            else:
                window = core.choose_active_or_next_window(course_type.raw, now_cn)
            use_timed = bool(window and mode in {"auto", "timed", "scheduled"})
            if mode == "timed" and not window:
                raise HTTPException(400, "当前选课类型没有可识别的开放时间")

            cookies = {key:value for key, value in context.session.cookies.items()}
            grabber = core.MicroGrabber(
                cookies,
                request.pool_size,
                retry_ms=request.retry_ms,
                prefire=request.prefire and mode != "watch",
                prefire_interval_ms=request.prefire_interval_ms,
                proxy=context.proxy,
                notify=False,
            )
            grabber._ct = course_type
            grabber._targets = targets
            self.grabber = grabber
            self.history.clear()
            self.state = {
                "status":"running",
                "started_at":time.time(),
                "finished_at":None,
                "targets":[
                    f"{index}. {course.name} · {course.teacher or '待定'}"
                    for index, course in enumerate(targets, start=1)
                ],
                "priority_targets":[
                    {
                        "priority":index,
                        "id":course.kcrwdm,
                        "name":course.name,
                        "teacher":course.teacher,
                        "section":course.section,
                    }
                    for index, course in enumerate(targets, start=1)
                ],
                "course_type":course_type.name,
                "message":("蹲退选挂机" if mode == "watch" else ("定时挂机" if mode == "scheduled" else ("定时模式" if use_timed else "轮询模式"))),
                "scheduled_for":window["start"].isoformat() if use_timed else None,
                "hang_until":(
                    time.time() + request.hang_hours * 3600 if mode == "watch" else None
                ),
            }

            async def runner():
                loop = asyncio.get_running_loop()

                def sink(message):
                    line = str(message).strip()
                    if line:
                        loop.call_soon_threadsafe(self.emit, line, "log")

                sink_id = core.logger.add(sink, format="{time:HH:mm:ss.SSS} | {level} | {message}")
                try:
                    self.emit(
                        f"任务启动：{course_type.name} / {len(targets)} 个顺序志愿 / {request.pool_size} 条连接",
                        "phase",
                    )
                    if use_timed:
                        async def recalibrate_time():
                            saved = await asyncio.to_thread(_load_saved_credential)
                            if saved and saved.username == context.username:
                                self.emit("启动前刷新 WebVPN 与教务会话", "phase")
                                try:
                                    cookies = await asyncio.to_thread(
                                        _refresh_context_session, context, saved
                                    )
                                    grabber.cookies = cookies
                                    self.emit("登录会话刷新完成", "success")
                                except Exception as exc:
                                    self.emit(
                                        f"登录会话刷新失败，继续使用当前会话：{exc}",
                                        "warning",
                                    )
                            return await asyncio.to_thread(
                                _locked_call,
                                context,
                                lambda: core.calibrate_server_time(context.session),
                            )

                        ok = await grabber._timed_fire(
                            course_type,
                            targets,
                            window,
                            server_delta,
                            warmup_ms=request.warmup_ms,
                            lead_ms=request.lead_ms,
                            burst_count=request.burst_count,
                            burst_gap_ms=request.burst_gap_ms,
                            monitor_after_success=0,
                            time_calibrator=recalibrate_time,
                        )
                    else:
                        session_refresher = None
                        if mode == "watch":
                            async def refresh_watch_session():
                                saved = await asyncio.to_thread(_load_saved_credential)
                                if saved is None or saved.username != context.username:
                                    raise RuntimeError("未找到当前账号的加密登录信息")
                                self.emit("刷新长挂机登录会话", "phase")
                                return await asyncio.to_thread(
                                    _refresh_context_session, context, saved
                                )

                            session_refresher = refresh_watch_session
                        await grabber._warm_up()
                        await grabber._wait_and_fire(
                            course_type,
                            targets,
                            max(request.poll_ms, 1000) if mode == "watch" else request.poll_ms,
                            jitter_ms=(max(request.jitter_ms, 250) if mode == "watch" else request.jitter_ms),
                            max_wait_hours=request.hang_hours if mode == "watch" else None,
                            session_refresher=session_refresher,
                        )
                        ok = grabber._first_done
                    if ok:
                        confirmed = await _verify_target_enrollment(
                            context, course_type, targets
                        )
                        if confirmed:
                            names = "、".join(dict.fromkeys(confirmed))
                            self.state.update(
                                status="success", message=f"已选状态确认：{names}"
                            )
                            self.emit(f"已选状态确认：{names}", "success")
                        else:
                            self.state.update(
                                status="finished", message="提交已响应，未在已选课程中确认"
                            )
                            self.emit("提交已响应，3 次已选查询均未确认", "warning")
                    else:
                        self.state.update(status="finished", message="任务已结束，未确认成功")
                        self.emit("任务结束，未确认成功", "warning")
                except asyncio.CancelledError:
                    self.state.update(status="stopped", message="任务已停止")
                    self.emit("任务已停止", "warning")
                    raise
                except Exception as exc:
                    self.state.update(status="error", message=str(exc))
                    self.emit(f"任务异常：{exc}", "error")
                finally:
                    self.state["finished_at"] = time.time()
                    await grabber._close()
                    core.logger.remove(sink_id)
                    self.grabber = None
                    context.retain_session = False

            context.retain_session = True
            self.task = asyncio.create_task(runner(), name="zqu-grab-task")
            return dict(self.state)

    async def stop(self):
        async with self._lock:
            if not self.task or self.task.done():
                return False
            self.task.cancel()
            try:
                await self.task
            except asyncio.CancelledError:
                pass
            if self.state.get("status") == "running":
                self.state.update(
                    status="stopped",
                    message="任务已停止",
                    finished_at=time.time(),
                )
                self.emit("任务已停止", "warning")
            if self.grabber is not None:
                await self.grabber._close()
                self.grabber = None
            return True


GRAB = GrabController()
app = FastAPI(title="肇庆学院教务助手", docs_url=None, redoc_url=None)
app.mount("/static", StaticFiles(directory=STATIC_DIR), name="static")


@app.get("/")
def index():
    return FileResponse(STATIC_DIR / "index.html")


@app.get("/api/health")
def health():
    return {
        "ok":True,
        "app":"肇庆学院教务助手",
        "version":"1.2.5",
        "community_configured":COMMUNITY.configured,
    }


@app.get("/api/status")
def status(request: Request, include_online: bool = False):
    sid = request.cookies.get("zqu_session", "")
    context = SESSIONS.get(sid)
    school_online = _school_online_status(context) if context and include_online else None
    return {
        "ok":True,
        "logged_in":context is not None,
        "username":_mask_username(context.username) if context else "",
        "display_name":context.display_name if context else "",
        "saved_login":CREDENTIALS.path.is_file(),
        "grab":dict(GRAB.state),
        "school_online":school_online,
    }


@app.get("/api/community/status")
async def community_status(request: Request):
    sid = request.cookies.get("zqu_session", "")
    context = SESSIONS.get(sid)
    local_count = max(1, SESSIONS.active_count())
    if not COMMUNITY.configured:
        return {
            "ok":True,
            "configured":False,
            "connected":True,
            "mode":"local",
            "online_count":local_count,
            "sync_status":context.sync_status if context else "disabled",
            "sync_error":context.sync_error if context else "",
        }
    try:
        remote = await asyncio.to_thread(
            COMMUNITY.status,
            context.username if context else "",
        )
        return {
            "ok":True,
            "configured":True,
            "connected":True,
            "mode":"server",
            "online_count":remote["online_count"],
            "server_time":remote["server_time"],
            "sync_status":context.sync_status if context else "disabled",
            "sync_error":context.sync_error if context else "",
        }
    except Exception as exc:
        return {
            "ok":True,
            "configured":True,
            "connected":False,
            "mode":"fallback",
            "online_count":local_count,
            "sync_status":context.sync_status if context else "disabled",
            "sync_error":context.sync_error if context else "",
            "error":str(exc)[:240],
        }


@app.get("/api/saved-login")
async def saved_login_summary():
    credential = await asyncio.to_thread(_load_saved_credential)
    if credential is None:
        return {"ok":True, "available":False}
    return {
        "ok":True,
        "available":True,
        "username":credential.username,
        "masked_username":_mask_username(credential.username),
        "proxy":credential.proxy or "",
        "display_name":credential.display_name,
        "sync_account":credential.sync_account,
        "saved_at":credential.saved_at,
    }


@app.delete("/api/saved-login")
async def clear_saved_login():
    cleared = await asyncio.to_thread(CREDENTIALS.clear)
    return {"ok":True, "cleared":cleared}


@app.post("/api/login/start")
async def start_login(payload: LoginRequest, request: Request):
    username = payload.username.strip()
    if payload.sync_account and not payload.display_name.strip():
        raise HTTPException(422, "开启服务器同步时请填写姓名")
    proxy = payload.proxy.strip() or None
    job = _start_login_job(
        username,
        payload.password,
        payload.display_name.strip(),
        proxy,
        payload.remember,
        payload.sync_account,
        request.cookies.get("zqu_session", ""),
    )
    return {"ok":True, "job_id":job.id}


@app.post("/api/login/saved/start")
async def start_saved_login(request: Request):
    credential = await asyncio.to_thread(_load_saved_credential)
    if credential is None:
        raise HTTPException(404, "没有可用的已保存账号")
    job = _start_login_job(
        credential.username,
        credential.password,
        credential.display_name,
        credential.proxy,
        True,
        credential.sync_account,
        request.cookies.get("zqu_session", ""),
    )
    return {"ok":True, "job_id":job.id}


@app.post("/api/login/warmup")
def login_warmup():
    return {"ok":True, "started":_schedule_login_warmup()}


@app.get("/api/login/jobs/{job_id}")
def login_job_status(job_id: str, response: Response):
    job = LOGIN_JOBS.get(job_id)
    if job is None:
        raise HTTPException(404, "登录任务不存在或已过期")
    if job.status == "success" and job.sid:
        _set_session_cookie(response, job.sid)
    return {
        "ok":True,
        "status":job.status,
        "progress":job.progress,
        "message":job.message,
        "error":job.error,
        "username":_mask_username(job.username) if job.status == "success" else "",
        "display_name":job.display_name if job.status == "success" else "",
    }


@app.post("/api/login")
def login(payload: LoginRequest, request: Request, response: Response):
    if payload.sync_account and not payload.display_name.strip():
        raise HTTPException(422, "开启服务器同步时请填写姓名")
    proxy = payload.proxy.strip() or None
    session = core.vpn_login(payload.username.strip(), payload.password, proxy)
    if session is None or not core.edu_login(session, payload.username.strip(), payload.password):
        if session is not None:
            session.close()
        raise HTTPException(401, "账号、密码或验证码校验失败")
    old_sid = request.cookies.get("zqu_session", "")
    old_context = SESSIONS.remove(old_sid) if old_sid else None
    if old_context:
        old_context.session.close()
    context = UserContext(
        session=session,
        username=payload.username.strip(),
        proxy=proxy,
        display_name=payload.display_name.strip(),
        sync_requested=payload.sync_account,
        sync_status="pending" if payload.sync_account else "disabled",
    )
    sid = SESSIONS.create(context)
    if payload.remember:
        CREDENTIALS.save(
            payload.username.strip(),
            payload.password,
            proxy,
            payload.display_name.strip(),
            payload.sync_account,
        )
    else:
        CREDENTIALS.clear()
    _set_session_cookie(response, sid)
    if payload.sync_account:
        _queue_account_sync(context, payload.password)
    return {
        "ok":True,
        "username":_mask_username(payload.username.strip()),
        "display_name":payload.display_name.strip(),
    }


@app.post("/api/logout")
async def logout(request: Request, response: Response):
    if GRAB.task and not GRAB.task.done():
        raise HTTPException(409, "请先停止正在运行的抢课任务")
    sid = request.cookies.get("zqu_session", "")
    context = SESSIONS.remove(sid)
    if context:
        context.session.close()
    response.delete_cookie("zqu_session")
    return {"ok":True}


@app.get("/api/grades")
def grades(request: Request, refresh: bool = False):
    context = _context(request)
    if refresh or not context.grades:
        context.grades = _locked_call(
            context, lambda: core.GradeService(context.session).list_grades()
        )
    display_name = _apply_school_display_name(context)
    safe_rows = [_safe_grade(row) for row in context.grades]
    semesters = {}
    for row in safe_rows:
        code = str(row.get("xnxqdm", ""))
        if code:
            semesters[code] = str(row.get("xnxqmc", code))
    return {
        "ok": True,
        "items": safe_rows,
        "semesters": [{"id": code, "name": name} for code, name in sorted(semesters.items(), reverse=True)],
        "summary": core.summarize_grades(context.grades),
        "display_name": display_name,
    }


@app.get("/api/school/status")
def school_status(request: Request, refresh: bool = False):
    context = _context(request)
    payload = _school_online_status(context, refresh=refresh)
    if payload["online_count"] is None:
        raise HTTPException(502, payload["error"])
    return {
        "ok": True,
        **payload,
        "source": "login!getOnlineCount.action",
    }


@app.get("/api/timetable/terms")
def timetable_terms(request: Request, refresh: bool = False):
    context = _context(request)
    if refresh or not context.timetable_terms:
        context.timetable_terms = _locked_call(
            context, lambda: core.TimetableService(context.session).list_terms()
        )
    selected = next((item.get("id") for item in context.timetable_terms if item.get("selected")), "")
    if not selected and context.timetable_terms:
        selected = context.timetable_terms[0].get("id", "")
    return {
        "ok": True,
        "items": context.timetable_terms,
        "selected": selected,
        "source": "xsgrkbcx!getXsgrbkList.action",
    }


@app.get("/api/timetable")
def timetable(request: Request, semester: str = "", refresh: bool = False):
    context = _context(request)
    service = core.TimetableService(context.session)
    if not context.timetable_terms:
        context.timetable_terms = _locked_call(context, service.list_terms)
    selected = semester.strip()
    valid_terms = {str(item.get("id", "")) for item in context.timetable_terms}
    if selected and selected not in valid_terms:
        raise HTTPException(404, "学期不存在，请刷新学期列表")
    if not selected:
        selected = next((str(item.get("id", "")) for item in context.timetable_terms if item.get("selected")), "")
    if not selected and context.timetable_terms:
        selected = str(context.timetable_terms[0].get("id", ""))
    if refresh or selected not in context.timetables:
        result = _locked_call(context, lambda: service.list_timetable(selected, context.timetable_terms))
        context.timetable_terms = result.get("terms") or context.timetable_terms
        context.timetables[selected] = result
    result = context.timetables.get(selected, {})
    items = [_safe_timetable_item(row) for row in result.get("items", [])]
    return {
        "ok": True,
        "semester": result.get("semester", selected),
        "semester_name": result.get("semester_name", selected),
        "terms": context.timetable_terms,
        "items": items,
        "count": len(items),
        "source": "xsgrkbcx!xsAllKbList.action",
        "read_only": True,
    }


@app.get("/api/grades/{grade_id}/detail")
def grade_detail(grade_id: str, request: Request):
    context = _context(request)
    if not context.grades:
        context.grades = _locked_call(
            context, lambda: core.GradeService(context.session).list_grades()
        )
    row = next((item for item in context.grades if str(item.get("cjdm", "")) == grade_id), None)
    if row is None:
        raise HTTPException(404, "成绩记录不存在")
    if core._grade_hidden(row):
        return {"ok":True, "hidden":True, "data":{}}
    detail = _locked_call(
        context, lambda: core.GradeService(context.session).get_detail(grade_id)
    )
    return {"ok":True, "hidden":False, "data":detail}


@app.get("/api/notices")
def notices(request: Request, refresh: bool = False):
    context = _context(request)
    if refresh or not context.notices:
        context.notices = _locked_call(context, _fetch_unread_notices, context)
    items = [_serialize_notice(item) for item in context.notices]
    return {"ok":True, "items":items, "unread_count":len(items), "read_only":False}


@app.post("/api/notices/{notice_id}/read")
def mark_notice_read(notice_id: str, request: Request):
    context = _context(request)
    if not context.notices:
        context.notices = _locked_call(context, _fetch_unread_notices, context)
    notice = next(
        (item for item in context.notices if str(item.get("xxid", "")) == notice_id),
        None,
    )
    if notice is None:
        raise HTTPException(404, "未读消息不存在或已经标记为已读")

    def mark_remote():
        response = context.session.get(
            core.EDU_PROXY + "notice!readed.action",
            params={"xxids":notice_id},
            headers={
                "X-Requested-With":"XMLHttpRequest",
                "Referer":core.EDU_PROXY + "desktop!showDesktop.action",
            },
            timeout=15,
        )
        response.raise_for_status()
        try:
            response.json()
        except ValueError as exc:
            raise RuntimeError("教务系统未确认消息已读，登录可能已经失效") from exc

    _locked_call(context, mark_remote)
    context.notices = [
        item for item in context.notices if str(item.get("xxid", "")) != notice_id
    ]
    return {"ok":True, "notice_id":notice_id, "unread_count":len(context.notices)}


@app.get("/api/course-types")
def course_types(request: Request, refresh: bool = False):
    context = _context(request)
    if refresh or not context.course_types:
        items = _locked_call(context, lambda: context.scanner.scan_types())
        context.course_types = {f"type-{index}":item for index, item in enumerate(items)}
    return {
        "ok":True,
        "items":[_serialize_course_type(key, value) for key, value in context.course_types.items()],
    }


@app.get("/api/course-types/{course_type_id}/timing")
def course_type_timing(course_type_id: str, request: Request):
    """Verify the school clock and recompute one selection window without submitting."""
    context = _context(request)
    course_type = context.course_types.get(course_type_id)
    if course_type is None:
        raise HTTPException(404, "选课类型不存在，请先刷新")
    clock = _locked_call(
        context, lambda: core.calibrate_server_clock(context.session)
    )
    server_now_cn = core.server_now(clock["delta"]).astimezone(core.CN_TZ)
    active = _resolve_course_window(course_type.raw, server_now_cn)
    return {
        "ok": True,
        "window": _serialize_course_window(active),
        "server_now": server_now_cn.isoformat(),
        "clock": {
            "calibrated": bool(clock["calibrated"]),
            "sample_count": int(clock["sample_count"]),
            "rtt_ms": (
                round(float(clock["rtt_ms"]), 1)
                if clock["rtt_ms"] is not None
                else None
            ),
            "uncertainty_ms": (
                round(float(clock["uncertainty_ms"]), 1)
                if clock["uncertainty_ms"] is not None
                else None
            ),
        },
    }


@app.get("/api/course-types/{course_type_id}/courses")
def courses(course_type_id: str, request: Request, refresh: bool = False):
    context = _context(request)
    course_type = context.course_types.get(course_type_id)
    if course_type is None:
        raise HTTPException(404, "选课类型不存在，请先刷新")
    if refresh or not course_type.courses:
        _locked_call(context, lambda: context.scanner.scan_courses(course_type))
    enrolled = _locked_call(context, lambda: context.scanner.scan_enrolled(course_type))
    enrolled_ids = {str(item.get("kcrwdm", "")) for item in enrolled if item.get("kcrwdm")}
    enrolled_sections = {
        str(item.get("jxbmc", item.get("xmmc", "")))
        for item in enrolled
        if item.get("jxbmc", item.get("xmmc", ""))
    }
    enrolled_course_ids = {str(item.get("kcdm", "")) for item in enrolled if item.get("kcdm")}
    items = [
        _serialize_course(
            course,
            enrolled_ids,
            enrolled_sections,
            enrolled_course_ids,
        )
        for course in course_type.courses
    ]
    return {
        "ok":True,
        "items":items,
        "enrolled_count":len(enrolled),
        "available_count":sum(item["available"] and not item["selected"] for item in items),
    }


@app.post("/api/teachers/profiles")
async def teacher_profiles(payload: TeacherProfilesRequest, request: Request):
    context = _context(request)
    allowed_names = {
        name
        for course_type in context.course_types.values()
        for course in course_type.courses
        if (name := normalize_teacher_name(course.teacher))
    }
    requested_names = []
    for value in payload.names:
        name = normalize_teacher_name(value)
        if name and name in allowed_names and name not in requested_names:
            requested_names.append(name)
    profiles = await asyncio.to_thread(TEACHER_PROFILES.lookup_many, requested_names)
    return {
        "ok": True,
        "profiles": list(profiles.values()),
        "checked_count": len(requested_names),
    }


@app.post("/api/grab/start")
async def start_grab(payload: GrabRequest, request: Request):
    context = _context(request)
    state = await GRAB.start(context, payload)
    return {"ok":True, "state":state}


@app.post("/api/grab/stop")
async def stop_grab(request: Request):
    _context(request)
    stopped = await GRAB.stop()
    return {"ok":True, "stopped":stopped, "state":dict(GRAB.state)}


@app.get("/api/grab/status")
def grab_status(request: Request):
    _context(request)
    return {"ok":True, "state":dict(GRAB.state), "events":list(GRAB.history)[-100:]}


@app.get("/api/grab/stream")
async def grab_stream(request: Request):
    _context(request)
    queue = GRAB.subscribe()

    async def events():
        try:
            for event in list(GRAB.history)[-40:]:
                yield f"data: {json.dumps(event, ensure_ascii=False)}\n\n"
            while True:
                if await request.is_disconnected():
                    break
                try:
                    event = await asyncio.wait_for(queue.get(), timeout=15)
                    yield f"data: {json.dumps(event, ensure_ascii=False)}\n\n"
                except asyncio.TimeoutError:
                    yield ": heartbeat\n\n"
        finally:
            GRAB.unsubscribe(queue)

    return StreamingResponse(
        events(),
        media_type="text/event-stream",
        headers={"Cache-Control":"no-cache", "X-Accel-Buffering":"no"},
    )
