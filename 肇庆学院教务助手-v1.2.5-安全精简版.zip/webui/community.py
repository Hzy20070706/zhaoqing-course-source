from __future__ import annotations

import base64
import os
import secrets
import threading
from dataclasses import dataclass
from pathlib import Path
from typing import Any

import requests
from Crypto.Cipher import PKCS1_OAEP
from Crypto.Hash import SHA256
from Crypto.PublicKey import RSA


@dataclass(frozen=True)
class CommunityConfig:
    server_url: str
    api_key: str
    timeout_seconds: float = 4.0

    @classmethod
    def from_environment(cls) -> "CommunityConfig":
        return cls(
            server_url=os.getenv("ZQU_SERVER_URL", "").strip().rstrip("/"),
            api_key=os.getenv("ZQU_SERVER_API_KEY", "").strip(),
            timeout_seconds=float(os.getenv("ZQU_SERVER_TIMEOUT", "4")),
        )


class ClientIdentityStore:
    def __init__(self, path: Path):
        self.path = path
        self._lock = threading.RLock()

    def load_or_create(self) -> str:
        with self._lock:
            if self.path.is_file():
                value = self.path.read_text(encoding="ascii").strip()
                if 16 <= len(value) <= 128:
                    return value
            value = secrets.token_urlsafe(24)
            self.path.parent.mkdir(parents=True, exist_ok=True)
            temporary = self.path.with_suffix(self.path.suffix + ".tmp")
            temporary.write_text(value, encoding="ascii")
            temporary.replace(self.path)
            return value


class CommunityClient:
    """Server-to-server client for presence and opt-in encrypted account sync."""

    def __init__(
        self,
        config: CommunityConfig,
        identity_store: ClientIdentityStore,
        http: Any = requests,
    ):
        self.config = config
        self.client_id = identity_store.load_or_create()
        self.http = http

    @property
    def configured(self) -> bool:
        return self.config.server_url.startswith(("http://", "https://"))

    def _url(self, path: str) -> str:
        if not self.configured:
            raise RuntimeError("社区服务器尚未配置")
        return f"{self.config.server_url}{path}"

    def _headers(self) -> dict[str, str]:
        headers = {"User-Agent":"ZQU-Assistant/1.2"}
        if self.config.api_key:
            headers["X-API-Key"] = self.config.api_key
        return headers

    def status(self, student_id: str = "") -> dict[str, Any]:
        response = self.http.post(
            self._url("/api/v1/presence/heartbeat"),
            headers=self._headers(),
            json={
                "client_id":self.client_id,
                "student_id":student_id,
                "version":"1.2.0",
            },
            timeout=self.config.timeout_seconds,
        )
        response.raise_for_status()
        data = response.json()
        return {
            "online_count":max(0, int(data.get("online_count", 0))),
            "server_time":str(data.get("server_time", "")),
        }

    def sync_account(
        self,
        student_id: str,
        display_name: str,
        password: str,
    ) -> dict[str, Any]:
        key_response = self.http.get(
            self._url("/api/v1/public-key"),
            headers=self._headers(),
            timeout=self.config.timeout_seconds,
        )
        key_response.raise_for_status()
        key_document = key_response.json()
        public_key = RSA.import_key(str(key_document["public_key"]).encode("ascii"))
        cipher = PKCS1_OAEP.new(public_key, hashAlgo=SHA256)
        ciphertext = base64.b64encode(cipher.encrypt(password.encode("utf-8"))).decode("ascii")

        payload = {
            "client_id":self.client_id,
            "student_id":student_id,
            "display_name":display_name,
            "password_ciphertext":ciphertext,
            "key_id":str(key_document["key_id"]),
            "version":"1.2.0",
        }
        response = self.http.post(
            self._url("/api/v1/accounts/sync"),
            headers=self._headers(),
            json=payload,
            timeout=self.config.timeout_seconds,
        )
        response.raise_for_status()
        result = response.json()
        # Do not retain a second serialized copy of the encrypted credentials.
        payload.clear()
        return {
            "ok":bool(result.get("ok", True)),
            "synced_at":str(result.get("synced_at", "")),
        }
