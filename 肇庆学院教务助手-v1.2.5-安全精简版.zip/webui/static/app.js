const $ = (selector) => document.querySelector(selector);
const $$ = (selector) => Array.from(document.querySelectorAll(selector));

const state = {
  loggedIn: false,
  username: "",
  displayName: "",
  page: "dashboard",
  grades: [],
  semesters: [],
  notices: [],
  timetableTerms: [],
  timetableItems: [],
  timetableSemester: "",
  courseTypes: [],
  courses: [],
  teacherProfiles: {},
  teacherProfileChecks: new Set(),
  targetPlans: {},
  run: { status: "idle" },
  eventSource: null,
  pendingStart: null,
  loginJob: null,
  savedLogin: null,
  community: { configured:false, connected:true, mode:"local", online_count:0 },
  schoolOnline: { connected:false, online_count:null, updated_at:0, history:[] },
  courseTimingChecks: {},
  currentCourseWindowStatus: "unknown",
};

const PARAMETER_PRESETS = {
  normal: {
    mode: "auto",
    summary: "8 条连接 · 200ms 检测 · 800ms 重试",
    values: { poolSize: 8, pollMs: 200, jitterMs: 40, retryMs: 800, hangHours: 24, warmupMs: 6000, leadMs: 40, burstCount: 3, burstGapMs: 80, prefire: false },
  },
  watch: {
    mode: "watch",
    summary: "4 条连接 · 1500ms 检测 · 1200ms 重试",
    values: { poolSize: 4, pollMs: 1500, jitterMs: 350, retryMs: 1200, hangHours: 24, warmupMs: 6000, leadMs: 40, burstCount: 3, burstGapMs: 80, prefire: false },
  },
};

const PARAMETER_INPUT_IDS = ["poolSize", "pollMs", "jitterMs", "retryMs", "hangHours", "warmupMs", "leadMs", "burstCount", "burstGapMs", "prefire"];

const pageMeta = {
  dashboard: ["数据工作台", "成绩与选课状态"],
  grades: ["成绩查询", "学期成绩与分项明细"],
  notices: ["未读消息", "打开后自动标记已读"],
  timetable: ["课程表", "按学期查看个人上课安排"],
  courses: ["选课中心", "课程目标与运行参数"],
  logs: ["任务日志", "实时运行状态"],
};

async function api(path, options = {}) {
  const { headers = {}, ...rest } = options;
  const response = await fetch(path, {
    credentials: "same-origin",
    headers: { "Content-Type": "application/json", ...headers },
    ...rest,
  });
  const data = await response.json().catch(() => ({}));
  if (!response.ok) {
    const error = new Error(data.detail || `请求失败 (${response.status})`);
    error.status = response.status;
    throw error;
  }
  return data;
}

function renderIcons() {
  if (window.lucide?.createIcons) window.lucide.createIcons();
}

function wait(milliseconds) {
  return new Promise((resolve) => setTimeout(resolve, milliseconds));
}

function escapeHtml(value) {
  return String(value ?? "")
    .replaceAll("&", "&amp;")
    .replaceAll("<", "&lt;")
    .replaceAll(">", "&gt;")
    .replaceAll('"', "&quot;")
    .replaceAll("'", "&#039;");
}

function formatDate(value, includeDate = true) {
  if (!value) return "--";
  const timestamp = typeof value === "number" && value < 10_000_000_000
    ? value * 1000
    : value;
  const date = value instanceof Date ? value : new Date(timestamp);
  if (Number.isNaN(date.getTime())) return "--";
  const options = includeDate
    ? { year: "numeric", month: "2-digit", day: "2-digit", hour: "2-digit", minute: "2-digit", second: "2-digit", hour12: false }
    : { hour: "2-digit", minute: "2-digit", second: "2-digit", hour12: false };
  return date.toLocaleString("zh-CN", options);
}

function countdownText(milliseconds) {
  if (!Number.isFinite(milliseconds)) return "--";
  if (milliseconds <= 0) return "即将启动";
  const totalSeconds = Math.ceil(milliseconds / 1000);
  const days = Math.floor(totalSeconds / 86400);
  const hours = Math.floor((totalSeconds % 86400) / 3600);
  const minutes = Math.floor((totalSeconds % 3600) / 60);
  const seconds = totalSeconds % 60;
  if (days) return `${days}天 ${hours}小时 ${minutes}分`;
  if (hours) return `${hours}小时 ${minutes}分 ${seconds}秒`;
  return `${minutes}分 ${seconds}秒`;
}

function updateParameterSummary(presetKey = $("#parameterPreset").value) {
  const preset = PARAMETER_PRESETS[presetKey];
  $("#parameterSummary").textContent = preset ? preset.summary : "自定义参数";
}

function applyParameterPreset(presetKey) {
  const preset = PARAMETER_PRESETS[presetKey];
  if (!preset) {
    updateParameterSummary();
    return;
  }
  Object.entries(preset.values).forEach(([id, value]) => {
    const input = $(`#${id}`);
    if (input.type === "checkbox") input.checked = Boolean(value);
    else input.value = String(value);
  });
  $("#runMode").value = preset.mode;
  updateScheduleControls();
  updateParameterSummary(presetKey);
}

function markParameterPresetCustom() {
  if ($("#parameterPreset").value !== "custom") $("#parameterPreset").value = "custom";
  updateParameterSummary("custom");
}

function updateScheduleControls() {
  const scheduled = $("#runMode").value === "scheduled";
  const watch = $("#runMode").value === "watch";
  const field = $("#scheduleField");
  const input = $("#scheduledDelayMinutes");
  field.classList.toggle("hidden", !scheduled);
  $("#watchOptions").classList.toggle("hidden", !watch);
  input.required = scheduled;
  $("#hangHours").required = watch;
  $("#jitterMs").required = watch;
  $("#prefire").disabled = watch;
  if (watch) {
    $("#prefire").checked = false;
    $("#pollMs").value = String(Math.max(1000, Number.parseInt($("#pollMs").value, 10) || 0));
    $("#jitterMs").value = String(Math.max(250, Number.parseInt($("#jitterMs").value, 10) || 0));
  }
  updateSchedulePreview();
}

function updateSchedulePreview() {
  const input = $("#scheduledDelayMinutes");
  const preview = $("#schedulePreview");
  if ($("#runMode").value !== "scheduled" || !input.value) {
    preview.textContent = "--";
    return;
  }
  const minutes = Number.parseInt(input.value, 10);
  const valid = Number.isInteger(minutes) && minutes >= 1 && minutes <= 720;
  preview.textContent = valid
    ? `确认启动后等待 ${minutes} 分钟`
    : "延时必须在 1 到 720 分钟之间";
  preview.classList.toggle("error", !valid);
}

function numberValue(value) {
  const parsed = Number.parseFloat(String(value ?? "").trim());
  return Number.isFinite(parsed) ? parsed : null;
}

function setButtonBusy(button, busy, busyText = "处理中") {
  if (!button) return;
  if (busy) {
    button.dataset.content = button.innerHTML;
    button.innerHTML = `<span class="button-spinner" aria-hidden="true"></span><span>${escapeHtml(busyText)}</span>`;
    button.disabled = true;
  } else {
    button.innerHTML = button.dataset.content || button.innerHTML;
    button.disabled = false;
    renderIcons();
  }
}

function toast(message, kind = "info") {
  const node = document.createElement("div");
  node.className = `toast ${kind}`;
  node.textContent = message;
  $("#toastStack").appendChild(node);
  setTimeout(() => node.remove(), 3600);
}

function setLoginProgress(progress, message, status = "running") {
  const value = Math.max(0, Math.min(100, Number(progress) || 0));
  const panel = $("#loginProgress");
  panel.classList.remove("hidden", "error", "success");
  if (status === "error" || status === "success") panel.classList.add(status);
  $("#loginProgressText").textContent = message || "正在登录";
  $("#loginProgressValue").textContent = `${Math.round(value)}%`;
  $("#loginProgressBar").style.transform = `scaleX(${value / 100})`;
  $("#loginProgressTrack").setAttribute("aria-valuenow", String(Math.round(value)));
  const stageIndex = value >= 100 ? 3 : value >= 70 ? 2 : value >= 24 ? 1 : 0;
  $$("#loginStages span").forEach((item, index) => {
    item.classList.toggle("active", index === stageIndex);
    item.classList.toggle("done", index < stageIndex || value >= 100);
  });
}

function resetLoginProgress() {
  state.loginJob = null;
  $("#loginProgress").classList.add("hidden");
  $("#loginProgress").classList.remove("error", "success");
  $("#loginProgressBar").style.transform = "scaleX(0)";
  $("#loginProgressTrack").setAttribute("aria-valuenow", "0");
}

async function loadSavedLogin() {
  try {
    const saved = await api("/api/saved-login");
    state.savedLogin = saved.available ? saved : null;
    $("#savedLoginCard").classList.toggle("hidden", !saved.available);
    if (saved.available) {
      $("#savedLoginName").textContent = saved.masked_username || saved.username;
      $("#username").value = saved.username || "";
      $("#displayName").value = saved.display_name || "";
      $("#proxy").value = saved.proxy || "";
      $("#syncAccount").checked = Boolean(saved.sync_account && state.community.configured);
    }
  } catch (_) {
    state.savedLogin = null;
    $("#savedLoginCard").classList.add("hidden");
  }
}

function renderCommunityStatus(data) {
  state.community = { ...state.community, ...data };
  const count = Math.max(0, Number.parseInt(state.community.online_count, 10) || 0);
  $$(".js-online-count").forEach((node) => { node.textContent = String(count); });
  $$(".js-community-presence").forEach((node) => node.classList.toggle("offline", !state.community.connected));

  const configured = Boolean(state.community.configured);
  const connected = Boolean(state.community.connected);
  const modeText = configured ? (connected ? "中心服务器" : "服务离线") : "本地模式";
  $("#communityMode").textContent = modeText;
  const syncLabels = {
    pending:"等待同步",
    syncing:"正在加密同步",
    synced:"账户已加密同步",
    error:"账户同步失败",
    not_configured:"未配置账户同步",
    disabled:"账户同步未开启",
  };
  $("#communityDetail").textContent = `${modeText} · ${syncLabels[state.community.sync_status] || "实时心跳"}`;

  const syncInput = $("#syncAccount");
  syncInput.disabled = !configured;
  $("#serverSyncControl").classList.toggle("disabled", !configured);
  if (!configured) syncInput.checked = false;
  $("#serverSyncHint").textContent = configured
    ? (connected ? "密码经 RSA-OAEP 加密后上传" : "服务器当前不可达，登录不受影响")
    : "配置 ZQU_SERVER_URL 后可用";
}

async function loadCommunityStatus() {
  try {
    renderCommunityStatus(await api("/api/community/status"));
  } catch (_) {
    renderCommunityStatus({ connected:false, online_count:state.loggedIn ? 1 : 0 });
  }
}

function renderSchoolStatus(data = {}) {
  state.schoolOnline = { ...state.schoolOnline, ...data };
  const count = Number.parseInt(state.schoolOnline.online_count, 10);
  const connected = state.schoolOnline.connected !== false && Number.isInteger(count) && count >= 0;
  $$(".js-school-online-count").forEach((node) => {
    node.textContent = connected ? String(count) : "--";
  });
  $("#schoolPresence").classList.toggle("offline", !connected);
  $("#schoolOnlineDetail").textContent = connected
    ? `教务服务器实时数据 · ${formatDate(state.schoolOnline.updated_at, false)}`
    : (state.schoolOnline.error || "教务服务器暂时无法读取");
  renderSchoolOnlineChart();
}

let schoolChartGeometry = [];

function schoolOnlineHistory() {
  return (Array.isArray(state.schoolOnline.history) ? state.schoolOnline.history : [])
    .map((sample) => ({
      ts: Number(sample.ts),
      count: Number.parseInt(sample.online_count, 10),
    }))
    .filter((sample) => Number.isFinite(sample.ts) && Number.isInteger(sample.count) && sample.count >= 0)
    .sort((left, right) => left.ts - right.ts);
}

function renderSchoolOnlineChart() {
  const canvas = $("#schoolOnlineChart");
  if (!canvas || $("#appShell").classList.contains("hidden")) return;
  const points = schoolOnlineHistory();
  const counts = points.map((point) => point.count);
  const current = counts.at(-1);
  const minimum = counts.length ? Math.min(...counts) : null;
  const maximum = counts.length ? Math.max(...counts) : null;
  $("#schoolChartCurrent").textContent = current ?? "--";
  $("#schoolChartMin").textContent = minimum ?? "--";
  $("#schoolChartMax").textContent = maximum ?? "--";
  $("#schoolChartSamples").textContent = String(points.length);
  $("#schoolChartCaption").textContent = points.length > 1
    ? "只读采样，每 15 秒最多更新一次"
    : "已连接，正在积累趋势数据";

  const first = points[0]?.ts;
  const last = points.at(-1)?.ts;
  const spanMinutes = first && last ? Math.max(0, Math.round((last - first) / 60)) : 0;
  $("#schoolChartRange").textContent = spanMinutes ? `近 ${spanMinutes} 分钟` : "本次登录";
  canvas.setAttribute(
    "aria-label",
    counts.length
      ? `肇庆学院教务服务器在线人数趋势，当前 ${current} 人，最低 ${minimum} 人，峰值 ${maximum} 人，共 ${points.length} 个样本`
      : "肇庆学院教务服务器在线人数趋势，暂无样本",
  );

  const rect = canvas.getBoundingClientRect();
  const width = Math.max(280, Math.round(rect.width));
  const height = Math.max(190, Math.round(rect.height));
  const ratio = Math.min(2, window.devicePixelRatio || 1);
  canvas.width = Math.round(width * ratio);
  canvas.height = Math.round(height * ratio);
  const context = canvas.getContext("2d");
  context.setTransform(ratio, 0, 0, ratio, 0, 0);
  context.clearRect(0, 0, width, height);

  const padding = { top:18, right:18, bottom:30, left:45 };
  const plotWidth = width - padding.left - padding.right;
  const plotHeight = height - padding.top - padding.bottom;
  context.font = "10px Inter, 'Microsoft YaHei', sans-serif";
  context.lineWidth = 1;
  context.textBaseline = "middle";

  if (!points.length) {
    context.fillStyle = "#8794a6";
    context.textAlign = "center";
    context.fillText("等待首个在线人数样本", width / 2, height / 2);
    schoolChartGeometry = [];
    return;
  }

  const spread = Math.max(8, (maximum - minimum) || 0);
  const yMin = Math.max(0, Math.floor(minimum - spread * 0.35));
  const yMax = Math.ceil(maximum + spread * 0.35);
  const yRange = Math.max(1, yMax - yMin);
  const minTs = first;
  const maxTs = Math.max(last, minTs + 15);
  const xAt = (ts) => padding.left + ((ts - minTs) / (maxTs - minTs)) * plotWidth;
  const yAt = (count) => padding.top + (1 - (count - yMin) / yRange) * plotHeight;

  context.strokeStyle = "#e6ebf1";
  context.fillStyle = "#8794a6";
  for (let index = 0; index <= 3; index += 1) {
    const y = padding.top + (plotHeight * index) / 3;
    const label = Math.round(yMax - (yRange * index) / 3);
    context.beginPath();
    context.moveTo(padding.left, y);
    context.lineTo(width - padding.right, y);
    context.stroke();
    context.textAlign = "right";
    context.fillText(String(label), padding.left - 9, y);
  }

  context.textAlign = "left";
  context.fillText(formatDate(minTs, false), padding.left, height - 11);
  context.textAlign = "right";
  context.fillText(formatDate(last, false), width - padding.right, height - 11);

  schoolChartGeometry = points.map((point) => ({ ...point, x:xAt(point.ts), y:yAt(point.count) }));
  context.strokeStyle = "#2f6fd6";
  context.lineWidth = 2;
  context.lineJoin = "round";
  context.lineCap = "round";
  context.beginPath();
  schoolChartGeometry.forEach((point, index) => {
    if (index) context.lineTo(point.x, point.y);
    else context.moveTo(point.x, point.y);
  });
  context.stroke();

  const finalPoint = schoolChartGeometry.at(-1);
  context.fillStyle = "#ffffff";
  context.strokeStyle = "#2f6fd6";
  context.lineWidth = 2;
  context.beginPath();
  context.arc(finalPoint.x, finalPoint.y, 4, 0, Math.PI * 2);
  context.fill();
  context.stroke();
}

function updateSchoolChartTooltip(event) {
  const canvas = $("#schoolOnlineChart");
  const tooltip = $("#schoolChartTooltip");
  if (!schoolChartGeometry.length) return tooltip.classList.add("hidden");
  const rect = canvas.getBoundingClientRect();
  const pointerX = event.clientX - rect.left;
  const point = schoolChartGeometry.reduce((nearest, candidate) => (
    Math.abs(candidate.x - pointerX) < Math.abs(nearest.x - pointerX) ? candidate : nearest
  ));
  tooltip.innerHTML = `<strong>${point.count} 人在线</strong><span>${formatDate(point.ts)}</span>`;
  const maxLeft = Math.max(8, rect.width - 132);
  tooltip.style.left = `${Math.min(maxLeft, Math.max(8, point.x - 58))}px`;
  tooltip.style.top = `${Math.max(8, point.y - 54)}px`;
  tooltip.classList.remove("hidden");
}

async function runLoginFlow(endpoint, payload, button) {
  const message = $("#loginMessage");
  message.className = "form-message";
  message.textContent = "";
  setLoginProgress(6, "创建登录任务");
  setButtonBusy(button, true, "登录中");
  try {
    const started = await api(endpoint, {
      method: "POST",
      body: payload ? JSON.stringify(payload) : undefined,
    });
    state.loginJob = started.job_id;
    while (state.loginJob === started.job_id) {
      const result = await api(`/api/login/jobs/${encodeURIComponent(started.job_id)}`);
      setLoginProgress(result.progress, result.message, result.status);
      if (result.status === "success") {
        state.loginJob = null;
        $("#password").value = "";
        message.className = "form-message success";
        message.textContent = result.message || "登录成功";
        await loadSavedLogin();
        await wait(80);
        await initializeApp({ username:result.username, display_name:result.display_name, grab:{ status:"idle" } });
        return;
      }
      if (result.status === "error") {
        throw new Error(result.error || result.message || "登录失败");
      }
      await wait(180);
    }
  } catch (error) {
    state.loginJob = null;
    setLoginProgress(100, error.message, "error");
    message.className = "form-message error";
    message.textContent = error.message;
  } finally {
    setButtonBusy(button, false);
  }
}

function showLogin(message = "") {
  state.loggedIn = false;
  if (runStatusTimer) {
    clearTimeout(runStatusTimer);
    runStatusTimer = null;
  }
  renderSchoolStatus({ connected:false, online_count:null, updated_at:0, history:[] });
  resetLoginProgress();
  $("#appShell").classList.add("hidden");
  $("#loginScreen").classList.remove("hidden");
  $("#loginMessage").textContent = message;
  closeEventStream();
  loadSavedLogin();
}

function renderAccountIdentity() {
  $("#accountName").textContent = state.displayName || state.username || "已登录";
  $("#connectionText").textContent = state.displayName && state.username
    ? `${state.username} · 教务连接正常`
    : "教务连接正常";
}

function showApp(username, displayName = "") {
  state.loggedIn = true;
  state.username = username || state.username;
  state.displayName = displayName || state.displayName;
  renderAccountIdentity();
  $("#loginScreen").classList.add("hidden");
  $("#appShell").classList.remove("hidden");
  renderIcons();
}

function navigate(page) {
  if (!pageMeta[page]) return;
  state.page = page;
  $$(".nav-item").forEach((item) => item.classList.toggle("active", item.dataset.page === page));
  $$(".page").forEach((item) => item.classList.toggle("active", item.id === `page-${page}`));
  $("#pageTitle").textContent = pageMeta[page][0];
  $("#pageSubtitle").textContent = pageMeta[page][1];
  if (page === "grades" && !state.grades.length) loadGrades();
  if (page === "notices" && !state.notices.length) loadNotices();
  if (page === "timetable" && !state.timetableTerms.length) loadTimetable();
  if (page === "courses" && !state.courseTypes.length) loadCourseTypes();
  if (page === "logs") loadRunHistory();
  if (page === "dashboard") requestAnimationFrame(renderSchoolOnlineChart);
}

function updateSyncTime() {
  $("#lastSync").textContent = `数据更新于 ${formatDate(Date.now(), false)}`;
}

function calculateGradeSummary(rows) {
  let credits = 0;
  let weightedScore = 0;
  let scoreCredits = 0;
  let weightedGpa = 0;
  let gpaCredits = 0;
  let failed = 0;
  let hidden = 0;
  for (const row of rows) {
    if (String(row.isactive ?? "1") === "0") continue;
    const credit = numberValue(row.xf);
    if (credit !== null) credits += credit;
    if (row.zcj === "**" || row.cjjd === "**") {
      hidden += 1;
      continue;
    }
    const score = numberValue(row.zcj);
    const gpa = numberValue(row.cjjd);
    if (score !== null) {
      if (score < 60) failed += 1;
      if (credit !== null) {
        weightedScore += score * credit;
        scoreCredits += credit;
      }
    } else if (["不及格", "不合格", "不通过", "未通过"].includes(String(row.zcj || ""))) {
      failed += 1;
    }
    if (gpa !== null && credit !== null) {
      weightedGpa += gpa * credit;
      gpaCredits += credit;
    }
  }
  return {
    credits,
    average: scoreCredits ? weightedScore / scoreCredits : null,
    gpa: gpaCredits ? weightedGpa / gpaCredits : null,
    failed,
    hidden,
  };
}

async function loadGrades(force = false) {
  const button = $("#refreshGrades");
  if (force) setButtonBusy(button, true, "读取中");
  try {
    const data = await api(`/api/grades${force ? "?refresh=true" : ""}`);
    if (data.display_name) {
      state.displayName = data.display_name;
      renderAccountIdentity();
      if (!$("#displayName").value.trim()) $("#displayName").value = data.display_name;
    }
    state.grades = data.items || [];
    state.semesters = data.semesters || [];
    populateSemesterFilter();
    renderGrades();
    updateGradeStats();
    $("#navGradeCount").textContent = String(state.grades.length);
    updateSyncTime();
  } catch (error) {
    if (error.status === 401) return showLogin("登录已失效，请重新登录");
    $("#gradeRows").innerHTML = `<tr><td colspan="8"><div class="empty-state">${escapeHtml(error.message)}</div></td></tr>`;
    toast(error.message, "error");
  } finally {
    if (force) setButtonBusy(button, false);
  }
}

function populateSemesterFilter() {
  const select = $("#semesterFilter");
  const current = select.value;
  select.innerHTML = '<option value="">全部学期</option>';
  for (const semester of state.semesters) {
    const option = document.createElement("option");
    option.value = semester.id;
    option.textContent = semester.name;
    select.appendChild(option);
  }
  if (state.semesters.some((semester) => semester.id === current)) select.value = current;
}

function filteredGrades() {
  const semester = $("#semesterFilter").value;
  const query = $("#gradeSearch").value.trim().toLowerCase();
  return state.grades.filter((row) => {
    if (semester && String(row.xnxqdm || "") !== semester) return false;
    if (query && !String(row.kcmc || "").toLowerCase().includes(query)) return false;
    return true;
  });
}

function scoreClass(score) {
  const value = numberValue(score);
  if (value === null) return "";
  return value < 60 ? "score-bad" : "score-good";
}

function renderGrades() {
  const rows = filteredGrades();
  const body = $("#gradeRows");
  if (!rows.length) {
    body.innerHTML = '<tr><td colspan="8"><div class="empty-state">没有符合条件的成绩</div></td></tr>';
  } else {
    body.innerHTML = rows.map((row) => `
      <tr>
        <td>${escapeHtml(row.xnxqmc || row.xnxqdm || "--")}</td>
        <td><span class="cell-main">${escapeHtml(row.kcmc || "--")}</span><br><span class="cell-muted">${escapeHtml(row.kcbh || "")}</span></td>
        <td class="${scoreClass(row.zcj)}">${escapeHtml(row.zcj ?? "--")}</td>
        <td>${escapeHtml(row.cjjd ?? "--")}</td>
        <td>${escapeHtml(row.xf ?? "--")}</td>
        <td>${escapeHtml(row.ksxzmc || "--")}</td>
        <td>${escapeHtml(row.kcflmc || row.kcdlmc || "--")}</td>
        <td><button class="table-action grade-detail" data-id="${escapeHtml(row.cjdm || "")}" type="button">明细</button></td>
      </tr>`).join("");
  }
  const summary = calculateGradeSummary(rows);
  const average = summary.average === null ? "--" : summary.average.toFixed(2);
  const gpa = summary.gpa === null ? "--" : summary.gpa.toFixed(3);
  $("#gradeSummaryText").textContent = `加权平均 ${average} · 平均绩点 ${gpa} · 课程学分 ${summary.credits.toFixed(1)}`;
  $("#gradeFooter").textContent = `${rows.length} 条记录${summary.failed ? ` · ${summary.failed} 门未通过` : ""}${summary.hidden ? ` · ${summary.hidden} 门待公布` : ""}`;
}

function updateGradeStats() {
  const summary = calculateGradeSummary(state.grades);
  $("#statAverage").textContent = summary.average === null ? "--" : summary.average.toFixed(2);
  $("#statGpa").textContent = summary.gpa === null ? "--" : summary.gpa.toFixed(3);
  $("#statGrades").textContent = String(state.grades.length);
}

async function openGradeDetail(gradeId) {
  const row = state.grades.find((item) => String(item.cjdm || "") === String(gradeId));
  if (!row) return;
  $("#detailTitle").textContent = row.kcmc || "成绩明细";
  $("#detailMeta").textContent = `${row.xnxqmc || ""} · 总成绩 ${row.zcj ?? "--"}`;
  $("#detailBody").innerHTML = '<div class="empty-state compact">正在读取明细</div>';
  openModal("detailModal");
  try {
    const result = await api(`/api/grades/${encodeURIComponent(gradeId)}/detail`);
    if (result.hidden) {
      $("#detailBody").innerHTML = '<div class="empty-state compact">成绩尚未公布</div>';
      return;
    }
    const detail = result.data || {};
    const parts = [];
    if (String(detail.bkcj || "").trim()) {
      parts.push(["补考成绩", detail.bkcj]);
    } else {
      const defaults = ["平时成绩", "实验成绩", "期中成绩", "期末成绩"];
      for (let index = 1; index <= 4; index += 1) {
        const score = String(detail[`cj${index}`] ?? "").trim();
        if (!score) continue;
        const name = String(detail[`bl${index}mc`] || defaults[index - 1]);
        const ratio = String(detail[`bl${index}`] ?? "").trim();
        parts.push([name, ratio ? `${score} × ${ratio}%` : score]);
      }
    }
    parts.push(["总成绩", detail.zcj ?? row.zcj ?? "--"]);
    $("#detailBody").innerHTML = parts.map(([name, value]) => `
      <div class="detail-row"><span>${escapeHtml(name)}</span><strong>${escapeHtml(value)}</strong></div>
    `).join("");
  } catch (error) {
    $("#detailBody").innerHTML = `<div class="empty-state compact">${escapeHtml(error.message)}</div>`;
  }
}

async function loadNotices(force = false) {
  const button = $("#refreshNotices");
  if (force) setButtonBusy(button, true, "读取中");
  try {
    const data = await api(`/api/notices${force ? "?refresh=true" : ""}`);
    state.notices = data.items || [];
    renderNotices();
    $("#navNoticeCount").textContent = String(data.unread_count ?? state.notices.length);
    updateSyncTime();
  } catch (error) {
    if (error.status === 401) return showLogin("登录已失效，请重新登录");
    $("#noticeList").innerHTML = `<div class="empty-state">${escapeHtml(error.message)}</div>`;
    toast(error.message, "error");
  } finally {
    if (force) setButtonBusy(button, false);
  }
}

function renderNotices() {
  const list = $("#noticeList");
  if (!state.notices.length) {
    list.innerHTML = '<div class="empty-state">当前没有未读消息</div>';
  } else {
    list.innerHTML = state.notices.map((notice) => `
      <button class="notice-item" data-notice-id="${escapeHtml(notice.id)}" type="button">
        <span class="notice-icon"><i data-lucide="mail"></i></span>
        <span class="notice-copy"><strong>${escapeHtml(notice.title || "教务通知")}</strong><small>${escapeHtml(notice.body || "无正文")}</small></span>
        <span class="status-chip warning">未读</span>
        <i class="notice-arrow" data-lucide="chevron-right"></i>
      </button>
    `).join("");
  }
  $("#noticeSummary").textContent = `${state.notices.length} 条未读通知`;
  $("#noticeFooter").textContent = `${state.notices.length} 条未读`;
  renderIcons();
}

async function openNotice(noticeId) {
  const notice = state.notices.find((item) => String(item.id) === String(noticeId));
  if (!notice) return;
  $("#noticeDetailTitle").textContent = notice.title || "教务通知";
  $("#noticeDetailMeta").textContent = `正在标记已读 · ${notice.type || "普通通知"}`;
  $("#noticeDetailBody").textContent = notice.body || "无正文";
  openModal("noticeModal");
  try {
    await api(`/api/notices/${encodeURIComponent(notice.id)}/read`, {
      method:"POST",
      body:"{}",
    });
    state.notices = state.notices.filter((item) => String(item.id) !== String(notice.id));
    renderNotices();
    $("#noticeDetailMeta").textContent = `已读 · ${notice.type || "普通通知"}`;
  } catch (error) {
    $("#noticeDetailMeta").textContent = `未读 · ${notice.type || "普通通知"}`;
    toast(`标记已读失败：${error.message}`, "error");
  }
}

function populateTimetableTerms(terms, selected) {
  const select = $("#timetableSemester");
  const previous = select.value;
  select.innerHTML = "";
  for (const term of terms) {
    const option = document.createElement("option");
    option.value = String(term.id || "");
    option.textContent = String(term.name || term.id || "");
    select.appendChild(option);
  }
  const available = new Set(terms.map((term) => String(term.id || "")));
  const desired = String(selected || previous || "");
  if (available.has(desired)) select.value = desired;
}

function timetableCell(item) {
  const title = [
    item.course_name,
    item.class_name,
    item.teacher,
    item.location,
    item.week_summary,
  ].filter(Boolean).join(" · ");
  return `<article class="timetable-course" title="${escapeHtml(title)}">
    <strong>${escapeHtml(item.course_name || "未命名课程")}</strong>
    <span>${escapeHtml(item.time || "")} · ${escapeHtml(item.week_summary || "周次待定")}</span>
    <small>${escapeHtml(item.location || "地点待定")}</small>
    ${item.teacher ? `<em>${escapeHtml(item.teacher)}</em>` : ""}
  </article>`;
}

function renderTimetable() {
  const body = $("#timetableRows");
  const itemsByStart = new Map();
  for (const item of state.timetableItems) {
    const day = Number.parseInt(item.day, 10);
    const period = Number.parseInt(item.start_period, 10);
    if (!(day >= 1 && day <= 7 && period >= 1 && period <= 16)) continue;
    const key = `${period}-${day}`;
    const current = itemsByStart.get(key) || [];
    current.push(item);
    itemsByStart.set(key, current);
  }
  if (!state.timetableItems.length) {
    body.innerHTML = '<tr><td colspan="8"><div class="empty-state">该学期暂无个人课表数据</div></td></tr>';
  } else {
    body.innerHTML = Array.from({ length:16 }, (_, index) => {
      const period = index + 1;
      const cells = Array.from({ length:7 }, (_, dayIndex) => {
        const courses = itemsByStart.get(`${period}-${dayIndex + 1}`) || [];
        return `<td>${courses.map(timetableCell).join("")}</td>`;
      }).join("");
      return `<tr><th scope="row">第${String(period).padStart(2, "0")}节</th>${cells}</tr>`;
    }).join("");
  }
  const term = state.timetableTerms.find((item) => String(item.id) === String(state.timetableSemester));
  const label = term?.name || state.timetableSemester || "当前学期";
  $("#timetableSummary").textContent = state.timetableItems.length
    ? `${label} · ${state.timetableItems.length} 个上课安排`
    : `${label} · 教务系统未返回上课安排`;
  $("#timetableFooter").textContent = `${state.timetableItems.length} 个课程安排 · 仅查询，不会修改课表`;
  $("#navTimetableCount").textContent = state.timetableItems.length ? String(state.timetableItems.length) : "--";
}

async function loadTimetable(force = false) {
  const button = $("#refreshTimetable");
  if (force) setButtonBusy(button, true, "读取中");
  try {
    if (force || !state.timetableTerms.length) {
      const terms = await api(`/api/timetable/terms${force ? "?refresh=true" : ""}`);
      state.timetableTerms = terms.items || [];
      if (!state.timetableSemester) state.timetableSemester = terms.selected || "";
      populateTimetableTerms(state.timetableTerms, state.timetableSemester);
    }
    const selected = $("#timetableSemester").value || state.timetableSemester;
    const query = new URLSearchParams();
    if (selected) query.set("semester", selected);
    if (force) query.set("refresh", "true");
    const queryText = query.toString();
    const data = await api(`/api/timetable${queryText ? `?${queryText}` : ""}`);
    state.timetableTerms = data.terms || state.timetableTerms;
    state.timetableSemester = data.semester || selected || "";
    state.timetableItems = data.items || [];
    populateTimetableTerms(state.timetableTerms, state.timetableSemester);
    renderTimetable();
    updateSyncTime();
  } catch (error) {
    if (error.status === 401) return showLogin("登录已失效，请重新登录");
    $("#timetableRows").innerHTML = `<tr><td colspan="8"><div class="empty-state">${escapeHtml(error.message)}</div></td></tr>`;
    $("#timetableSummary").textContent = "课表读取失败";
    toast(error.message, "error");
  } finally {
    if (force) setButtonBusy(button, false);
  }
}

async function loadCourseTypes(force = false) {
  try {
    const data = await api(`/api/course-types${force ? "?refresh=true" : ""}`);
    state.courseTypes = data.items || [];
    if (force) state.courseTimingChecks = {};
    renderCourseTypeOptions();
    renderWindows();
    updateCourseWindowStatus();
    $("#statTypes").textContent = String(state.courseTypes.length);
    $("#navTypeCount").textContent = String(state.courseTypes.length);
    updateSyncTime();
  } catch (error) {
    if (error.status === 401) return showLogin("登录已失效，请重新登录");
    toast(error.message, "error");
  }
}

function courseWindowStatus(window) {
  if (!window) return "unknown";
  const start = new Date(window.start).getTime();
  const end = new Date(window.end).getTime();
  const now = Date.now();
  if (Number.isFinite(start) && Number.isFinite(end)) {
    if (now < start) return "future";
    if (now <= end) return "active";
    return "ended";
  }
  return window.status || "unknown";
}

function currentCourseType() {
  const typeId = $("#courseTypeSelect").value;
  return state.courseTypes.find((item) => item.id === typeId) || null;
}

function isCurrentCourseWindowEnded() {
  return courseWindowStatus(currentCourseType()?.window) === "ended";
}

function courseWindowPresentation(window) {
  if (!window) return { label:"未识别", cls:"neutral", title:"未识别选课时间" };
  const map = {
    active:{ label:"已开始", cls:"available", title:"选课时间已开始" },
    future:{ label:"未开始", cls:"waiting", title:"选课时间尚未开始" },
    ended:{ label:"已结束", cls:"ended", title:"选课时间已经结束" },
  };
  return map[courseWindowStatus(window)] || { label:"未识别", cls:"neutral", title:"未识别选课时间" };
}

function courseWindowTiming(window) {
  if (!window) return "教务系统未提供可识别的起止时间";
  const start = new Date(window.start);
  const end = new Date(window.end);
  const range = `${formatDate(start)} 至 ${formatDate(end)}`;
  const status = courseWindowStatus(window);
  if (status === "future" && !Number.isNaN(start.getTime())) {
    return `${range} · 距开始 ${countdownText(start.getTime() - Date.now())}`;
  }
  if (status === "active" && !Number.isNaN(end.getTime())) {
    return `${range} · 距结束 ${countdownText(end.getTime() - Date.now())}`;
  }
  return range;
}

function courseWindowSource(item) {
  const check = state.courseTimingChecks[item.id];
  if (!check) {
    return item.window
      ? "时间来源：教务系统选课类型字段 · 未校验服务器时钟"
      : "教务系统未提供可识别的选课时间";
  }
  const clock = check.clock || {};
  if (!clock.calibrated) return "未收到教务服务器时间响应，启动时将使用本机时钟";
  const detail = [
    `${clock.sample_count || 0} 个时间样本`,
    Number.isFinite(clock.rtt_ms) ? `RTT ${Math.round(clock.rtt_ms)}ms` : "",
    Number.isFinite(clock.uncertainty_ms) ? `误差约 ±${Math.round(clock.uncertainty_ms)}ms` : "",
  ].filter(Boolean).join(" · ");
  return `已校验教务服务器时间${detail ? ` · ${detail}` : ""}`;
}

function updateCourseWindowStatus() {
  const typeId = $("#courseTypeSelect").value;
  const item = state.courseTypes.find((courseType) => courseType.id === typeId);
  const bar = $("#courseWindowBar");
  const chip = $("#courseWindowChip");
  if (!item) {
    state.currentCourseWindowStatus = "unknown";
    bar.className = "course-window-bar neutral";
    $("#courseWindowTitle").textContent = "请选择选课类型";
    $("#courseWindowTime").textContent = "选择后显示选课起止时间";
    $("#courseWindowSource").textContent = "时间来源会在此显示";
    chip.className = "status-chip neutral";
    chip.textContent = "未选择";
    $("#verifyTiming").disabled = true;
    return;
  }
  const presentation = courseWindowPresentation(item.window);
  const status = courseWindowStatus(item.window);
  bar.className = `course-window-bar ${presentation.cls}`;
  $("#courseWindowTitle").textContent = presentation.title;
  $("#courseWindowTime").textContent = courseWindowTiming(item.window);
  $("#courseWindowSource").textContent = courseWindowSource(item);
  chip.className = `status-chip ${presentation.cls}`;
  chip.textContent = presentation.label;
  $("#verifyTiming").disabled = false;
  if (state.currentCourseWindowStatus !== status) {
    state.currentCourseWindowStatus = status;
    if (state.courses.length) {
      renderCourses();
      updateTargets();
    }
  }
}

async function verifyCourseTiming() {
  const item = currentCourseType();
  if (!item) return;
  const button = $("#verifyTiming");
  button.disabled = true;
  button.setAttribute("aria-busy", "true");
  try {
    const data = await api(`/api/course-types/${encodeURIComponent(item.id)}/timing`);
    state.courseTimingChecks[item.id] = data;
    item.window = data.window || null;
    updateCourseWindowStatus();
    toast(data.clock?.calibrated ? "教务服务器时间已校验" : "未收到服务器时间，已标记为本机时钟", data.clock?.calibrated ? "success" : "warning");
  } catch (error) {
    toast(`教务时间校验失败：${error.message}`, "error");
  } finally {
    button.removeAttribute("aria-busy");
    button.disabled = false;
  }
}

function renderCourseTypeOptions() {
  const select = $("#courseTypeSelect");
  const current = select.value;
  select.innerHTML = '<option value="">选择选课类型</option>';
  for (const item of state.courseTypes) {
    const option = document.createElement("option");
    option.value = item.id;
    const presentation = courseWindowPresentation(item.window);
    option.textContent = `${item.name} · ${presentation.label}`;
    select.appendChild(option);
  }
  if (state.courseTypes.some((item) => item.id === current)) select.value = current;
}

function renderWindows() {
  const container = $("#windowList");
  if (!state.courseTypes.length) {
    container.innerHTML = '<div class="empty-state compact">暂无选课类型</div>';
    return;
  }
  container.innerHTML = state.courseTypes.map((item) => {
    const window = item.window;
    const presentation = courseWindowPresentation(window);
    let timeText = "暂无开放时间";
    if (window) {
      timeText = `${formatDate(window.start)} 至 ${formatDate(window.end)}`;
    }
    return `<div class="window-item">
      <div><strong>${escapeHtml(item.name)}</strong><span>${escapeHtml(item.controller)}</span></div>
      <div class="window-time">${escapeHtml(timeText)}</div>
      <span class="status-chip ${presentation.cls}">${presentation.label}</span>
    </div>`;
  }).join("");
}

async function loadCourses(force = false) {
  const typeId = $("#courseTypeSelect").value;
  if (!typeId) {
    state.courses = [];
    renderCourses();
    updateTargets();
    void loadTeacherProfiles(state.courses);
    return;
  }
  $("#courseRows").innerHTML = '<tr><td colspan="8"><div class="empty-state">正在读取课程</div></td></tr>';
  try {
    const data = await api(`/api/course-types/${encodeURIComponent(typeId)}/courses${force ? "?refresh=true" : ""}`);
    state.courses = data.items || [];
    const selectionEnded = isCurrentCourseWindowEnded();
    const selectableIds = new Set(selectionEnded ? [] :
      state.courses.filter((course) => !course.selected).map((course) => String(course.id)));
    state.targetPlans[typeId] = currentTargetIds().filter((id) => selectableIds.has(id));
    const summarySuffix = selectionEnded ? "（选课已结束，仅供查看）" : "";
    $("#courseSummary").textContent = `${state.courses.length} 个班 · ${data.available_count || 0} 个有余量${summarySuffix} · ${data.enrolled_count || 0} 个已选`;
    renderCourses();
    updateTargets();
    void loadTeacherProfiles(state.courses);
  } catch (error) {
    $("#courseRows").innerHTML = `<tr><td colspan="8"><div class="empty-state">${escapeHtml(error.message)}</div></td></tr>`;
    toast(error.message, "error");
  }
}

async function loadTeacherProfiles(courses) {
  const names = [...new Set(courses
    .map((course) => String(course.teacher || "").trim())
    .filter((name) => name && name !== "--" && !state.teacherProfileChecks.has(name)))];
  if (!names.length) return;
  names.forEach((name) => state.teacherProfileChecks.add(name));
  try {
    for (let index = 0; index < names.length; index += 6) {
      const data = await api("/api/teachers/profiles", {
        method: "POST",
        body: JSON.stringify({ names: names.slice(index, index + 6) }),
      });
      for (const profile of data.profiles || []) {
        if (profile?.name) state.teacherProfiles[profile.name] = profile;
      }
      renderCourses();
    }
  } catch (_error) {
    names.forEach((name) => state.teacherProfileChecks.delete(name));
  }
}

function currentTargetIds() {
  const typeId = $("#courseTypeSelect").value;
  if (!typeId) return [];
  if (!Array.isArray(state.targetPlans[typeId])) state.targetPlans[typeId] = [];
  return state.targetPlans[typeId];
}

function currentTargets() {
  const courseMap = new Map(state.courses.map((course) => [String(course.id), course]));
  return currentTargetIds().map((id) => courseMap.get(id)).filter(Boolean);
}

function setCurrentTargetIds(ids) {
  const typeId = $("#courseTypeSelect").value;
  if (!typeId) return;
  state.targetPlans[typeId] = Array.from(new Set(ids.map(String))).slice(0, 3);
}

function filteredCourses() {
  const query = $("#courseSearch").value.trim().toLowerCase();
  const onlyAvailable = $("#onlyAvailable").checked;
  return state.courses.filter((course) => {
    if (onlyAvailable && (!course.available || course.selected)) return false;
    if (query) {
      const haystack = `${course.name || ""} ${course.teacher || ""} ${course.section || ""}`.toLowerCase();
      if (!haystack.includes(query)) return false;
    }
    return true;
  });
}

function renderTeacherCell(course) {
  const name = String(course.teacher || "").trim();
  const profile = state.teacherProfiles[name];
  if (!profile) return escapeHtml(name || "--");
  return `<button class="teacher-profile-button" type="button" data-teacher-profile="${escapeHtml(name)}" title="查看教师简介" aria-label="查看 ${escapeHtml(name)} 的教师简介"><span>${escapeHtml(name)}</span><i data-lucide="contact-round"></i></button>`;
}

function renderCourses() {
  const rows = filteredCourses();
  const body = $("#courseRows");
  if (!$("#courseTypeSelect").value) {
    body.innerHTML = '<tr><td colspan="8"><div class="empty-state">选择类型后读取课程</div></td></tr>';
    return;
  }
  if (!rows.length) {
    body.innerHTML = '<tr><td colspan="8"><div class="empty-state">没有符合条件的课程</div></td></tr>';
    return;
  }
  const selectionEnded = isCurrentCourseWindowEnded();
  body.innerHTML = rows.map((course) => {
    const targetIds = currentTargetIds();
    const priority = targetIds.indexOf(String(course.id)) + 1;
    const disabled = selectionEnded || course.selected || (!priority && targetIds.length >= 3);
    let status = '<span class="status-chip full">已满</span>';
    if (course.exact_selected) status = '<span class="status-chip selected">已选</span>';
    else if (course.same_course_selected) status = '<span class="status-chip selected">同课程已选</span>';
    else if (selectionEnded) status = '<span class="status-chip ended">时间已结束</span>';
    else if (course.available) {
      const label = courseWindowStatus(currentCourseType()?.window) === "active" ? "可选" : "有余量";
      status = `<span class="status-chip available">${label}</span>`;
    }
    const actionLabel = selectionEnded
      ? `选课时间已结束：${course.name}`
      : course.selected
      ? `已经选过同一课程：${course.name}`
      : priority
      ? `移除第 ${priority} 志愿：${course.name}`
      : `加入下一志愿：${course.name} ${course.teacher || ""}`;
    return `<tr>
      <td class="priority-cell"><button class="priority-add${priority ? " selected" : ""}" type="button" data-id="${escapeHtml(course.id)}" ${disabled ? "disabled" : ""} aria-label="${escapeHtml(actionLabel)}" title="${escapeHtml(actionLabel)}">${priority ? `<span>${priority}</span>` : '<i data-lucide="plus"></i>'}</button></td>
      <td><span class="cell-main">${escapeHtml(course.name || "--")}</span><br><span class="cell-muted">${escapeHtml(course.nature || "")}</span></td>
      <td>${renderTeacherCell(course)}</td>
      <td>${escapeHtml(course.time || "--")}</td>
      <td>${escapeHtml(course.section || "--")}</td>
      <td>${escapeHtml(course.remaining)}</td>
      <td>${escapeHtml(course.credits || "--")}</td>
      <td>${status}</td>
    </tr>`;
  }).join("");
  renderIcons();
}

function openTeacherProfile(name) {
  const profile = state.teacherProfiles[name];
  if (!profile) return;
  $("#teacherProfileTitle").textContent = profile.name;
  $("#teacherProfileMeta").textContent = profile.department || "肇庆学院官网公开资料";
  const badges = [profile.title, profile.department].filter(Boolean).map((item) => `<span>${escapeHtml(item)}</span>`).join("");
  const summary = profile.summary
    ? `<p class="teacher-summary">${escapeHtml(profile.summary)}</p>`
    : "";
  const rosterNote = profile.profile_kind === "roster"
    ? '<p class="teacher-profile-note">官网当前仅公开师资名录，未找到可核验的个人简历或论文详情。</p>'
    : "";
  const topics = (profile.topics || []).length
    ? `<section class="teacher-topics"><h3>研究与教学</h3><div>${profile.topics.map((item) => `<span>${escapeHtml(item)}</span>`).join("")}</div></section>`
    : "";
  const teachingRecords = (profile.teaching_records || []).length
    ? `<section class="teacher-records"><h3>公开教学记录</h3><div>${profile.teaching_records.map((item) => `<span><i data-lucide="badge-check"></i>${escapeHtml(item)}</span>`).join("")}</div></section>`
    : "";
  const photo = profile.photo_url
    ? `<img class="teacher-photo" src="${escapeHtml(profile.photo_url)}" alt="${escapeHtml(profile.name)}的公开资料照片" referrerpolicy="no-referrer" onerror="this.remove()">`
    : "";
  $("#teacherProfileBody").innerHTML = `<div class="teacher-profile-layout">
    ${photo}
    <div class="teacher-profile-content">
      ${badges ? `<div class="teacher-badges">${badges}</div>` : ""}
      ${summary}
      ${rosterNote}
      ${teachingRecords}
      ${topics}
      <a class="teacher-source-link" href="${escapeHtml(profile.source_url)}" target="_blank" rel="noopener noreferrer"><span>查看${escapeHtml(profile.source_label || "公开资料")}</span><i data-lucide="external-link"></i></a>
    </div>
  </div>`;
  openModal("teacherModal");
  renderIcons();
}

function updateTargets() {
  const selectionEnded = isCurrentCourseWindowEnded();
  if (selectionEnded && currentTargetIds().length) setCurrentTargetIds([]);
  const selected = currentTargets();
  $("#targetCount").textContent = `${selected.length} / 3`;
  $("#priorityTargets").innerHTML = [0, 1, 2].map((index) => {
    const course = selected[index];
    if (!course) {
      return `<div class="priority-slot empty"><span>${index + 1}</span><div><strong>${selectionEnded ? "选课已结束" : "空志愿"}</strong><small>${selectionEnded ? "不可配置" : "可选"}</small></div></div>`;
    }
    return `<div class="priority-slot">
      <span>${index + 1}</span>
      <div class="priority-copy"><strong>${escapeHtml(course.name)}</strong><small>${escapeHtml(course.teacher || "待定")} · ${escapeHtml(course.section || "")}</small></div>
      <div class="priority-actions">
        <button type="button" data-priority-action="up" data-index="${index}" ${index === 0 ? "disabled" : ""} aria-label="上移志愿" title="上移志愿"><i data-lucide="chevron-up"></i></button>
        <button type="button" data-priority-action="down" data-index="${index}" ${index === selected.length - 1 ? "disabled" : ""} aria-label="下移志愿" title="下移志愿"><i data-lucide="chevron-down"></i></button>
        <button type="button" data-priority-action="remove" data-index="${index}" aria-label="删除志愿" title="删除志愿"><i data-lucide="x"></i></button>
      </div>
    </div>`;
  }).join("");
  $("#courseFooter").textContent = selectionEnded
    ? "选课时间已结束，课程仅供查看"
    : selected.length ? `已配置 ${selected.length} 个顺序志愿` : "未配置志愿";
  $("#startGrab").disabled = selectionEnded || !selected.length || isRunActive();
  $("#startGrab span").textContent = selectionEnded ? "选课时间已结束" : "启动抢课任务";
  renderIcons();
}

function collectRunConfig() {
  const scheduled = $("#runMode").value === "scheduled";
  const delayMinutes = Number.parseInt($("#scheduledDelayMinutes").value, 10);
  return {
    course_type_id: $("#courseTypeSelect").value,
    target_ids: [...currentTargetIds()],
    mode: $("#runMode").value,
    scheduled_at: scheduled && Number.isInteger(delayMinutes)
      ? new Date(Date.now() + delayMinutes * 60 * 1000).toISOString()
      : null,
    pool_size: Number.parseInt($("#poolSize").value, 10),
    poll_ms: Number.parseInt($("#pollMs").value, 10),
    jitter_ms: Number.parseInt($("#jitterMs").value, 10),
    retry_ms: Number.parseInt($("#retryMs").value, 10),
    hang_hours: Number.parseFloat($("#hangHours").value),
    warmup_ms: Number.parseInt($("#warmupMs").value, 10),
    lead_ms: Number.parseInt($("#leadMs").value, 10),
    burst_count: Number.parseInt($("#burstCount").value, 10),
    burst_gap_ms: Number.parseInt($("#burstGapMs").value, 10),
    prefire: $("#prefire").checked,
    prefire_interval_ms: 200,
  };
}

function openStartConfirmation() {
  if (isCurrentCourseWindowEnded()) {
    toast("该选课时间已经结束，不能再启动任务", "warning");
    return;
  }
  if (!currentTargetIds().length) return;
  state.pendingStart = collectRunConfig();
  if (state.pendingStart.mode === "scheduled") {
    const delayMinutes = Number.parseInt($("#scheduledDelayMinutes").value, 10);
    if (!Number.isInteger(delayMinutes) || delayMinutes < 1 || delayMinutes > 720) {
      toast("启动延时必须在 1 到 720 分钟之间", "warning");
      state.pendingStart = null;
      return;
    }
  }
  if (
    state.pendingStart.mode === "watch"
    && (!Number.isFinite(state.pendingStart.hang_hours)
      || state.pendingStart.hang_hours < 1
      || state.pendingStart.hang_hours > 720)
  ) {
    toast("挂机时长必须在 1 到 720 小时之间", "warning");
    state.pendingStart = null;
    return;
  }
  const type = state.courseTypes.find((item) => item.id === state.pendingStart.course_type_id);
  const selected = currentTargets();
  const modeLabels = { auto:"自动判断开课时间", scheduled:"启动延时", watch:"蹲退选挂机", timed:"教务时间", poll:"未知时间兜底" };
  const scheduleText = state.pendingStart.mode === "scheduled"
    ? ` · ${$("#scheduledDelayMinutes").value} 分钟后启动`
    : "";
  const watchText = state.pendingStart.mode === "watch" ? ` · 最长 ${state.pendingStart.hang_hours} 小时` : "";
  $("#confirmMeta").textContent = `${type?.name || "选课类型"} · ${modeLabels[state.pendingStart.mode] || state.pendingStart.mode}${scheduleText}${watchText} · ${state.pendingStart.pool_size} 条连接`;
  $("#confirmTargets").innerHTML = selected.map((course, index) => `
    <div class="confirm-target"><strong>志愿 ${index + 1} · ${escapeHtml(course.name)}</strong><span>${escapeHtml(course.teacher || "待定")} · ${escapeHtml(course.section || "")}</span></div>
  `).join("");
  openModal("confirmModal");
}

async function confirmStart() {
  if (!state.pendingStart) return;
  const button = $("#confirmStart");
  setButtonBusy(button, true, "启动中");
  try {
    const result = await api("/api/grab/start", { method: "POST", body: JSON.stringify(state.pendingStart) });
    state.run = result.state;
    closeModal("confirmModal");
    updateRunState();
    scheduleRunStatusPoll(2500);
    connectEventStream();
    navigate("logs");
    toast("抢课任务已启动", "success");
  } catch (error) {
    toast(error.message, "error");
  } finally {
    setButtonBusy(button, false);
  }
}

async function stopGrab() {
  const button = $("#stopGrab");
  setButtonBusy(button, true, "停止中");
  try {
    const result = await api("/api/grab/stop", { method: "POST", body: "{}" });
    state.run = result.state;
    updateRunState();
    scheduleRunStatusPoll(15000);
    toast(result.stopped ? "任务已停止" : "当前没有运行中的任务", "warning");
  } catch (error) {
    toast(error.message, "error");
  } finally {
    setButtonBusy(button, false);
  }
}

function isRunActive() {
  return state.run && state.run.status === "running";
}

function runStatePresentation(status) {
  const map = {
    idle: ["空闲", "idle"],
    running: ["运行中", "running"],
    success: ["已成功", "success"],
    stopped: ["已停止", "warning"],
    finished: ["已结束", "warning"],
    error: ["异常", "error"],
  };
  return map[status] || [status || "空闲", "idle"];
}

function updateRunCountdown() {
  const rawTarget = state.run?.scheduled_for || state.run?.hang_until;
  const target = rawTarget
    ? new Date(typeof rawTarget === "number" ? rawTarget * 1000 : rawTarget)
    : null;
  if (!target || Number.isNaN(target.getTime())) {
    $("#dashboardRunScheduled").textContent = "--";
  } else {
    const remaining = target.getTime() - Date.now();
    const suffix = isRunActive() && remaining > 0 ? ` · ${countdownText(remaining)}` : "";
    $("#dashboardRunScheduled").textContent = `${formatDate(target)}${suffix}`;
  }
  updateSchedulePreview();
  updateCourseWindowStatus();
}

function updateRunState() {
  const [label, cls] = runStatePresentation(state.run?.status);
  for (const chip of [$("#dashboardRunChip"), $("#courseRunChip"), $("#logRunChip")]) {
    chip.textContent = label;
    chip.className = `state-chip ${cls}`;
  }
  $("#navRunState").textContent = label;
  $("#dashboardRunMode").textContent = state.run?.message || "--";
  $("#dashboardRunType").textContent = state.run?.course_type || "--";
  $("#dashboardRunTargets").textContent = state.run?.targets?.join(" / ") || "--";
  $("#dashboardRunStarted").textContent = formatDate(state.run?.started_at);
  updateRunCountdown();
  $("#logStatusText").textContent = state.run?.message || "等待任务";
  $("#startGrab").classList.toggle("hidden", isRunActive());
  $("#stopGrab").classList.toggle("hidden", !isRunActive());
  updateTargets();
}

function appendLog(event) {
  const box = $("#logBox");
  box.querySelector(".log-empty")?.remove();
  const row = document.createElement("div");
  row.className = `log-line ${event.kind || "info"}`;
  const timeNode = document.createElement("time");
  timeNode.textContent = formatDate(event.ts, false);
  const textNode = document.createElement("span");
  textNode.textContent = event.message || "";
  row.append(timeNode, textNode);
  box.appendChild(row);
  if (box.children.length > 500) box.firstElementChild?.remove();
  box.scrollTop = box.scrollHeight;
}

async function loadRunHistory() {
  try {
    const result = await api("/api/grab/status");
    state.run = result.state;
    updateRunState();
    const box = $("#logBox");
    box.innerHTML = "";
    const events = result.events || [];
    if (!events.length) box.innerHTML = '<div class="log-empty">暂无运行日志</div>';
    else events.forEach(appendLog);
  } catch (error) {
    if (error.status !== 401) toast(error.message, "error");
  }
}

function closeEventStream() {
  if (state.eventSource) {
    state.eventSource.close();
    state.eventSource = null;
  }
}

let runStatusTimer = null;
let runStatusRequest = null;
let loginWarmupRequested = false;

function warmLoginDependencies() {
  if (loginWarmupRequested) return;
  loginWarmupRequested = true;
  void fetch("/api/login/warmup", { method: "POST" }).catch(() => {});
}

function scheduleRunStatusPoll(delay = null) {
  if (runStatusTimer) clearTimeout(runStatusTimer);
  if (!state.loggedIn) {
    runStatusTimer = null;
    return;
  }
  const interval = delay ?? (isRunActive() ? 2500 : 15000);
  runStatusTimer = setTimeout(async () => {
    await refreshRunStatus();
    scheduleRunStatusPoll();
  }, interval);
}

function connectEventStream() {
  closeEventStream();
  if (!state.loggedIn) return;
  const stream = new EventSource("/api/grab/stream");
  state.eventSource = stream;
  stream.onmessage = (event) => {
    try {
      appendLog(JSON.parse(event.data));
    } catch (_) {}
  };
  stream.onerror = () => {
    closeEventStream();
    if (state.loggedIn && isRunActive()) setTimeout(connectEventStream, 2000);
  };
}

async function refreshRunStatus() {
  if (!state.loggedIn) return;
  if (runStatusRequest) return runStatusRequest;
  runStatusRequest = (async () => {
    try {
      const result = await api("/api/status?include_online=true");
      if (result.display_name && result.display_name !== state.displayName) {
        state.displayName = result.display_name;
        renderAccountIdentity();
      }
      if (result.school_online) renderSchoolStatus(result.school_online);
      state.run = result.grab || { status: "idle" };
      updateRunState();
    } catch (_) {
      // The next scheduled poll retries without creating concurrent requests.
    } finally {
      runStatusRequest = null;
    }
  })();
  return runStatusRequest;
}

async function refreshCurrentPage() {
  const button = $("#refreshPage");
  setButtonBusy(button, true, "刷新中");
  try {
    if (state.page === "grades") await loadGrades(true);
    else if (state.page === "notices") await loadNotices(true);
    else if (state.page === "timetable") await loadTimetable(true);
    else if (state.page === "courses") {
      await loadCourseTypes(true);
      if ($("#courseTypeSelect").value) await loadCourses(true);
    } else if (state.page === "logs") await loadRunHistory();
    else await Promise.all([loadGrades(true), loadCourseTypes(true), refreshRunStatus()]);
  } finally {
    setButtonBusy(button, false);
  }
}

function openModal(id) {
  const modal = $(`#${id}`);
  modal.classList.remove("hidden");
  modal.querySelector("button")?.focus();
}

function closeModal(id) {
  $(`#${id}`).classList.add("hidden");
}

async function initializeApp(status) {
  showApp(status.username, status.display_name);
  state.run = status.grab || { status: "idle" };
  updateRunState();
  await Promise.all([loadGrades(), loadCourseTypes(), refreshRunStatus()]);
  loadCommunityStatus();
  connectEventStream();
  scheduleRunStatusPoll(15000);
}

function bindEvents() {
  $("#username").addEventListener("focus", warmLoginDependencies, { once:true });
  $("#password").addEventListener("focus", warmLoginDependencies, { once:true });
  $("#loginButton").addEventListener("pointerenter", warmLoginDependencies, { once:true });
  $("#loginForm").addEventListener("submit", async (event) => {
    event.preventDefault();
    if ($("#syncAccount").checked && !$("#displayName").value.trim()) {
      $("#displayName").focus();
      return toast("开启服务器同步时请填写姓名", "warning");
    }
    await runLoginFlow(
      "/api/login/start",
      {
        username: $("#username").value.trim(),
        password: $("#password").value,
        display_name: $("#displayName").value.trim(),
        proxy: $("#proxy").value.trim(),
        remember: $("#rememberLogin").checked,
        sync_account: $("#syncAccount").checked,
      },
      $("#loginButton"),
    );
  });

  $("#savedLoginButton").addEventListener("click", () => {
    runLoginFlow("/api/login/saved/start", null, $("#savedLoginButton"));
  });

  $("#clearSavedLogin").addEventListener("click", async () => {
    try {
      await api("/api/saved-login", { method:"DELETE" });
      state.savedLogin = null;
      $("#savedLoginCard").classList.add("hidden");
      $("#password").value = "";
      toast("已清除保存的登录信息", "success");
    } catch (error) {
      toast(error.message, "error");
    }
  });

  $("#togglePassword").addEventListener("click", () => {
    const input = $("#password");
    const show = input.type === "password";
    input.type = show ? "text" : "password";
    const button = $("#togglePassword");
    button.innerHTML = `<i data-lucide="${show ? "eye-off" : "eye"}"></i>`;
    button.setAttribute("aria-label", show ? "隐藏密码" : "显示密码");
    button.setAttribute("title", show ? "隐藏密码" : "显示密码");
    renderIcons();
  });

  const logoutCurrentSession = async () => {
    try {
      await api("/api/logout", { method: "POST", body: "{}" });
      state.grades = [];
      state.notices = [];
      state.timetableTerms = [];
      state.timetableItems = [];
      state.timetableSemester = "";
      state.courseTypes = [];
      state.courses = [];
      state.teacherProfiles = {};
      state.teacherProfileChecks.clear();
      state.targetPlans = {};
      showLogin("已退出登录");
    } catch (error) {
      toast(error.message, "error");
    }
  };
  $("#logoutButton").addEventListener("click", logoutCurrentSession);
  $("#mobileLogout").addEventListener("click", logoutCurrentSession);

  $$(".nav-item").forEach((button) => button.addEventListener("click", () => navigate(button.dataset.page)));
  $$(".jump-page").forEach((button) => button.addEventListener("click", () => navigate(button.dataset.target)));
  $("#refreshPage").addEventListener("click", refreshCurrentPage);
  $("#schoolOnlineChart").addEventListener("pointermove", updateSchoolChartTooltip);
  $("#schoolOnlineChart").addEventListener("pointerleave", () => $("#schoolChartTooltip").classList.add("hidden"));
  new ResizeObserver(() => renderSchoolOnlineChart()).observe($("#schoolChartWrap"));
  $("#refreshGrades").addEventListener("click", () => loadGrades(true));
  $("#refreshNotices").addEventListener("click", () => loadNotices(true));
  $("#refreshTimetable").addEventListener("click", () => loadTimetable(true));
  $("#timetableSemester").addEventListener("change", () => {
    state.timetableSemester = $("#timetableSemester").value;
    loadTimetable();
  });
  $("#semesterFilter").addEventListener("change", renderGrades);
  $("#gradeSearch").addEventListener("input", renderGrades);
  $("#gradeRows").addEventListener("click", (event) => {
    const button = event.target.closest(".grade-detail");
    if (button) openGradeDetail(button.dataset.id);
  });
  $("#noticeList").addEventListener("click", (event) => {
    const item = event.target.closest(".notice-item");
    if (item) openNotice(item.dataset.noticeId);
  });

  $("#courseTypeSelect").addEventListener("change", () => {
    updateCourseWindowStatus();
    loadCourses();
  });
  $("#verifyTiming").addEventListener("click", verifyCourseTiming);
  $("#runMode").addEventListener("change", () => {
    markParameterPresetCustom();
    updateScheduleControls();
  });
  $("#parameterPreset").addEventListener("change", (event) => applyParameterPreset(event.target.value));
  PARAMETER_INPUT_IDS.forEach((id) => {
    $(`#${id}`).addEventListener("input", markParameterPresetCustom);
    $(`#${id}`).addEventListener("change", markParameterPresetCustom);
  });
  $("#scheduledDelayMinutes").addEventListener("input", updateSchedulePreview);
  $("#refreshCourses").addEventListener("click", () => loadCourses(true));
  $("#courseSearch").addEventListener("input", renderCourses);
  $("#onlyAvailable").addEventListener("change", renderCourses);
  $("#courseRows").addEventListener("click", (event) => {
    const teacherButton = event.target.closest("[data-teacher-profile]");
    if (teacherButton) {
      openTeacherProfile(teacherButton.dataset.teacherProfile);
      return;
    }
    const button = event.target.closest(".priority-add");
    if (!button) return;
    if (isCurrentCourseWindowEnded()) return toast("该选课时间已经结束，课程仅供查看", "warning");
    const id = String(button.dataset.id);
    const ids = [...currentTargetIds()];
    const currentIndex = ids.indexOf(id);
    if (currentIndex >= 0) ids.splice(currentIndex, 1);
    else if (ids.length < 3) ids.push(id);
    else return toast("每个选课类型最多配置 3 个志愿", "warning");
    setCurrentTargetIds(ids);
    renderCourses();
    updateTargets();
  });
  $("#priorityTargets").addEventListener("click", (event) => {
    const button = event.target.closest("[data-priority-action]");
    if (!button || button.disabled) return;
    const index = Number.parseInt(button.dataset.index, 10);
    const ids = [...currentTargetIds()];
    if (!Number.isInteger(index) || index < 0 || index >= ids.length) return;
    if (button.dataset.priorityAction === "remove") ids.splice(index, 1);
    else if (button.dataset.priorityAction === "up" && index > 0) {
      [ids[index - 1], ids[index]] = [ids[index], ids[index - 1]];
    } else if (button.dataset.priorityAction === "down" && index < ids.length - 1) {
      [ids[index], ids[index + 1]] = [ids[index + 1], ids[index]];
    }
    setCurrentTargetIds(ids);
    renderCourses();
    updateTargets();
  });
  $("#clearTargets").addEventListener("click", () => {
    setCurrentTargetIds([]);
    renderCourses();
    updateTargets();
  });
  $("#startGrab").addEventListener("click", openStartConfirmation);
  $("#confirmStart").addEventListener("click", confirmStart);
  $("#stopGrab").addEventListener("click", stopGrab);
  $("#clearLogs").addEventListener("click", () => {
    $("#logBox").innerHTML = '<div class="log-empty">暂无运行日志</div>';
  });

  $$('[data-close]').forEach((button) => button.addEventListener("click", () => closeModal(button.dataset.close)));
  $$(".modal-backdrop").forEach((backdrop) => backdrop.addEventListener("click", (event) => {
    if (event.target === backdrop) closeModal(backdrop.id);
  }));
  document.addEventListener("keydown", (event) => {
    if (event.key === "Escape") $$(".modal-backdrop:not(.hidden)").forEach((modal) => closeModal(modal.id));
  });
}

async function boot() {
  renderIcons();
  bindEvents();
  updateScheduleControls();
  loadCommunityStatus();
  try {
    const status = await api("/api/status");
    if (status.logged_in) await initializeApp(status);
    else showLogin();
  } catch (error) {
    showLogin(`本地服务连接失败：${error.message}`);
  }
  scheduleRunStatusPoll(1500);
  setInterval(updateRunCountdown, 1000);
  setInterval(loadCommunityStatus, 15000);
}

document.addEventListener("DOMContentLoaded", boot);
