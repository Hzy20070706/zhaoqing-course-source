#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
肇庆学院 WebVPN 全自动抢课系统 v7.0 — 微秒级触发
架构:
  交互选课 → 预构建HTTP → asyncio协程池 → 10ms轮询 → 同tick释放 → QQ加群

性能:
  - 轮询间隔: 10ms (100次/秒)
  - 并发请求释放: <1ms (同事件循环 gather)
  - TCP keep-alive 复用, 零握手延迟
"""
import re, sys, time, json, base64, io, configparser, asyncio, contextlib, html, unicodedata, threading, random
from dataclasses import dataclass, field
from typing import Optional, List, Tuple, Dict, Any, Callable, Awaitable
from pathlib import Path
from urllib.parse import urlencode
from datetime import datetime, timezone, timedelta
from email.utils import parsedate_to_datetime

try:
    from zoneinfo import ZoneInfo
except Exception:
    ZoneInfo = None

try:
    import aiohttp
    import requests
    from loguru import logger
except ImportError as exc:
    raise SystemExit(
        f"缺少基础依赖：{exc.name}\n"
        f"解释器：{sys.executable}\n"
        f'请手动执行："{sys.executable}" -m pip install -r requirements.txt'
    ) from exc

# ============================================================
_DEPENDENCY_PACKAGES = {
    "Crypto":"pycryptodome",
    "cv2":"opencv-python",
    "numpy":"numpy",
    "PIL":"Pillow",
    "ddddocr":"ddddocr",
    "aiohttp":"aiohttp",
    "requests":"requests",
    "loguru":"loguru",
}


def ensure_deps(modules: Optional[List[str]] = None):
    modules = modules or list(_DEPENDENCY_PACKAGES)
    missing = []
    for mod in modules:
        try:
            if mod=="PIL": __import__("PIL.Image")
            elif mod=="Crypto": __import__("Crypto.Cipher")
            else: __import__(mod)
        except ImportError: missing.append(mod)
    if missing:
        names = [_DEPENDENCY_PACKAGES[m] for m in missing if m in _DEPENDENCY_PACKAGES]
        raise RuntimeError(
            f"缺少依赖：{', '.join(names)}。请使用当前解释器手动执行：\n"
            f'"{sys.executable}" -m pip install -r requirements.txt'
        )

ensure_deps(["Crypto", "aiohttp", "requests", "loguru"])
from Crypto.Cipher import AES

_EDU_OCR = None
_EDU_OCR_LOCK = threading.Lock()
_EDU_OCR_RELEASE_TIMER = None
_JITTER_RNG = random.SystemRandom()


def _load_slider_dependencies():
    """Load image matching dependencies only while solving the VPN slider."""
    ensure_deps(["cv2", "numpy", "PIL"])
    import cv2
    import numpy as np
    from PIL import Image
    return cv2, np, Image


def _get_edu_ocr():
    """Create the OCR model on first use instead of during WebUI startup."""
    global _EDU_OCR
    with _EDU_OCR_LOCK:
        if _EDU_OCR is None:
            ensure_deps(["ddddocr"])
            import ddddocr
            _EDU_OCR = ddddocr.DdddOcr(show_ad=False)
        return _EDU_OCR


def _release_edu_ocr():
    """Drop the OCR model once authentication finishes to keep the WebUI light."""
    global _EDU_OCR, _EDU_OCR_RELEASE_TIMER
    with _EDU_OCR_LOCK:
        if _EDU_OCR_RELEASE_TIMER is not None:
            _EDU_OCR_RELEASE_TIMER.cancel()
            _EDU_OCR_RELEASE_TIMER = None
        _EDU_OCR = None
    import gc
    gc.collect()


def warm_login_dependencies(hold_seconds: float = 45) -> None:
    """Warm local captcha code after user intent, without making a VPN request."""
    global _EDU_OCR_RELEASE_TIMER
    _load_slider_dependencies()
    _get_edu_ocr()
    with _EDU_OCR_LOCK:
        if _EDU_OCR_RELEASE_TIMER is not None:
            _EDU_OCR_RELEASE_TIMER.cancel()
        timer = threading.Timer(max(5.0, float(hold_seconds)), _release_edu_ocr)
        timer.daemon = True
        _EDU_OCR_RELEASE_TIMER = timer
        timer.start()

# ============================================================
VPN_BASE  = "https://webvpn-free.zqu.edu.cn"
AES_KEY   = b"wrdvpnisawesome!"
AES_IV    = b"wrdvpnisawesome!"
EDU_PROXY = VPN_BASE + "/https/77726476706e69737468656265737421fae04690692a7945300d8db9d6562d/"
QQ_GROUP  = "1044128566"

# ============================================================
# 课程时间计算: 第一节8:00, 每节40分钟+休息10分钟
PERIOD_START = [None, "08:00","08:50","09:40","10:30","11:20",  # 1-5 上午
                "14:00","14:50","15:40","16:30","17:20",          # 6-10 下午
                "19:00","19:50","20:40"]                           # 11-13 晚上
PERIOD_END   = [None, "08:40","09:30","10:20","11:10","12:00",
                "14:40","15:30","16:20","17:10","18:00",
                "19:40","20:30","21:20"]
WEEKDAYS = {1:"周一",2:"周二",3:"周三",4:"周四",5:"周五",6:"周六",7:"周日"}


def _jittered_delay_seconds(base_ms: int, jitter_ms: int, minimum_ms: int = 1) -> float:
    jitter = max(0, int(jitter_ms or 0))
    delay = int(base_ms or 0)
    if jitter:
        delay += _JITTER_RNG.uniform(-jitter, jitter)
    return max(int(minimum_ms or 1), delay) / 1000.0

def _safe_int(value, default: int = 0) -> int:
    """把接口返回的 '', None, '10.0', '10人' 等安全转成 int。"""
    if value is None:
        return default
    if isinstance(value, bool):
        return int(value)
    if isinstance(value, (int, float)):
        return int(value)
    m = re.search(r"-?\d+", str(value))
    return int(m.group(0)) if m else default

def _normalize_weekday(text: str) -> str:
    """统一 '星期三'/'周三'/'周天' 为 '周三'/'周日'。"""
    day = text.replace("星期", "周")
    return day.replace("周天", "周日")

def _period_desc(p1: int, p2: int) -> str:
    # 1-5 上午，6-10 下午，11-13 晚上；跨段时明确标注。
    if p2 <= 5:
        return "上午"
    if p1 >= 6 and p2 <= 10:
        return "下午"
    if p1 >= 11:
        return "晚上"
    if p1 <= 5 and p2 >= 6:
        return "上午+下午"
    if p1 <= 10 and p2 >= 11:
        return "下午+晚上"
    return ""

def _parse_compact_periods(value: str) -> Optional[Tuple[int, int]]:
    """把 345、8910、101112 等连续节次解析为起止节次。"""
    digits = str(value or "")
    candidates: List[List[int]] = []

    def walk(offset: int, periods: List[int]) -> None:
        if offset == len(digits):
            if periods and all(right == left + 1 for left, right in zip(periods, periods[1:])):
                candidates.append(periods)
            return
        for width in (1, 2):
            token = digits[offset:offset + width]
            if len(token) != width or token.startswith("0"):
                continue
            period = int(token)
            if not 1 <= period <= 13:
                continue
            if periods and period != periods[-1] + 1:
                continue
            walk(offset + width, [*periods, period])

    walk(0, [])
    if not candidates:
        return None
    periods = max(candidates, key=len)
    return periods[0], periods[-1]

def parse_time(xmmc: str) -> str:
    """从 xmmc 解析上课时间, 如 '周二6-7匹克球' → '周二 6-7节 下午 (14:00-15:30)'"""
    if not xmmc: return ""
    xmmc = str(xmmc).strip()
    # 提取周次前缀: "9-10周星期三6-8" → weeks="9-10周", rest="星期三6-8"
    week_prefix = ""
    rest = xmmc
    wm = re.match(r'(\d+[-—]\d+周)', xmmc)
    if wm:
        week_prefix = wm.group(1)
        rest = xmmc[wm.end():]

    # 匹配 "周三6-7" / "星期三6-7" / "周三第6-7节"
    day_pat = r'((?:周|星期)[一二三四五六日天])'
    m = re.search(day_pat + r'\s*(?:第)?\s*(\d{1,2})\s*[-—–－~至]+\s*(\d{1,2})\s*(?:节)?', rest)
    if m:
        day = _normalize_weekday(m.group(1))
        p1, p2 = int(m.group(2)), int(m.group(3))
    else:
        # 匹配连续节次: "周三678" / "星期五8910" / "周一101112"。
        m = re.search(day_pat + r'\s*(\d{2,8})\s*(?:节)?', rest)
        if m:
            day = _normalize_weekday(m.group(1))
            parsed_periods = _parse_compact_periods(m.group(2))
            if parsed_periods is None:
                return f"{xmmc[:30]}"
            p1, p2 = parsed_periods
        else:
            return f"{xmmc[:30]}"

    if p1 > p2:
        p1, p2 = p2, p1

    # 时间段描述
    period_desc = _period_desc(p1, p2)

    start_t = PERIOD_START[p1] if p1 < len(PERIOD_START) else "?"
    end_t = PERIOD_END[p2] if p2 < len(PERIOD_END) else "?"

    week_str = f"{week_prefix} " if week_prefix else ""
    return f"{week_str}{day} {p1}-{p2}节 {period_desc} ({start_t}-{end_t})".strip()

@dataclass
class Course:
    name: str; section: str; teacher: str
    kcrwdm: str; jxbdm: str = ""; kcdm: str = ""
    capacity: int = 0; enrolled: int = 0
    credits: str = ""; nature: str = ""
    time_info: str = ""
    raw: dict = field(default_factory=dict)

    @property
    def remaining(self) -> int: return max(0, self.capacity - self.enrolled)
    @property
    def available(self) -> bool: return self.remaining > 0 or self.capacity == 0
    def __repr__(self): return f"[{self.time_info}] {self.section} {self.teacher} 余{self.remaining}"

@dataclass
class CourseType:
    name: str; xkkzdm: str = ""; kzdm: str = ""
    controller: str = "xsxklist"
    is_special: bool = False; main_url: str = ""
    courses: List[Course] = field(default_factory=list)
    raw: dict = field(default_factory=dict)

def course_from_row(row: Dict[str, Any]) -> Course:
    """把教务接口 row 统一转换成 Course，避免同步/异步扫描字段不一致。"""
    xmmc = str(row.get("xmmc", ""))
    return Course(
        name=str(row.get("kcmc", "")),
        section=str(row.get("jxbmc", row.get("xmmc", ""))),
        teacher=str(row.get("teaxm", "")),
        kcrwdm=str(row.get("kcrwdm", "")),
        jxbdm=str(row.get("jxbdm", "")),
        kcdm=str(row.get("kcdm", "")),
        capacity=_safe_int(row.get("pkrs", row.get("jxbrs", 0))),
        enrolled=_safe_int(row.get("jxbrs", 0)),
        credits=str(row.get("xf", "")),
        nature=str(row.get("xdfsmc", "")),
        time_info=parse_time(xmmc),
        raw=row,
    )

def local_tz():
    """学校选课时间按北京时间处理。"""
    if ZoneInfo:
        try:
            return ZoneInfo("Asia/Shanghai")
        except Exception:
            pass
    return timezone(timedelta(hours=8))

CN_TZ = local_tz()

def parse_school_datetime(value: str) -> Optional[datetime]:
    """解析教务系统的 'YYYY-mm-dd HH:MM:SS' 为北京时间 aware datetime。"""
    value = str(value or "").strip()
    if not value:
        return None
    for fmt in ("%Y-%m-%d %H:%M:%S", "%Y-%m-%d %H:%M"):
        try:
            return datetime.strptime(value, fmt).replace(tzinfo=CN_TZ)
        except ValueError:
            continue
    return None

def _course_term_start_year(raw: dict) -> int:
    """从选课学期字段取得提示文本所对应的起始年份。"""
    for value in (raw.get("xnxqmc", ""), raw.get("xnxqdm", "")):
        match = re.search(r"(20\d{2})", str(value or ""))
        if match:
            return int(match.group(1))
    return datetime.now().year

def _tip_course_windows(raw: dict) -> List[dict]:
    """解析选课页面 xk_tips 中的明确时间范围，作为结构化字段的兜底。"""
    tips = html.unescape(str(raw.get("xk_tips", "") or ""))
    if not tips:
        return []
    pattern = re.compile(
        r"(?:(?P<sy>20\d{2})年)?(?P<sm>\d{1,2})月(?P<sd>\d{1,2})日"
        r"\s*(?P<sh>\d{1,2})(?::(?P<smin>\d{2}))?\s*"
        r"[—–－~至到-]+\s*"
        r"(?:(?P<ey>20\d{2})年)?(?P<em>\d{1,2})月(?P<ed>\d{1,2})日"
        r"\s*(?P<eh>\d{1,2})(?::(?P<emin>\d{2}))?"
    )
    default_year = _course_term_start_year(raw)
    windows = []
    for match in pattern.finditer(tips):
        parts = match.groupdict()
        start_year = int(parts["sy"] or default_year)
        end_year = int(parts["ey"] or start_year)
        start_month = int(parts["sm"])
        end_month = int(parts["em"])
        if not parts["ey"] and end_month < start_month:
            end_year += 1
        try:
            start = datetime(
                start_year,
                start_month,
                int(parts["sd"]),
                int(parts["sh"]),
                int(parts["smin"] or 0),
                tzinfo=CN_TZ,
            )
            end_hour = int(parts["eh"])
            end = datetime(
                end_year,
                end_month,
                int(parts["ed"]),
                0 if end_hour == 24 else end_hour,
                int(parts["emin"] or 0),
                tzinfo=CN_TZ,
            )
            if end_hour == 24:
                end += timedelta(days=1)
        except (TypeError, ValueError):
            continue
        if start < end:
            windows.append({"stage": len(windows) + 1, "start": start, "end": end})
    return windows

def get_course_windows(raw: dict) -> List[dict]:
    """从选课类型 raw 中提取多轮选课窗口。"""
    windows = []
    for stage, (sk, ek) in enumerate([('qssj1','jssj1'),('qssj2','jssj2'),('qssj3','jssj3')], 1):
        start = parse_school_datetime(raw.get(sk, ""))
        end = parse_school_datetime(raw.get(ek, ""))
        if start and end:
            windows.append({"stage": stage, "start": start, "end": end})
    return windows or _tip_course_windows(raw)

def choose_active_or_next_window(raw: dict, now_dt: datetime) -> Optional[dict]:
    """优先返回进行中的窗口；否则返回最近的未来窗口。"""
    windows = sorted(get_course_windows(raw), key=lambda x: x["start"])
    for w in windows:
        if w["start"] <= now_dt <= w["end"]:
            return {**w, "status": "active"}
    for w in windows:
        if now_dt < w["start"]:
            return {**w, "status": "future"}
    return None

def server_now(server_delta: timedelta = timedelta(0)) -> datetime:
    """用校准偏移估算服务器当前 UTC 时间。"""
    return datetime.now(timezone.utc) + server_delta

def _estimate_server_delta(samples: List[Tuple[datetime, datetime, datetime]]) -> Tuple[timedelta, float, float]:
    """利用 HTTP Date 的整秒区间约束估算时钟偏移。"""
    if not samples:
        return timedelta(0), 1000.0, 0.0
    one_second = timedelta(seconds=1)
    lower = max(server_dt - local_end for local_start, local_end, server_dt in samples)
    upper = min(server_dt + one_second - local_start for local_start, local_end, server_dt in samples)
    best = min(samples, key=lambda item:(item[1] - item[0]).total_seconds())
    best_rtt_ms = (best[1] - best[0]).total_seconds() * 1000
    if lower <= upper:
        delta = lower + (upper - lower) / 2
        uncertainty_ms = (upper - lower).total_seconds() * 500
        return delta, uncertainty_ms, best_rtt_ms
    local_start, local_end, server_dt = best
    midpoint = local_start + (local_end - local_start) / 2
    delta = server_dt + timedelta(milliseconds=500) - midpoint
    return delta, 500 + best_rtt_ms / 2, best_rtt_ms

def calibrate_server_clock(session: requests.Session, samples: int = 24) -> dict:
    """Measure the authenticated service clock and retain its uncertainty."""
    records: List[Tuple[datetime, datetime, datetime]] = []
    for i in range(max(1, samples)):
        try:
            t0 = datetime.now(timezone.utc)
            r = session.head(EDU_PROXY, timeout=4, allow_redirects=False)
            t1 = datetime.now(timezone.utc)
            date_header = r.headers.get("Date")
            r.close()
            if not date_header:
                continue
            srv = parsedate_to_datetime(date_header)
            if srv.tzinfo is None:
                srv = srv.replace(tzinfo=timezone.utc)
            srv = srv.astimezone(timezone.utc)
            records.append((t0, t1, srv))
            time.sleep(0.01)
        except Exception as e:
            logger.debug(f"服务器时间校准失败({i+1}/{samples}): {e}")
            time.sleep(0.05)
    if not records:
        logger.warning("未能从 HTTP Date 头校准服务器时间，使用本机时间。")
        return {
            "delta": timedelta(0),
            "calibrated": False,
            "sample_count": 0,
            "uncertainty_ms": None,
            "rtt_ms": None,
        }
    delta, uncertainty_ms, best_rtt_ms = _estimate_server_delta(records)
    logger.info(
        f"服务器时间校准: {len(records)}样本, RTT={best_rtt_ms:.0f}ms, "
        f"偏移={delta.total_seconds()*1000:+.0f}ms, 不确定度约±{uncertainty_ms:.0f}ms"
    )
    return {
        "delta": delta,
        "calibrated": True,
        "sample_count": len(records),
        "uncertainty_ms": uncertainty_ms,
        "rtt_ms": best_rtt_ms,
    }


def calibrate_server_time(session: requests.Session, samples: int = 24) -> timedelta:
    """Return the measured clock delta for existing timing callers."""
    return calibrate_server_clock(session, samples)["delta"]

def save_target_selection(ct: CourseType, targets: List[Course], window: Optional[dict], path: str = "target_course.json"):
    """保存本次选择，便于复盘或下次无课程列表时参考。"""
    if not targets:
        return
    data = {
        "saved_at": datetime.now(CN_TZ).strftime("%Y-%m-%d %H:%M:%S"),
        "course_type": {
            "name": ct.name,
            "controller": ct.controller,
            "xkkzdm": ct.xkkzdm,
            "kzdm": ct.kzdm,
            "is_special": ct.is_special,
        },
        "window": {
            "stage": window.get("stage") if window else None,
            "status": window.get("status") if window else None,
            "start": window["start"].strftime("%Y-%m-%d %H:%M:%S") if window else None,
            "end": window["end"].strftime("%Y-%m-%d %H:%M:%S") if window else None,
        },
        "targets": [
            {
                "name": c.name,
                "section": c.section,
                "teacher": c.teacher,
                "kcrwdm": c.kcrwdm,
                "jxbdm": c.jxbdm,
                "kcdm": c.kcdm,
                "time_info": c.time_info,
                "capacity": c.capacity,
                "enrolled": c.enrolled,
            }
            for c in targets
        ],
    }
    p = Path(path)
    p.write_text(json.dumps(data, ensure_ascii=False, indent=2), encoding="utf-8")
    logger.info(f"目标课程已保存: {p.resolve()}")

# ============================================================
# 通知 + QQ
# ============================================================
_qq_opened = False

def desktop_notify(title: str, msg: str):
    try:
        import subprocess
        ps = f'''
Add-Type -AssemblyName System.Windows.Forms
$n=New-Object System.Windows.Forms.NotifyIcon
$n.Icon=[System.Drawing.Icon]::ExtractAssociatedIcon([System.Diagnostics.Process]::GetCurrentProcess().MainModule.FileName)
$n.BalloonTipTitle="{title}";$n.BalloonTipText="{msg}"
$n.Visible=$true;$n.ShowBalloonTip(5000);Start-Sleep 6;$n.Dispose()'''
        subprocess.Popen(["powershell","-NoProfile","-NonInteractive","-Command",ps],
                         stdout=subprocess.DEVNULL,stderr=subprocess.DEVNULL)
    except: pass

def beep():
    try: import winsound; winsound.MessageBeep(0x00040000)
    except: pass

def open_qq():
    global _qq_opened
    if _qq_opened: return
    _qq_opened = True
    try:
        import webbrowser, subprocess
        webbrowser.open(f"https://qm.qq.com/q/{QQ_GROUP}")
        subprocess.Popen(["start",f"tencent://AddContact/?fromId=45&fromSubId=1&subcmd=all&uin={QQ_GROUP}"],
                       shell=True, stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
        logger.info(f"[QQ] 加群链接已打开: {QQ_GROUP}")
    except: pass

# ============================================================
# Part 1: VPN 登录 (同步, 复用 v6.0 代码)
# ============================================================
def vpn_login(username: str, password: str, proxy: str = None) -> Optional[requests.Session]:
    s = requests.Session()
    s.headers.update({"User-Agent":"Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36",
                       "Accept-Language":"zh-CN,zh;q=0.9"})
    if proxy: s.proxies = {"http":proxy,"https":proxy}

    def _encrypt(text):
        tl = len(text)
        padded = text if tl%16==0 else text+"0"*(16-tl%16)
        cipher = AES.new(AES_KEY, AES.MODE_CFB, iv=AES_IV, segment_size=128)
        enc = cipher.encrypt(padded.encode())
        return AES_IV.hex() + enc.hex()[:tl*2]

    def _solve_slider():
        cv2, np, Image = _load_slider_dependencies()
        r = s.get(f"{VPN_BASE}/login/image", params={"_":int(time.time()*1000)}, timeout=15)
        data = r.json()
        for k in ("p","s"):
            if data[k].startswith("data:"): data[k] = data[k].split(",",1)[1]
        bg = cv2.cvtColor(np.array(Image.open(io.BytesIO(base64.b64decode(data["p"])))), cv2.COLOR_RGB2GRAY)
        sl = cv2.cvtColor(np.array(Image.open(io.BytesIO(base64.b64decode(data["s"])))), cv2.COLOR_RGB2GRAY)
        be = cv2.Canny(bg,100,200); se = cv2.Canny(sl,100,200)
        res = cv2.matchTemplate(be,se,cv2.TM_CCOEFF_NORMED)
        _,_,_,ml = cv2.minMaxLoc(res)
        dist = ml[0]; locs = []; x = 0
        for i in range(int(dist)):
            p = i/dist
            if p<0.1: step=1+p/0.1*3
            elif p>0.8: step=3-(p-0.8)/0.2*2
            else: step=3+(0.5-abs(p-0.5))*0.5
            x = min(x+int(step),int(dist)); locs.append({"x":x,"y":30})
        r = s.post(f"{VPN_BASE}/login/verify",
            data={"w":int(dist),"t":len(locs)*30,"locations":json.dumps(locs)}, timeout=15)
        return r.json().get("success",False)

    r = s.get(f"{VPN_BASE}/login", timeout=15)
    m = re.search(r'name="_csrf"\s+value="([^"]+)"', r.text)
    if not m: logger.error("CSRF获取失败"); return None
    csrf = m.group(1)

    for i in range(5):
        if _solve_slider(): break
        logger.warning(f"滑块重试 {i+1}/5")
    else: logger.error("滑块失败"); return None
    enc_pw = _encrypt(password)
    r = s.post(f"{VPN_BASE}/do-login",
        data={"_csrf":csrf,"auth_type":"local","username":username,"password":enc_pw},
        timeout=15, allow_redirects=False)
    result = r.json()
    if result.get("error")=="NEED_CONFIRM":
        r = s.post(f"{VPN_BASE}/do-confirm-login", timeout=15); result = r.json()
    if result.get("error")=="NEED_TWO_STEP":
        code = input(f"短信验证码 ({result.get('phone','')}): ").strip()
        r = s.post(f"{VPN_BASE}/do-login",
            data={"_csrf":csrf,"auth_type":"local","username":username,"password":enc_pw,"code":code},
            timeout=15); result = r.json()
    if result.get("success"):
        logger.success("VPN OK")
        return s
    logger.error(f"VPN失败: {result.get('error')}"); return None

# ============================================================
# Part 2: 教务登录
# ============================================================
def edu_login(session: requests.Session, username: str, password: str) -> bool:
    pwd_b64 = base64.b64encode(password.encode()).decode()
    ocr = _get_edu_ocr()
    try:
        for attempt in range(5):
            r = session.get(EDU_PROXY + "yzm?d=" + str(int(time.time()*1000)), timeout=10)
            with _EDU_OCR_LOCK:
                code = ocr.classification(r.content)
            r = session.post(EDU_PROXY + "login!doLogin.action",
                data={"account":username,"pwd":pwd_b64,"verifycode":code},
                headers={"Accept":"application/json","Content-Type":"application/x-www-form-urlencoded",
                         "X-Requested-With":"XMLHttpRequest","Referer":EDU_PROXY}, timeout=15)
            try: result = r.json()
            except: continue
            if result.get("status")=="y":
                logger.success("教务 OK")
                return True
            elif "验证码" in result.get("msg",""): continue
            else: logger.error(f"教务登录失败: {result.get('msg','')}"); return False
        return False
    finally:
        _release_edu_ocr()

# ============================================================
# Part 3: API 扫描 (同步)
# ============================================================
class Scanner:
    def __init__(self, session: requests.Session):
        self.s = session

    def scan_types(self) -> List[CourseType]:
        logger.info("扫描选课类型...")
        types = []
        try:
            r = self.s.get(EDU_PROXY + "xsxkmain!getDataList.action",
                params={"page":"1","rows":"100"},
                headers={"Referer":EDU_PROXY+"xsxkmain!xkmain.action","X-Requested-With":"XMLHttpRequest"},
                timeout=15)
            for item in r.json():
                t = CourseType(
                    name=item.get("xklxmc","?"),
                    xkkzdm=str(item.get("xkkzdm","")),
                    kzdm=str(item.get("kzdm","")),
                    raw=item,
                )
                if t.kzdm and not t.xkkzdm: t.controller = "jlxklist"
                elif "补修" in t.name: t.controller="bcbmxx"; t.is_special=True; t.main_url="bcbmxx!bcbmMain.action"
                elif "体测" in t.name: t.controller="xstcbm"; t.is_special=True; t.main_url="xstcbm!xstcbmMain.action"
                else: t.controller = "xsxklist"
                types.append(t)
        except Exception as e:
            logger.error(f"扫描类型失败: {e}")
        return types

    def scan_courses(self, ct: CourseType) -> List[Course]:
        params = {"page":"1","rows":"500"}
        if ct.is_special: pass
        elif ct.controller == "jlxklist": params["kzdm"] = ct.kzdm
        else: params["xkkzdm"] = ct.xkkzdm

        try:
            r = self.s.post(EDU_PROXY + f"{ct.controller}!getDataList.action", data=params,
                headers={"Referer":EDU_PROXY,"X-Requested-With":"XMLHttpRequest",
                         "Content-Type":"application/x-www-form-urlencoded"}, timeout=15)
            data = r.json()
            rows = data.get("rows",[]) if isinstance(data,dict) else (data if isinstance(data,list) else [])
            courses = []
            for row in rows:
                c = course_from_row(row)
                if c.kcrwdm: courses.append(c)
            ct.courses = courses
            return courses
        except Exception as e:
            logger.debug(f"扫描课程失败 ({ct.name}): {e}")
            return []

    def scan_enrolled(self, ct: CourseType) -> List[dict]:
        try:
            if ct.controller=="jlxklist": params={"kzdm":ct.kzdm}
            elif ct.is_special: params={}
            else: params={"xkkzdm":ct.xkkzdm}
            r = self.s.post(EDU_PROXY + f"{ct.controller}!getXzkcList.action", data=params,
                headers={"Referer":EDU_PROXY,"X-Requested-With":"XMLHttpRequest",
                         "Content-Type":"application/x-www-form-urlencoded"}, timeout=15)
            data = r.json()
            return data if isinstance(data,list) else data.get("rows",[])
        except: return []

# ============================================================
# Part 3.5: 成绩查询（只读）
# ============================================================
class GradeService:
    """只调用教务系统的成绩 GET 查询接口。"""
    LIST_URL = "xskccjxx!getDataList.action"
    DETAIL_URL = "xskccjxx!getDetail.action"
    REFERER = "xskccjxx!xskccjList.action?firstquery=1"

    def __init__(self, session: requests.Session):
        self.s = session
        self.headers = {
            "Accept":"application/json, text/javascript, */*; q=0.01",
            "X-Requested-With":"XMLHttpRequest",
            "Referer":EDU_PROXY + self.REFERER,
        }

    def _get_json(self, path: str, params: dict):
        r = self.s.get(EDU_PROXY + path, params=params, headers=self.headers, timeout=15)
        r.raise_for_status()
        try:
            return r.json()
        except ValueError as e:
            raise RuntimeError("成绩接口未返回 JSON，登录可能已失效") from e

    def list_grades(self, semester: str = "") -> List[dict]:
        data = self._get_json(self.LIST_URL, {
            "page":"1",
            "rows":"500",
            "primarySort":" cjdm asc ",
            "xnxqdm":semester,
            "jhlxdm":"",
        })
        if isinstance(data, dict):
            rows = data.get("rows", [])
        elif isinstance(data, list):
            rows = data
        else:
            rows = []
        return rows if isinstance(rows, list) else []

    def get_detail(self, grade_id: str) -> dict:
        data = self._get_json(self.DETAIL_URL, {"cjdm":grade_id})
        if isinstance(data, list):
            return data[0] if data and isinstance(data[0], dict) else {}
        return data if isinstance(data, dict) else {}


class TimetableService:
    """只调用教务系统个人课表 GET 查询接口。"""
    TERMS_URL = "xsgrkbcx!getXsgrbkList.action"
    LIST_URL = "xsgrkbcx!xsAllKbList.action"
    REFERER = "xsgrkbcx!xsgrkbMain.action"

    def __init__(self, session: requests.Session):
        self.s = session
        self.headers = {
            "Accept":"text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8",
            "Referer":EDU_PROXY + self.REFERER,
        }

    def _get_text(self, path: str, params: Optional[dict] = None) -> str:
        r = self.s.get(EDU_PROXY + path, params=params or {}, headers=self.headers, timeout=20)
        r.raise_for_status()
        r.encoding = "utf-8"
        text = r.text or ""
        if "页面不存在" in text or "找不到页面" in text:
            raise RuntimeError("课表页面不存在或当前账号无权限")
        return text

    @staticmethod
    def _term_label_from_code(code: str) -> str:
        digits = re.sub(r"\D+", "", str(code or ""))
        if len(digits) >= 6:
            year = int(digits[:4])
            term = digits[-2:].lstrip("0") or digits[-1]
            return f"{year}-{year + 1}-{term}"
        if len(digits) >= 5:
            year = int(digits[:4])
            term = digits[-1]
            return f"{year}-{year + 1}-{term}"
        return str(code or "")

    def list_terms(self) -> List[dict]:
        text = self._get_text(self.TERMS_URL)
        select = re.search(
            r'<select[^>]+(?:id|name)=["\']xnxqdm["\'][^>]*>(.*?)</select>',
            text,
            re.I | re.S,
        )
        source = select.group(1) if select else text
        terms: List[dict] = []
        for match in re.finditer(r'<option([^>]*)value=["\']?([^"\'\s>]+)["\']?([^>]*)>(.*?)</option>', source, re.I | re.S):
            attrs = f"{match.group(1)} {match.group(3)}"
            code = html.unescape(match.group(2).strip())
            name = re.sub(r"\s+", " ", html.unescape(re.sub(r"<[^>]+>", "", match.group(4)))).strip()
            if not code:
                continue
            terms.append({
                "id": code,
                "name": name or self._term_label_from_code(code),
                "selected": "selected" in attrs.lower(),
            })
        return terms

    @staticmethod
    def _parse_number_list(value: Any) -> List[int]:
        nums = []
        for token in re.findall(r"\d+", str(value or "")):
            try:
                nums.append(int(token))
            except ValueError:
                pass
        return sorted(dict.fromkeys(nums))

    @staticmethod
    def _period_time_range(start: int, end: int) -> str:
        def _start(period: int) -> str:
            if 1 <= period < len(PERIOD_START) and PERIOD_START[period]:
                return PERIOD_START[period]
            base = datetime(2000, 1, 1, 8, 0) + timedelta(minutes=(period - 1) * 50)
            return base.strftime("%H:%M")

        def _end(period: int) -> str:
            if 1 <= period < len(PERIOD_END) and PERIOD_END[period]:
                return PERIOD_END[period]
            base = datetime(2000, 1, 1, 8, 40) + timedelta(minutes=(period - 1) * 50)
            return base.strftime("%H:%M")

        return f"{_start(start)}-{_end(end)}" if start and end else ""

    @staticmethod
    def _week_summary(weeks: List[int]) -> str:
        if not weeks:
            return ""
        ranges = []
        start = prev = weeks[0]
        for week in weeks[1:]:
            if week == prev + 1:
                prev = week
                continue
            ranges.append(f"{start}" if start == prev else f"{start}-{prev}")
            start = prev = week
        ranges.append(f"{start}" if start == prev else f"{start}-{prev}")
        return "、".join(ranges) + "周"

    def list_timetable(self, semester: str = "", terms: Optional[List[dict]] = None) -> dict:
        terms = terms if terms is not None else self.list_terms()
        selected = semester or next((item["id"] for item in terms if item.get("selected")), "")
        if not selected and terms:
            selected = terms[0]["id"]
        text = self._get_text(self.LIST_URL, {"xnxqdm": selected})
        match = re.search(r"var\s+kbxx\s*=\s*(\[.*?\])\s*;\s*\$\.each", text, re.S)
        raw_items = []
        if match:
            try:
                raw_items = json.loads(match.group(1))
            except ValueError:
                raw_items = []
        items = []
        for index, item in enumerate(raw_items):
            if not isinstance(item, dict):
                continue
            periods = self._parse_number_list(item.get("jcdm2"))
            weeks = self._parse_number_list(item.get("zcs"))
            day = _safe_int(item.get("xq"), 0)
            start = periods[0] if periods else 0
            end = periods[-1] if periods else 0
            items.append({
                "id": str(item.get("kcrwdm") or f"{selected}-{index}"),
                "course_name": str(item.get("kcmc") or ""),
                "course_code": str(item.get("kcbh") or ""),
                "class_name": str(item.get("jxbmc") or ""),
                "teacher": str(item.get("teaxms") or ""),
                "location": str(item.get("jxcdmcs") or ""),
                "day": day,
                "weekday": WEEKDAYS.get(day, f"周{day}" if day else ""),
                "periods": periods,
                "start_period": start,
                "end_period": end,
                "time": self._period_time_range(start, end),
                "weeks": weeks,
                "week_summary": self._week_summary(weeks),
                "raw": {
                    key: value for key, value in item.items()
                    if key in {"kcmc", "kcbh", "jxbmc", "kcrwdm", "jcdm2", "zcs", "xq", "jxcdmcs", "teaxms"}
                },
            })
        return {
            "semester": selected,
            "semester_name": next((item["name"] for item in terms if item["id"] == selected), self._term_label_from_code(selected)),
            "terms": terms,
            "items": items,
        }

def _grade_hidden(row: dict) -> bool:
    return str(row.get("wpj", "")) == "1" or str(row.get("wzc", "")) == "1"

def _number(value) -> Optional[float]:
    try:
        text = str(value).strip()
        return float(text) if text else None
    except (TypeError, ValueError):
        return None

def summarize_grades(rows: List[dict]) -> dict:
    """只统计有效且已公布的数字成绩。"""
    credits = 0.0
    score_weight = 0.0
    score_credits = 0.0
    gpa_weight = 0.0
    gpa_credits = 0.0
    failed = 0
    hidden = 0

    for row in rows:
        if str(row.get("isactive", "1")) == "0":
            continue
        credit = _number(row.get("xf"))
        if credit is not None:
            credits += credit
        if _grade_hidden(row):
            hidden += 1
            continue
        score = _number(row.get("zcj"))
        gpa = _number(row.get("cjjd"))
        if score is not None:
            if score < 60:
                failed += 1
            if credit is not None:
                score_weight += score * credit
                score_credits += credit
        elif str(row.get("zcj", "")).strip() in {"不及格", "不合格", "不通过", "未通过"}:
            failed += 1
        if gpa is not None and credit is not None:
            gpa_weight += gpa * credit
            gpa_credits += credit

    return {
        "credits":credits,
        "average":score_weight / score_credits if score_credits else None,
        "gpa":gpa_weight / gpa_credits if gpa_credits else None,
        "failed":failed,
        "hidden":hidden,
    }

def _text_width(text: str) -> int:
    return sum(2 if unicodedata.east_asian_width(ch) in "WFA" else 1 for ch in text)

def _fit_cell(value, width: int) -> str:
    text = str(value if value is not None else "")
    if _text_width(text) <= width:
        return text + " " * (width - _text_width(text))
    out = ""
    used = 0
    for ch in text:
        ch_width = 2 if unicodedata.east_asian_width(ch) in "WFA" else 1
        if used + ch_width > width - 2:
            break
        out += ch
        used += ch_width
    return out + ".." + " " * max(0, width - used - 2)

def _display_grades(rows: List[dict]):
    columns = [
        ("序", 4), ("学期", 13), ("课程", 28), ("成绩", 8),
        ("绩点", 7), ("学分", 7), ("考试性质", 12),
    ]
    print("\n" + " ".join(_fit_cell(name, width) for name, width in columns))
    print("-" * 86)
    for i, row in enumerate(rows, 1):
        hidden = _grade_hidden(row)
        score = "**" if hidden else row.get("zcj", "")
        gpa = "**" if hidden else row.get("cjjd", "")
        exam = str(row.get("ksxzmc", ""))
        if str(row.get("isactive", "1")) == "0":
            exam += "[无效]"
        values = [
            i, row.get("xnxqmc", row.get("xnxqdm", "")), row.get("kcmc", ""),
            score, gpa, row.get("xf", ""), exam,
        ]
        print(" ".join(_fit_cell(value, width) for value, (_, width) in zip(values, columns)))

    summary = summarize_grades(rows)
    average = f"{summary['average']:.2f}" if summary["average"] is not None else "--"
    gpa = f"{summary['gpa']:.3f}" if summary["gpa"] is not None else "--"
    print("-" * 86)
    print(
        f"共 {len(rows)} 门 | 课程学分合计 {summary['credits']:g} | "
        f"加权平均分 {average} | 加权平均绩点 {gpa} | 不及格 {summary['failed']} 门"
        + (f" | 待公布 {summary['hidden']} 门" if summary["hidden"] else "")
    )

def _display_grade_detail(service: GradeService, row: dict):
    print(f"\n[{row.get('kcmc', '?')}] 成绩明细")
    if _grade_hidden(row):
        notes = [str(row.get(k, "")).strip() for k in ("wpjbz", "wzcbz")]
        print("成绩尚未公布" + (f": {'; '.join(x for x in notes if x)}" if any(notes) else ""))
        return
    grade_id = str(row.get("cjdm", "")).strip()
    if not grade_id:
        print("该成绩没有明细编号")
        return
    try:
        detail = service.get_detail(grade_id)
    except Exception as e:
        logger.error(f"成绩明细读取失败: {e}")
        return
    if not detail:
        print("暂无分项明细")
        return

    if str(detail.get("bkcj", "")).strip():
        print(f"  补考成绩: {detail.get('bkcj', '')}")
    else:
        defaults = ["平时成绩", "实验成绩", "期中成绩", "期末成绩"]
        for i, default_name in enumerate(defaults, 1):
            score = str(detail.get(f"cj{i}", "")).strip()
            if not score:
                continue
            name = str(detail.get(f"bl{i}mc", "")).strip() or default_name
            ratio = str(detail.get(f"bl{i}", "")).strip()
            suffix = f" × {ratio}%" if ratio else ""
            print(f"  {name}: {score}{suffix}")
    print(f"  总成绩: {detail.get('zcj', row.get('zcj', ''))}")

def interactive_grade_query(session: requests.Session):
    """登录后的只读成绩查询菜单。"""
    print("\n" + "=" * 60)
    print("  成绩查询（只读）")
    print("=" * 60)
    service = GradeService(session)
    try:
        all_rows = service.list_grades()
    except Exception as e:
        logger.error(f"成绩读取失败: {e}")
        return
    if not all_rows:
        print("\n暂无成绩数据")
        return

    semesters = {}
    for row in all_rows:
        code = str(row.get("xnxqdm", "")).strip()
        if code:
            semesters[code] = str(row.get("xnxqmc", code)).strip() or code
    semester_items = sorted(semesters.items(), key=lambda item:item[0], reverse=True)

    while True:
        print("\n选择学期:")
        print(f"  [0] 全部 ({len(all_rows)}门)")
        for i, (code, name) in enumerate(semester_items, 1):
            count = sum(str(row.get("xnxqdm", "")) == code for row in all_rows)
            print(f"  [{i}] {name} ({count}门)")
        print("  [b] 返回功能菜单")
        choice = input("> ").strip().lower()
        if choice == "b":
            return
        try:
            index = int(choice)
        except ValueError:
            print("无效")
            continue
        if index == 0:
            rows = list(all_rows)
        elif 1 <= index <= len(semester_items):
            semester = semester_items[index - 1][0]
            rows = [row for row in all_rows if str(row.get("xnxqdm", "")) == semester]
        else:
            print("无效")
            continue
        rows.sort(key=lambda row:(str(row.get("xnxqdm", "")), str(row.get("kcmc", ""))), reverse=True)
        _display_grades(rows)

        while True:
            detail_choice = input("\n输入序号查看明细，[r] 重选学期，[b] 返回功能菜单: ").strip().lower()
            if detail_choice == "b":
                return
            if detail_choice == "r":
                break
            try:
                detail_index = int(detail_choice) - 1
                if 0 <= detail_index < len(rows):
                    _display_grade_detail(service, rows[detail_index])
                else:
                    print("无效")
            except ValueError:
                print("无效")

# ============================================================
# Part 4: 微秒级异步抢课引擎
# ============================================================
class MicroGrabber:
    """
    微秒级触发引擎 v2.0:
    - 预编码 HTTP 请求字节 (零构建延迟)
    - 1ms 间隔轮询 (1000次/秒)
    - asyncio.gather() 同 tick 齐射 (<500us 内全部发出)
    - 预发射模式: 窗口开启前持续发送, 确保请求已在服务器TCP缓冲区

    原理:
      服务器选课窗口开启的瞬间, 它的 TCP 栈会开始 accept() 连接并处理 HTTP 请求.
      我们在窗口开启前就维持 N 个 keep-alive 连接, 每 1ms 检查一次 getDataList.
      检测到数据的同一毫秒内, N 个预编码的 getAdd 请求通过 gather() 同时写入 socket,
      成为服务器启动后处理的第一批请求.
    """

    def __init__(
        self,
        cookies: dict,
        pool_size: int = 16,
        *,
        retry_ms: int = 1000,
        prefire: bool = False,
        prefire_interval_ms: int = 200,
        proxy: Optional[str] = None,
        notify: bool = True,
    ):
        self.cookies = cookies
        self.pool_size = max(1, int(pool_size or 1))
        self.retry_ms = max(200, int(retry_ms or 1000))
        self.prefire = bool(prefire)
        self.prefire_interval_ms = max(50, int(prefire_interval_ms or 200))
        self.proxy = proxy
        self.notify = bool(notify)
        self._connector: Optional[aiohttp.TCPConnector] = None
        self._sessions: List[aiohttp.ClientSession] = []
        self._ct: Optional[CourseType] = None
        self._targets: List[Course] = []
        self._grabbed = set()
        self._first_done = False
        self._notified_success = False
        self._notified_failure = False
        self._headers = {
            "User-Agent":"Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36",
            "Accept":"application/json, text/javascript, */*; q=0.01",
            "Accept-Language":"zh-CN,zh;q=0.9",
            "X-Requested-With":"XMLHttpRequest",
            "Connection":"keep-alive",
        }
        # 预编码的请求数据 (避免每次构建)
        self._encoded_select_bodies: dict = {}   # kcrwdm → urlencoded bytes
        self._encoded_search_body: bytes = b""
        self._poll_timeout = aiohttp.ClientTimeout(total=3, connect=2, sock_read=2)
        self._submit_timeout = aiohttp.ClientTimeout(total=6, connect=2, sock_read=5)

    async def _warm_up(self):
        """预热: 创建连接池 + 预编码所有请求体"""
        self._connector = aiohttp.TCPConnector(
            limit=self.pool_size,
            limit_per_host=self.pool_size,
            force_close=False,
            enable_cleanup_closed=False,
            keepalive_timeout=300,
            ttl_dns_cache=3600,
        )

        cookie_jar = aiohttp.CookieJar(unsafe=True)
        cookie_jar.update_cookies({str(k): str(v) for k, v in self.cookies.items()})

        for _ in range(self.pool_size):
            session = aiohttp.ClientSession(
                connector=self._connector,
                connector_owner=False,
                cookie_jar=cookie_jar,
                headers=self._headers,
            )
            self._sessions.append(session)

        async def _touch(session: aiohttp.ClientSession):
            try:
                async with session.get(
                    EDU_PROXY,
                    proxy=self.proxy,
                    timeout=aiohttp.ClientTimeout(total=10),
                ) as resp:
                    await resp.read()  # 必须释放响应，否则连接不会回到 keep-alive 池
                    return True
            except Exception as e:
                logger.debug(f"预热连接失败: {e}")
                return False

        # 首轮会用满连接池；全部提前握手，避免其余连接在开窗时才做 TCP/TLS 建连。
        warm_tasks = [_touch(s) for s in self._sessions]
        results = await asyncio.gather(*warm_tasks, return_exceptions=True)
        ready = sum(result is True for result in results)

        logger.success(f"连接池 + TCP/TLS预热: {ready}/{self.pool_size} 就绪")

    def _encode_select(self, ct: CourseType, course: Course) -> bytes:
        """预编码选课请求体"""
        key = (ct.controller, ct.xkkzdm, ct.kzdm, course.kcrwdm)
        if key not in self._encoded_select_bodies:
            params = {"kcrwdm": course.kcrwdm, "kcmc": course.name, "tzjf": "0"}
            if ct.controller=="jlxklist":
                params["kzdm"] = ct.kzdm
            elif not ct.is_special:
                params["xkkzdm"] = ct.xkkzdm
            # 不能手写 "a=b&kcmc=中文"：课程名包含中文、空格、& 时会提交错。
            self._encoded_select_bodies[key] = urlencode(params).encode("utf-8")
        return self._encoded_select_bodies[key]

    async def _poll_once(self, session: aiohttp.ClientSession, ct: CourseType) -> Optional[List[Course]]:
        """1ms 轮询: 检查选课窗口是否开启"""
        params = {"page":"1","rows":"500"}
        if not ct.is_special:
            if ct.controller=="jlxklist": params["kzdm"]=ct.kzdm
            else: params["xkkzdm"]=ct.xkkzdm

        try:
            async with session.post(EDU_PROXY + f"{ct.controller}!getDataList.action",
                                     data=params, proxy=self.proxy,
                                     timeout=self._poll_timeout) as resp:
                text = await resp.text()
                if not text or len(text) < 10: return None
                data = json.loads(text)
                rows = data.get("rows",[]) if isinstance(data,dict) else (data if isinstance(data,list) else [])
                if not rows: return None
                courses = []
                for row in rows:
                    c = course_from_row(row)
                    if c.kcrwdm:
                        courses.append(c)
                return courses if courses else None
        except Exception as e:
            logger.debug(f"轮询失败: {e}")
            return None

    async def _fire_one_raw(self, session: aiohttp.ClientSession, ct: CourseType,
                             course: Course) -> Tuple[str, bool, str, float]:
        """单次选课请求 (预编码body, 零构建开销)"""
        body = self._encode_select(ct, course)
        t0 = time.perf_counter()
        try:
            async with session.post(EDU_PROXY + f"{ct.controller}!getAdd.action",
                                     data=body,
                                     headers={"Content-Type":"application/x-www-form-urlencoded; charset=UTF-8",
                                              "Referer":EDU_PROXY,
                                              "X-Requested-With":"XMLHttpRequest"},
                                     proxy=self.proxy, timeout=self._submit_timeout) as resp:
                text = await resp.text()
                lat = (time.perf_counter()-t0)*1_000_000
                return (course.kcrwdm, text.strip()=="1", text[:80], lat)
        except asyncio.TimeoutError:
            return (course.kcrwdm, False, "timeout", (time.perf_counter()-t0)*1_000_000)
        except Exception as e:
            return (course.kcrwdm, False, str(e)[:60], (time.perf_counter()-t0)*1_000_000)

    async def _volley_one(
        self,
        ct: CourseType,
        course: Course,
        active_sessions: List[aiohttp.ClientSession],
        priority: int,
    ) -> bool:
        """Use the full connection group for one priority before falling back."""
        if self._first_done:
            return True

        tasks = []
        for session in active_sessions:
            tasks.append(asyncio.create_task(self._fire_one_raw(session, ct, course)))

        t0 = time.perf_counter()
        results = []
        pending = set(tasks)
        try:
            while pending:
                done, pending = await asyncio.wait(pending, return_when=asyncio.FIRST_COMPLETED)
                for task in done:
                    try:
                        result = task.result()
                    except Exception as e:
                        result = e
                    results.append(result)
                    if isinstance(result, tuple) and result[1]:
                        self._grabbed.add(result[0])
                        self._first_done = True
                if self._first_done and pending:
                    for task in pending:
                        task.cancel()
                    await asyncio.gather(*pending, return_exceptions=True)
                    pending.clear()
        finally:
            if pending:
                for task in pending:
                    task.cancel()
                await asyncio.gather(*pending, return_exceptions=True)
        elapsed = (time.perf_counter()-t0)*1_000_000

        success = False
        failures: Dict[str, int] = {}
        for r in results:
            if isinstance(r, tuple) and r[1]:
                kcrwdm, ok, msg, lat = r
                self._grabbed.add(kcrwdm)
                success = True
                logger.success(f"抢课成功! kcrwdm={kcrwdm[-6:]} ({lat:.0f}us)")
            elif isinstance(r, tuple):
                msg = (r[2] or "").strip()[:80]
                failures[msg] = failures.get(msg, 0) + 1
            elif isinstance(r, Exception):
                msg = str(r)[:80]
                failures[msg] = failures.get(msg, 0) + 1

        logger.info(
            f"志愿{priority}齐射: {course.name} / {course.teacher or '待定'} / "
            f"{len(tasks)}请求 {elapsed:.0f}us, 成功={success}"
        )
        if failures:
            brief = "; ".join(f"{k or '<empty>'}×{v}" for k, v in list(failures.items())[:3])
            logger.debug(f"志愿{priority}失败摘要: {brief}")

        return success or self._first_done

    async def _volley(
        self,
        ct: CourseType,
        targets: List[Course],
        sessions: Optional[List[aiohttp.ClientSession]] = None,
        *,
        notify_failure: bool = True,
    ):
        """Try at most three unique targets strictly in user-defined order."""
        ordered_targets: List[Course] = []
        seen_ids = set()
        for course in targets:
            if course.kcrwdm in seen_ids:
                continue
            seen_ids.add(course.kcrwdm)
            ordered_targets.append(course)
            if len(ordered_targets) == 3:
                break

        if not ordered_targets:
            logger.debug("齐射跳过: 未指定目标课程")
            return False

        active_sessions = sessions if sessions is not None else self._sessions
        if not active_sessions:
            logger.debug("齐射跳过: 没有可用连接")
            return False

        for priority, course in enumerate(ordered_targets, start=1):
            logger.info(
                f"尝试志愿{priority}/{len(ordered_targets)}: "
                f"{course.name} / {course.teacher or '待定'}"
            )
            if await self._volley_one(ct, course, active_sessions, priority):
                if self.notify and not self._notified_success:
                    self._notified_success = True
                    open_qq()
                    desktop_notify("抢课结果", "抢到了!")
                    beep()
                return True
            if priority < len(ordered_targets):
                logger.info(f"志愿{priority}未成功，切换志愿{priority + 1}")

        if self.notify and notify_failure and not self._notified_failure:
            self._notified_failure = True
            desktop_notify("抢课结果", "本次提交失败，继续重试中...")
        return False

    async def _fire_boundary_waves(
        self,
        ct: CourseType,
        targets: List[Course],
        start_dt: datetime,
        server_delta: timedelta,
        lead_ms: int,
        wave_count: int,
        wave_gap_ms: int,
    ) -> bool:
        """Spread the pre-warmed connections across the opening boundary."""
        if not targets or not self._sessions:
            return False

        configured_waves = max(1, int(wave_count or 1))
        effective_waves = min(configured_waves, len(self._sessions))
        groups = [self._sessions[index::effective_waves] for index in range(effective_waves)]

        if effective_waves == 1:
            boundary_index = min(
                configured_waves - 1,
                max(0, round(lead_ms / max(1, wave_gap_ms))),
            )
            wave_indexes = [boundary_index]
        elif effective_waves < configured_waves:
            wave_indexes = [
                round(index * (configured_waves - 1) / (effective_waves - 1))
                for index in range(effective_waves)
            ]
        else:
            wave_indexes = list(range(effective_waves))

        tasks: List[asyncio.Task] = []
        fire_dt = start_dt - timedelta(milliseconds=lead_ms)
        for group, wave_index in zip(groups, wave_indexes):
            wave_dt = fire_dt + timedelta(milliseconds=wave_index * wave_gap_ms)
            await self._sleep_until_server_time(wave_dt, server_delta, "等待边界波次")
            if self._first_done:
                break
            offset_ms = (wave_dt - start_dt).total_seconds() * 1000
            logger.info(
                f"边界波次 {len(tasks)+1}/{effective_waves}: "
                f"{len(group)}条连接, 计划偏移 {offset_ms:+.0f}ms"
            )
            tasks.append(
                asyncio.create_task(
                    self._volley(ct, targets, group, notify_failure=False)
                )
            )
            await asyncio.sleep(0)

        success = False
        pending = set(tasks)
        try:
            while pending:
                done, pending = await asyncio.wait(
                    pending, return_when=asyncio.FIRST_COMPLETED
                )
                for task in done:
                    try:
                        success = bool(task.result()) or success
                    except Exception as exc:
                        logger.debug(f"边界波次异常: {exc}")
                if success or self._first_done:
                    for task in pending:
                        task.cancel()
                    await asyncio.gather(*pending, return_exceptions=True)
                    pending.clear()
        finally:
            if pending:
                for task in pending:
                    task.cancel()
                await asyncio.gather(*pending, return_exceptions=True)

        return success or self._first_done

    async def _prefire_loop(self, ct: CourseType, course: Course, session_idx: int):
        """
        预发射循环: 按固定间隔试探提交，并且读取/释放响应。
        注意：旧版 fire-and-forget 不读取响应，会把连接池耗尽，也无法知道是否成功。
        """
        session = self._sessions[session_idx % self.pool_size]
        count = 0
        while not self._first_done:
            try:
                kcrwdm, ok, msg, lat = await self._fire_one_raw(session, ct, course)
                count += 1
                if ok:
                    self._grabbed.add(kcrwdm)
                    self._first_done = True
                    if self.notify:
                        open_qq()
                        desktop_notify("抢课结果", "抢到了!")
                        beep()
                    logger.success(f"预发射成功! kcrwdm={kcrwdm[-6:]} ({lat:.0f}us)")
                    break
                if count % 20 == 0:
                    logger.debug(f"  预发射[{session_idx}]: {count}次，最近响应={msg[:60]}")
            except Exception as e:
                logger.debug(f"预发射[{session_idx}]异常: {e}")
            await asyncio.sleep(self.prefire_interval_ms / 1000.0)

        logger.debug(f"预发射[{session_idx}] 停止: {count}次")

    async def _wait_and_fire(
        self,
        ct: CourseType,
        targets: List[Course],
        poll_ms: int = 1,
        *,
        jitter_ms: int = 0,
        max_wait_hours: Optional[float] = None,
        session_refresher: Optional[Callable[[], Awaitable[dict]]] = None,
    ):
        """
        核心: 预发射 + 1ms轮询 + 检测齐射 三重保障

        策略:
          1. 一半连接做预发射 (持续发送getAdd, 不等响应)
          2. 一个连接做轮询检测 (1ms检查getDataList)
          3. 检测到数据后所有连接齐射确认
        """
        poll_ms = max(1, int(poll_ms or 1))
        jitter_ms = max(0, int(jitter_ms or 0))
        watch_mode = max_wait_hours is not None
        wait_hours = min(720.0, max(0.0, float(max_wait_hours or 0.0)))
        poll_s = self._sessions[0]

        # 分配: 前半做预发射, 后半做齐射备份
        half = max(1, self.pool_size // 2)
        pref_sessions = self._sessions[:half]
        fire_sessions = self._sessions[half:]

        # 预发射默认关闭。旧版无目标/未开窗时会持续 fire-and-forget，容易耗尽连接池。
        pref_tasks = []
        if self.prefire and targets and not watch_mode:
            # 预发射只保护第一志愿，避免低优先级课程与第一志愿同时提交。
            pref_tasks.append(asyncio.create_task(self._prefire_loop(ct, targets[0], 0)))

        logger.info(f"预发射: {'开启' if pref_tasks else '关闭'}" + (f" ({len(pref_tasks)}协程, {self.prefire_interval_ms}ms间隔)" if pref_tasks else ""))
        jitter_text = f" ± {jitter_ms}ms随机" if jitter_ms else ""
        logger.info(f"轮询检测: 每{poll_ms}ms{jitter_text}")
        if watch_mode:
            logger.info(f"蹲退选挂机: 最长 {wait_hours:g} 小时，目标出现余量后才提交")
        logger.info(f"齐射备份: {len(fire_sessions)}连接待命")
        logger.info(f"目标: {len(targets)}门 → {[t.kcrwdm[-6:] for t in targets]}")
        if not targets:
            logger.warning("未指定目标课程：将只监控窗口并展示可选课程，不会自动提交任意课程。")
        logger.info("选课窗口开启后按目标课程提交；失败会按重试间隔继续尝试。\n")

        check = 0; start = time.perf_counter(); had_data = False; last_fire = 0.0
        deadline = start + wait_hours * 3600 if watch_mode else None
        next_refresh = (
            start + _JITTER_RNG.uniform(80 * 60, 100 * 60)
            if watch_mode and session_refresher is not None
            else None
        )

        try:
            while True:
                now = time.perf_counter()
                if deadline is not None and now >= deadline:
                    logger.warning(f"蹲退选挂机已达到 {wait_hours:g} 小时上限，任务结束")
                    break
                if next_refresh is not None and now >= next_refresh:
                    logger.info("长挂机会话刷新中...")
                    try:
                        refreshed_cookies = await session_refresher()
                        self.cookies = refreshed_cookies
                        await self._close()
                        await self._warm_up()
                        poll_s = self._sessions[0]
                        logger.success("长挂机会话与连接池已刷新")
                    except Exception as exc:
                        logger.warning(f"长挂机会话刷新失败，将继续使用当前会话: {exc}")
                    next_refresh = time.perf_counter() + _JITTER_RNG.uniform(80 * 60, 100 * 60)

                check += 1
                courses = await self._poll_once(poll_s, ct)

                if courses:
                    if not had_data:
                        elapsed = (time.perf_counter()-start)*1000
                        logger.success(f"[检测{check}] 窗口已开 ({elapsed:.0f}ms)")

                        # 显示当前课程
                        for c in sorted(courses, key=lambda x:-x.remaining)[:10]:
                            logger.info(f"  {c.teacher:6s} | {c.section[:30]} | 余{c.remaining}")

                    if targets:
                        # 只提交用户选中的目标。旧版 targets 为空时会退化成“任意可选课第一门”，风险很高。
                        live_courses = {course.kcrwdm:course for course in courses}
                        hit = []
                        for target in targets:
                            current = live_courses.get(target.kcrwdm)
                            if current and current.available:
                                hit.append(current)
                        if not hit:
                            logger.debug("窗口有数据，但目标课程暂无余量/未出现在列表中")
                        now = time.perf_counter()
                        if hit and (now - last_fire) * 1000 >= self.retry_ms:
                            logger.info(f"齐射确认: {len(hit)}目标 × {self.pool_size}连接")
                            last_fire = now
                            await self._volley(ct, hit)

                    had_data = True
                else:
                    if had_data:
                        logger.info("窗口关闭")
                        had_data = False

                # 如果抢到了, 停止
                if self._first_done:
                    logger.success("目标课程提交成功，监控30秒后退出...")
                    await asyncio.sleep(30)
                    break

                if check % 1000 == 0:
                    elapsed = time.perf_counter()-start
                    logger.debug(f"[{check}] {elapsed:.0f}s 监控中...")

                await asyncio.sleep(
                    _jittered_delay_seconds(
                        poll_ms, jitter_ms, minimum_ms=50 if watch_mode else 1
                    )
                )
        finally:
            for t in pref_tasks:
                t.cancel()
            if pref_tasks:
                await asyncio.gather(*pref_tasks, return_exceptions=True)

    async def _sleep_until_server_time(self, target_dt: datetime, server_delta: timedelta, label: str = ""):
        """按校准后的服务器时间等待到目标时刻。"""
        target_utc = target_dt.astimezone(timezone.utc)
        while True:
            remain = (target_utc - server_now(server_delta)).total_seconds()
            if remain <= 0:
                return
            if remain > 60:
                logger.info(f"{label} 剩余 {remain:.1f}s")
                await asyncio.sleep(min(30, remain - 30))
            elif remain > 5:
                await asyncio.sleep(min(1, remain - 3))
            elif remain > 0.5:
                await asyncio.sleep(min(0.1, remain - 0.2))
            elif remain > 0.02:
                await asyncio.sleep(min(0.01, remain))
            else:
                # 最后 20ms 不做 busy wait，只让出事件循环，尽量贴近目标时间。
                await asyncio.sleep(0)

    async def _timed_fire(
        self,
        ct: CourseType,
        targets: List[Course],
        window: dict,
        server_delta: timedelta,
        warmup_ms: int = 8000,
        lead_ms: int = 80,
        burst_count: int = 5,
        burst_gap_ms: int = 40,
        monitor_after_success: int = 30,
        time_calibrator: Optional[Callable[[], Awaitable[timedelta]]] = None,
        recalibrate_before_ms: int = 10000,
    ):
        """
        极速定时模式：
        - 登录后先由用户选择目标；
        - 开窗前重新校准服务器时间；
        - 按服务器时间等到开始前 warmup_ms 再预热连接；
        - 把连接池拆成多个独立波次，跨开放边界提交；
        - 失败按 self.retry_ms 重试，不退化成任意课程。
        """
        if not targets:
            logger.warning("未指定目标课程，极速定时模式不会提交任何课程。")
            return False

        warmup_ms = max(0, int(warmup_ms or 0))
        lead_ms = max(0, int(lead_ms or 0))
        burst_count = max(1, int(burst_count or 1))
        burst_gap_ms = max(1, int(burst_gap_ms or 1))
        recalibrate_before_ms = max(0, int(recalibrate_before_ms or 0))
        min_warmup_ms = max(3000, lead_ms + 1000)
        if warmup_ms < min_warmup_ms:
            logger.warning(f"预热时间 {warmup_ms}ms 小于提前提交 {lead_ms}ms + 安全余量，自动提高到 {min_warmup_ms}ms")
            warmup_ms = min_warmup_ms
        start_dt = window["start"]
        end_dt = window.get("end")
        now_cn = server_now(server_delta).astimezone(CN_TZ)
        target_ids = [t.kcrwdm[-6:] for t in targets]

        logger.info("极速定时模式已启用:")
        logger.info(f"  服务器当前时间: {now_cn.strftime('%Y-%m-%d %H:%M:%S.%f')[:-3]}")
        logger.info(f"  开始时间: {start_dt.strftime('%Y-%m-%d %H:%M:%S.%f')[:-3]}")
        if end_dt:
            logger.info(f"  结束时间: {end_dt.strftime('%Y-%m-%d %H:%M:%S')}")
        logger.info(f"  预热提前: {warmup_ms}ms")
        logger.info(f"  首波提前: {lead_ms}ms")
        logger.info(f"  边界波次: {burst_count}波 × 间隔{burst_gap_ms}ms")
        logger.info(f"  失败重试: {self.retry_ms}ms")
        logger.info(f"  目标: {len(targets)}门 → {target_ids}")

        recalibrate_lead_ms = max(recalibrate_before_ms, warmup_ms + 2000)
        recalibrate_dt = start_dt - timedelta(milliseconds=recalibrate_lead_ms)
        if time_calibrator is not None and now_cn < recalibrate_dt:
            await self._sleep_until_server_time(
                recalibrate_dt, server_delta, "等待二次校时"
            )
            logger.info("开窗前二次校准服务器时间...")
            try:
                server_delta = await time_calibrator()
                now_cn = server_now(server_delta).astimezone(CN_TZ)
                logger.success(
                    f"二次校时完成，服务器当前时间: "
                    f"{now_cn.strftime('%Y-%m-%d %H:%M:%S.%f')[:-3]}"
                )
            except Exception as exc:
                logger.warning(f"二次校时失败，继续使用首次校时结果: {exc}")

        warm_dt = start_dt - timedelta(milliseconds=warmup_ms)
        if now_cn < warm_dt:
            await self._sleep_until_server_time(warm_dt, server_delta, "等待预热")

        if not self._sessions:
            logger.info("开始预热连接池...")
            await self._warm_up()
        else:
            logger.debug("连接池已预热，跳过重复预热")

        logger.success(
            f"连接池已就绪，按 {burst_count} 个波次跨开放边界提交目标课程!"
        )
        ok = await self._fire_boundary_waves(
            ct,
            targets[:1],
            start_dt,
            server_delta,
            lead_ms,
            burst_count,
            burst_gap_ms,
        )
        if ok or self._first_done:
            logger.success("目标课程提交成功，监控结束后退出...")
            await asyncio.sleep(monitor_after_success)
            return True

        attempt = burst_count
        logger.info("第一志愿边界波次未成功，按志愿顺序进入完整连接池持续重试。")
        while not self._first_done:
            now_cn = server_now(server_delta).astimezone(CN_TZ)
            if end_dt and now_cn > end_dt:
                logger.warning("选课窗口已结束，停止定时提交。")
                break

            attempt += 1
            offset_ms = (now_cn - start_dt).total_seconds() * 1000
            logger.info(f"持续重试第 {attempt} 轮，服务器偏移 {offset_ms:+.0f}ms")
            round_started = time.perf_counter()
            ok = await self._volley(ct, targets)
            if ok or self._first_done:
                logger.success("目标课程提交成功，监控30秒后退出...")
                await asyncio.sleep(monitor_after_success)
                return True

            remain = self.retry_ms / 1000.0 - (time.perf_counter() - round_started)
            if remain > 0:
                await asyncio.sleep(remain)

        return self._first_done

    async def _close(self):
        for s in self._sessions:
            with contextlib.suppress(Exception):
                await s.close()
        self._sessions.clear()
        if self._connector and not self._connector.closed:
            with contextlib.suppress(Exception):
                await self._connector.close()

# ============================================================
# Part 5: 交互式选菜单
# ============================================================
def format_window(raw: dict) -> list:
    """格式化选课时间窗口 + 倒计时"""
    from datetime import datetime
    now = datetime.now()
    windows = []
    for stage, (sk, ek) in enumerate([('qssj1','jssj1'),('qssj2','jssj2'),('qssj3','jssj3')]):
        qs = raw.get(sk,'').strip()
        js = raw.get(ek,'').strip()
        if qs and js:
            try:
                qs_dt = datetime.strptime(qs, "%Y-%m-%d %H:%M:%S")
                js_dt = datetime.strptime(js, "%Y-%m-%d %H:%M:%S")
                if now < qs_dt:
                    diff = qs_dt - now
                    d,h,m = diff.days, diff.seconds//3600, (diff.seconds%3600)//60
                    windows.append((f"第{stage+1}轮: {qs} ~ {js}", f"距离开启: {d}天{h}时{m}分"))
                elif qs_dt <= now <= js_dt:
                    diff = js_dt - now
                    d,h,m = diff.days, diff.seconds//3600, (diff.seconds%3600)//60
                    windows.append((f"第{stage+1}轮: {qs} ~ {js}", f"进行中! 剩余{d}天{h}时{m}分"))
                else:
                    windows.append((f"第{stage+1}轮: {qs} ~ {js}", "已结束"))
            except: pass
    return windows

def interactive_select(scanner: Scanner) -> Tuple[Optional[CourseType], List[Course]]:
    """交互式选择: 扫描 → 显示 → 用户选 → 返回目标"""

    print("\n" + "=" * 60)
    print("  扫描选课系统 (只读, 不会修改任何数据)")
    print("=" * 60)

    types = scanner.scan_types()
    if not types:
        logger.warning("当前无可用选课类型")
        return None, []

    print(f"\n发现 {len(types)} 种选课类型:\n")
    for i, t in enumerate(types):
        tips = ""
        if t.raw.get("xk_tips"):
            tips = t.raw["xk_tips"].replace("&mdash;","—").replace("&amp;","&")[:120]
        # 时间窗口 + 倒计时
        windows = format_window(t.raw)
        if windows:
            win_lines = []
            for win_str, countdown in windows:
                win_lines.append(f"{win_str} [{countdown}]")
            print(f"  [{i+1}] {t.name}  {' | '.join(win_lines)}")
        else:
            print(f"  [{i+1}] {t.name}")
        if tips: print(f"      {tips}")

    while True:
        try:
            choice = input(f"\n选类型 [1-{len(types)}]: ").strip()
            idx = int(choice)-1
            if 0 <= idx < len(types): ct = types[idx]; break
        except: pass
        print("无效")

    print(f"\n已选: [{ct.name}]")
    print(f"扫描课程...")

    courses = scanner.scan_courses(ct)

    if not courses:
        logger.warning("当前无课程数据 (选课窗口未开)")
        enrolled = scanner.scan_enrolled(ct)
        if enrolled:
            print(f"\n已选 ({len(enrolled)}门):")
            for e in enrolled:
                print(f"  {e.get('kcmc','?')} - {e.get('jxbmc',e.get('xmmc','?'))}")
        return ct, []

    # 加载已选课程。注意：同一门课的不同教学班通常 kcdm 相同，
    # 不能用 kcdm 判断“这一行已选”，否则会把同一门课的所有班都误标成 [已选]。
    enrolled_list = scanner.scan_enrolled(ct)
    enrolled_kcrwdm = {str(e.get("kcrwdm","")) for e in enrolled_list if str(e.get("kcrwdm",""))}
    enrolled_jxbdm = {str(e.get("jxbdm","")) for e in enrolled_list if str(e.get("jxbdm",""))}
    enrolled_kcdm = {str(e.get("kcdm","")) for e in enrolled_list if str(e.get("kcdm",""))}
    enrolled_sections = {str(e.get("jxbmc", e.get("xmmc",""))) for e in enrolled_list}
    enrolled_times = []
    for e in enrolled_list:
        et = parse_time(str(e.get("xmmc","")))
        if et: enrolled_times.append(et)

    def is_exact_enrolled(c: Course) -> bool:
        return (
            (c.kcrwdm and c.kcrwdm in enrolled_kcrwdm) or
            (c.jxbdm and c.jxbdm in enrolled_jxbdm) or
            (c.section and c.section in enrolled_sections)
        )

    def is_same_course_selected(c: Course) -> bool:
        return bool(c.kcdm and c.kcdm in enrolled_kcdm)

    # 按课程名称分组
    course_groups = {}
    for c in courses:
        name = c.name or "其他"
        if name not in course_groups: course_groups[name] = []
        course_groups[name].append(c)

    # 只把“有名额且未选过同一门课程”的班放进可选列表。
    # 已经选过同一 kcdm 的其它教学班，前端 JS 也会拦截“你已经选过该课程”，所以不应继续显示成可选。
    available_groups = {}
    duplicate_groups = {}
    for name, clist in course_groups.items():
        avail = [c for c in clist if c.available and not is_same_course_selected(c)]
        dup = [c for c in clist if c.available and is_same_course_selected(c) and not is_exact_enrolled(c)]
        if avail:
            available_groups[name] = avail
        if dup:
            duplicate_groups[name] = dup

    GREEN = '\033[92m'
    RESET = '\033[0m'
    YELLOW = '\033[93m'
    RED = '\033[91m'
    CYAN = '\033[96m'

    print(f"\n可选课程 ({sum(len(v) for v in available_groups.values())}个班):")
    if enrolled_list:
        print(f"{GREEN}已选 {len(enrolled_list)}门: {', '.join(e.get('jxbmc',e.get('xmmc','?')) for e in enrolled_list)}{RESET}")
    print()

    idx = 1
    index_map = {}
    for name, clist in sorted(available_groups.items()):
        print(f"  [{idx}] {name} ({len(clist)}个班可选)")
        index_map[idx] = clist
        for c in clist:
            time_str = f" {c.time_info}" if c.time_info else ""
            already = f" {GREEN}[已选]{RESET}" if is_exact_enrolled(c) else ""
            # Check time conflict with enrolled
            conflict = ""
            if not already and c.time_info:
                for et in enrolled_times:
                    if et and et.split('节')[0] == c.time_info.split('节')[0]:
                        conflict = f" {RED}[时间冲突]{RESET}"
                        break
            print(f"       {YELLOW}余{c.remaining:>4}{RESET} | {c.teacher:6s} | {c.section[:35]}{time_str}{already}{conflict}")
        idx += 1

    if duplicate_groups:
        print(f"\n{CYAN}已选同一课程的其它班（不列入可选，直接选会被系统提示“你已经选过该课程”）:{RESET}")
        for name, clist in sorted(duplicate_groups.items()):
            print(f"  - {name} ({len(clist)}个班)")
            for c in clist:
                time_str = f" {c.time_info}" if c.time_info else ""
                print(f"       余{c.remaining:>4} | {c.teacher:6s} | {c.section[:35]}{time_str} {CYAN}[同课程已选]{RESET}")

    if not available_groups:
        print("\n当前没有可重复选择的新课程。")
        return ct, []

    print(f"\n  [1-{len(available_groups)}] 选择课程")
    print(f"  [q] 退出")
    print(f"\n  {GREEN}绿色{RESET}=精确已选班  {YELLOW}黄色{RESET}=有余量  {RED}红色{RESET}=时间冲突  {CYAN}青色{RESET}=同课程已选")

    choices = []
    while True:
        s = input("> ").strip().lower()
        if s == 'q': return ct, []
        try:
            idx = int(s)
            if idx in index_map:
                choices = index_map[idx]
                # 如果有多个班, 让用户选
                if len(choices) > 1:
                    print(f"\n选哪个班?")
                    for i, c in enumerate(choices):
                        print(f"  [{i+1}] {c.teacher} | {c.section} | 余{c.remaining}")
                    s2 = input("> ").strip()
                    try:
                        i2 = int(s2)-1
                        if 0 <= i2 < len(choices):
                            choices = [choices[i2]]
                    except: pass
                break
        except: pass
        print("无效")

    print(f"\n目标: {choices[0]}")
    return ct, choices

# ============================================================
# Part 6: 主入口
# ============================================================
BANNER = """
========================================================
  肇庆学院 教务助手 v7.1
  成绩查询（只读） | 交互选课 | 异步轮询 | 齐射触发
  QQ群: 1044128566
========================================================"""

def load_config(config_path: str = "config.ini") -> dict:
    cfg = configparser.ConfigParser()
    if Path(config_path).exists():
        cfg.read(config_path, encoding='utf-8')
        return {
            "username": cfg.get("account","username",fallback=""),
            "password": cfg.get("account","password",fallback=""),
            "concurrent": cfg.getint("grab","concurrent",fallback=16),
            "pool_size": cfg.getint("grab","pool_size",fallback=16),
            "poll_ms": cfg.getint("grab","poll_ms",fallback=1),
            "retry_ms": cfg.getint("grab","retry_ms",fallback=250),
            "warmup_ms": cfg.getint("grab","warmup_ms",fallback=8000),
            "lead_ms": cfg.getint("grab","lead_ms",fallback=80),
            "burst_count": cfg.getint("grab","burst_count",fallback=5),
            "burst_gap_ms": cfg.getint("grab","burst_gap_ms",fallback=40),
            "mode": cfg.get("grab","mode",fallback="auto"),
            "prefire": cfg.getboolean("grab","prefire",fallback=False),
            "prefire_interval_ms": cfg.getint("grab","prefire_interval_ms",fallback=200),
            "proxy": cfg.get("advanced","proxy",fallback=None) or None,
            "log_level": cfg.get("advanced","log_level",fallback="INFO"),
        }
    return {}

def setup_log(level="INFO"):
    logger.remove()
    logger.add(sys.stderr, level=level, colorize=True,
        format="<green>{time:HH:mm:ss.SSS}</green> | <level>{level: <8}</level> | <level>{message}</level>")

def main():
    import argparse
    p = argparse.ArgumentParser(description="肇庆学院 WebVPN 教务助手 v7.1")
    p.add_argument("-u","--username", help="学号")
    p.add_argument("-p","--password", help="密码")
    p.add_argument("--pool", type=int, default=None, help="连接池大小")
    p.add_argument("--poll-ms", type=int, default=None, help="轮询间隔(毫秒, 默认读取配置/1ms)")
    p.add_argument("--retry-ms", type=int, default=None, help="提交失败后的重试间隔(毫秒, 默认250)")
    p.add_argument("--warmup-ms", type=int, default=None, help="极速定时模式提前预热毫秒数(默认8000)")
    p.add_argument("--lead-ms", type=int, default=None, help="首个边界波次提前毫秒数(默认80)")
    p.add_argument("--burst-count", type=int, default=None, help="跨开窗边界提交波次数(默认5)")
    p.add_argument("--burst-gap-ms", type=int, default=None, help="边界波次间隔毫秒数(默认40)")
    p.add_argument("--mode", choices=["auto","timed","poll"], default=None, help="auto=有窗口时间则定时, timed=强制定时, poll=传统轮询")
    p.add_argument("--prefire", action="store_true", help="开启预发射试探提交(默认关闭)")
    p.add_argument("--prefire-ms", type=int, default=None, help="预发射间隔(毫秒, 默认200)")
    p.add_argument("--grades", action="store_true", help="登录后直接进入只读成绩查询")
    p.add_argument("--login-only", action="store_true")
    p.add_argument("--config", default="config.ini")
    p.add_argument("--proxy", help="HTTP代理")
    p.add_argument("--debug", action="store_true")
    args = p.parse_args()

    cfg = load_config(args.config)
    username = args.username or cfg.get("username","")
    password = args.password or cfg.get("password","")
    pool_size = max(1, args.pool if args.pool is not None else cfg.get("pool_size",16))
    poll_ms = max(1, args.poll_ms if args.poll_ms is not None else cfg.get("poll_ms",1))
    retry_ms = max(200, args.retry_ms if args.retry_ms is not None else cfg.get("retry_ms",250))
    warmup_ms = max(0, args.warmup_ms if args.warmup_ms is not None else cfg.get("warmup_ms",8000))
    lead_ms = max(0, args.lead_ms if args.lead_ms is not None else cfg.get("lead_ms",80))
    burst_count = max(1, args.burst_count if args.burst_count is not None else cfg.get("burst_count",5))
    burst_gap_ms = max(1, args.burst_gap_ms if args.burst_gap_ms is not None else cfg.get("burst_gap_ms",40))
    mode = (args.mode or cfg.get("mode","auto") or "auto").lower()
    if mode not in {"auto","timed","poll"}:
        mode = "auto"
    prefire = bool(args.prefire or cfg.get("prefire", False))
    prefire_interval_ms = max(50, args.prefire_ms if args.prefire_ms is not None else cfg.get("prefire_interval_ms",200))
    proxy = args.proxy or cfg.get("proxy") or None
    log_level = "DEBUG" if args.debug else cfg.get("log_level","INFO")

    setup_log(log_level)
    print(BANNER)

    if not username:
        username = input("学号: ").strip()
    if not password:
        password = input("密码: ").strip()
    if not username or not password:
        logger.error("账号密码不能为空!"); return

    # ═══ 登录 (同步) ═══
    logger.info("Step 1/2: VPN 登录")
    s = vpn_login(username, password, proxy)
    if not s: return

    logger.info("Step 2/2: 教务登录")
    if not edu_login(s, username, password): return

    if args.login_only:
        logger.success("登录链路正常!"); return

    if args.grades:
        interactive_grade_query(s)
        return

    while True:
        print("\n功能菜单:")
        print("  [1] 成绩查询（只读）")
        print("  [2] 进入选课")
        print("  [q] 退出")
        action = input("> ").strip().lower()
        if action == "1":
            interactive_grade_query(s)
        elif action == "2":
            break
        elif action == "q":
            return
        else:
            print("无效")

    # ═══ 登录完, 显示已选 ═══
    scanner = Scanner(s)
    types = scanner.scan_types()
    if types:
        for t in types:
            enrolled = scanner.scan_enrolled(t)
            if enrolled:
                logger.info(f"[{t.name}] 已选 {len(enrolled)}门:")
                for e in enrolled:
                    logger.info(f"  {e.get('kcmc','?')} - {e.get('jxbmc',e.get('xmmc','?'))}")

    # ═══ 交互式选课 ═══
    ct, targets = interactive_select(scanner)

    if ct is None:
        logger.info("没有可用的选课类型, 退出")
        return

    if not targets:
        logger.info(f"[{ct.name}] 当前未选择目标课程 — 进入只读监控模式")
        logger.info("提示: 发现课程后不会自动提交任意课程，请重新运行并选择具体目标。")

    # 校准服务器时间，并选择当前/下一轮选课窗口。
    server_delta = calibrate_server_time(s)
    now_cn = server_now(server_delta).astimezone(CN_TZ)
    selected_window = choose_active_or_next_window(ct.raw, now_cn)
    if selected_window:
        logger.info(
            f"选课窗口: 第{selected_window['stage']}轮 "
            f"{selected_window['start'].strftime('%Y-%m-%d %H:%M:%S')} ~ "
            f"{selected_window['end'].strftime('%Y-%m-%d %H:%M:%S')} "
            f"({selected_window['status']})"
        )
    else:
        logger.warning("未识别到当前或未来选课窗口时间；定时模式将回退到轮询模式。")

    if targets:
        save_target_selection(ct, targets, selected_window)

    use_timed_mode = bool(targets and selected_window and mode in {"auto", "timed"})
    if mode == "timed" and not use_timed_mode:
        logger.warning("强制定时模式条件不足：需要已选择目标课程且能识别选课窗口，已回退轮询/监控。")

    # 提取 cookies 给 aiohttp
    cookies = {k:v for k,v in s.cookies.items()}

    # ═══ 微秒级引擎 ═══
    grabber = MicroGrabber(
        cookies,
        pool_size,
        retry_ms=retry_ms,
        prefire=prefire,
        prefire_interval_ms=prefire_interval_ms,
        proxy=proxy,
    )
    grabber._ct = ct
    grabber._targets = targets

    logger.info(f"\n启动微秒级引擎:")
    logger.info(f"  模式: {'极速定时' if use_timed_mode else '轮询'} ({mode})")
    logger.info(f"  连接池: {pool_size} keep-alive")
    logger.info(f"  轮询: {poll_ms}ms ({1000//poll_ms}次/秒)")
    logger.info(f"  失败重试: {retry_ms}ms")
    logger.info(f"  定时预热: {warmup_ms}ms")
    logger.info(f"  首波提前: {lead_ms}ms")
    logger.info(f"  边界波次: {burst_count}波 × {burst_gap_ms}ms")
    logger.info(f"  预发射: {'开启' if prefire else '关闭'}" + (f" ({prefire_interval_ms}ms)" if prefire else ""))
    logger.info(f"  目标: {len(targets)}门课")
    logger.info(f"  只提交已选择目标，不会退化为任意课程。")
    logger.info("按 Ctrl+C 停止\n")

    async def run():
        try:
            if use_timed_mode:
                async def recalibrate_time():
                    return await asyncio.to_thread(calibrate_server_time, s)

                await grabber._timed_fire(
                    ct,
                    targets,
                    selected_window,
                    server_delta,
                    warmup_ms=warmup_ms,
                    lead_ms=lead_ms,
                    burst_count=burst_count,
                    burst_gap_ms=burst_gap_ms,
                    time_calibrator=recalibrate_time,
                )
            else:
                await grabber._warm_up()
                await grabber._wait_and_fire(ct, targets, poll_ms)
        except KeyboardInterrupt:
            logger.info("用户中断")
        finally:
            await grabber._close()

    try:
        asyncio.run(run())
    except KeyboardInterrupt:
        logger.info("已停止")

if __name__ == "__main__":
    main()
