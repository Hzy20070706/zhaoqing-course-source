# 更新记录

## v1.2.5

- 修复 Windows `cmd` 下 `.bat` 中文编码乱码导致的启动失败。
- `start_webui.bat`、`install_dependencies.bat` 改为纯 ASCII 输出，避免出现 `'y' 不是内部或外部命令` 等错误。
- 保留中文名 `安装依赖.bat`，但它现在只是调用英文安装脚本的轻量包装。

## v1.2.4

- 启动脚本新增缺依赖自动安装：
  - 官方 PyPI 失败后自动切换清华源、阿里云源、中科大源。
  - 安装过程显示 pip 自带进度条。
  - 新增 `安装依赖.bat`，可单独安装依赖。

## v1.2.3

- 新增“课程表”页面。
  - 来源：教务系统 `信息查询 → 课表查询`。
  - 支持按学期选择。
  - 显示课程名、教师、地点、星期、节次、周次。
  - 接口均为只读 GET 查询。
- 新增真实课表接口封装：
  - `xsgrkbcx!getXsgrbkList.action`
  - `xsgrkbcx!xsAllKbList.action`
- 新增 WebUI 接口：
  - `GET /api/timetable/terms`
  - `GET /api/timetable`
- 新增安全交付规则：
  - `.gitignore` 默认忽略本机保存登录、会话、token、client id、缓存、压缩包。
  - 发布包不包含账号密码、cookie、session、token、community client id。
- 新增 `使用说明.md`。
- 更新健康检查版本到 `1.2.3`。

## v1.2.2

- 成绩查询、未读消息、课程选择目标、在线人数曲线、教师资料缓存等功能稳定版。
