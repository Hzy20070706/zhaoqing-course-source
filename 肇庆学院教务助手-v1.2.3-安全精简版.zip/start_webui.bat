@echo off
setlocal
cd /d "%~dp0"
set "PYTHON_EXE=D:\anaconda3\envs\cs2\python.exe"
if exist "%PYTHON_EXE%" (
  "%PYTHON_EXE%" -B start_webui.py %*
) else (
  echo [INFO] Recommended Python not found: %PYTHON_EXE%
  echo [INFO] Using py -3. Ensure requirements.txt is installed in that environment.
  py -3 -B start_webui.py %*
)
if errorlevel 1 pause
endlocal
