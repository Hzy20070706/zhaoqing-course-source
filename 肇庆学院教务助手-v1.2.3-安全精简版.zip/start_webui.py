#!/usr/bin/env python3
"""Start the local ZQU WebUI."""
from __future__ import annotations

import argparse
import os
import socket
import sys
import webbrowser
from json import JSONDecodeError, load
from pathlib import Path
from urllib.error import URLError
from urllib.request import urlopen

ROOT = Path(__file__).resolve().parent


def _ensure_web_dependencies() -> None:
    missing = []
    try:
        import fastapi  # noqa: F401
    except ImportError:
        missing.append("fastapi")
    try:
        import uvicorn  # noqa: F401
    except ImportError:
        missing.append("uvicorn")
    try:
        import pydantic  # noqa: F401
    except ImportError:
        missing.append("pydantic")
    if missing:
        packages = " ".join(missing)
        raise SystemExit(
            f"当前 Python 缺少依赖：{packages}\n"
            f"解释器：{sys.executable}\n"
            "请使用已配置的 Python 环境，或手动执行：\n"
            f'  "{sys.executable}" -m pip install -r requirements.txt'
        )


def _port_available(host: str, port: int) -> bool:
    with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as sock:
        try:
            sock.bind((host, port))
            return True
        except OSError:
            return False


def _running_webui(url: str) -> bool:
    try:
        with urlopen(f"{url}api/health", timeout=1.5) as response:
            payload = load(response)
        return bool(isinstance(payload, dict) and payload.get("app"))
    except (OSError, URLError, JSONDecodeError, ValueError):
        return False


def _next_available_port(host: str, requested_port: int) -> int | None:
    for candidate in range(requested_port + 1, requested_port + 21):
        if _port_available(host, candidate):
            return candidate
    return None


def main():
    parser = argparse.ArgumentParser(description="肇庆学院教务助手 WebUI")
    parser.add_argument("--host", default="127.0.0.1")
    parser.add_argument("--port", type=int, default=8766)
    parser.add_argument("--server-url", default=os.getenv("ZQU_SERVER_URL", ""))
    parser.add_argument("--no-browser", action="store_true")
    parser.add_argument("--reload", action="store_true")
    args = parser.parse_args()

    if args.server_url:
        os.environ["ZQU_SERVER_URL"] = args.server_url.strip().rstrip("/")

    if sys.platform.startswith("win"):
        os.environ.setdefault("PYTHONIOENCODING", "utf-8")
        for stream in (sys.stdout, sys.stderr):
            try:
                stream.reconfigure(encoding="utf-8")
            except Exception:
                pass

    browser_host = "127.0.0.1" if args.host == "0.0.0.0" else args.host
    port = args.port
    url = f"http://{browser_host}:{port}/"
    if not _port_available(args.host, port):
        if _running_webui(url):
            print(f"肇庆学院教务助手已在运行：{url}")
            if not args.no_browser:
                webbrowser.open(url)
            return
        fallback_port = _next_available_port(args.host, port)
        if fallback_port is None:
            raise SystemExit(f"端口 {port}-{port + 20} 均被占用，请稍后重试。")
        port = fallback_port
        url = f"http://{browser_host}:{port}/"
        print(f"端口 {args.port} 被其他程序占用，已改用 {port}。")

    _ensure_web_dependencies()
    sys.path.insert(0, str(ROOT))
    import uvicorn

    print(f"肇庆学院教务助手 WebUI: {url}")
    if not args.no_browser:
        webbrowser.open(url)
    uvicorn.run(
        "webui.app:app",
        host=args.host,
        port=port,
        reload=args.reload,
        log_level="info",
        access_log=False,
    )


if __name__ == "__main__":
    main()
